# LDS-VOICE Quick Start

**From zero to running voice agent in 5 minutes.**

---

## What You Get

| File | Purpose |
|------|---------|
| `lds_voice_starter.py` | **Runnable agent** - the actual voice app |
| `test_lds_video.py` | Video safety tests |
| `lds-voice-spec/` | 61 LDS entities + 24 spec docs |

---

## Step 1: Install Dependencies

```bash
pip install groq pyttsx3 --break-system-packages
```

Optional (better voices):
```bash
pip install elevenlabs --break-system-packages
```

---

## Step 2: Set API Key

```bash
export GROQ_API_KEY="your-groq-api-key"
```

Get a free key at: https://console.groq.com

Optional (for premium voices):
```bash
export ELEVENLABS_API_KEY="your-elevenlabs-key"
```

---

## Step 3: Run

**Interactive mode:**
```bash
python lds_voice_starter.py
```

**Demo mode:**
```bash
python lds_voice_starter.py --demo
```

---

## What It Does

```
You: What's the weather like?
Agent: [Speaks response using text-to-speech]

You: /public
🏪 [Simulated: Public space detected]

You: Tell me my diagnosis
Agent: [PHI content detected but blocked in current environment...]

You: /private
You: /headphones
You: Tell me my diagnosis
Agent: [Speaks PHI - private space with headphones]
```

---

## Commands

| Command | Effect |
|---------|--------|
| `/status` | Show agent status |
| `/public` | Simulate coffee shop (blocks PHI) |
| `/private` | Simulate home office |
| `/stop` | Simulate stop gesture (stops speaking) |
| `/away` | Simulate looking away (pauses) |
| `/back` | Restore attention |
| `/headphones` | Toggle headphones (enables PHI) |
| `/quit` | Exit |

---

## Architecture

```
User Input → Video Signals → LDS Rules → LLM → PHI Check → Voice Synthesis
                  ↓
            Audit Log
```

**Key principle**: Visual context dictates audio behavior.

---

## Run Tests

```bash
python test_lds_video.py
```

All 10 tests should pass:
- Public space blocks PHI ✅
- Multiple faces block PHI ✅
- Stop gesture stops audio ✅
- User absence pauses audio ✅
- Headphones enable PHI ✅

---

## Load Custom Entities

```python
from lds_voice_starter import LDSVoiceAgent

agent = LDSVoiceAgent()
agent.load_entities("lds-voice-spec/seed-data")
```

---

## Configuration

Edit `Config` class in `lds_voice_starter.py`:

```python
class Config:
    GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
    ELEVENLABS_API_KEY = os.environ.get("ELEVENLABS_API_KEY", "")
    DEFAULT_LLM_MODEL = "llama-3.1-8b-instant"
    DEFAULT_VOICE = "system"  # "system", "elevenlabs"
    HIPAA_MODE = True
```

---

## Next Steps

1. **Add your own entities**: Create JSON files in `seed-data/`
2. **Connect real video**: Replace `VideoSignals` with actual camera processing
3. **Add voice cloning**: Integrate ElevenLabs or Coqui XTTS
4. **Build UI**: Create React frontend using `video-consent-ui.lds.json`
5. **Deploy**: See `LDS_PLATFORM_SPECIFICATION.md` for multi-tenant setup

---

## File Structure

```
.
├── lds_voice_starter.py      # Main runnable agent
├── test_lds_video.py         # Video safety tests
├── QUICK_START.md            # This file
└── lds-voice-spec/
    ├── seed-data/            # 61 LDS entities
    │   ├── video/            # Video capability entities
    │   ├── voice/            # Voice profiles
    │   ├── controls/         # Safety breakers
    │   ├── hipaa/            # HIPAA compliance
    │   └── ...
    └── reference-docs/       # 24 specification documents
```

---

## That's It!

You now have a working voice agent with:
- ✅ Video signal processing
- ✅ PHI detection
- ✅ HIPAA compliance
- ✅ Voice synthesis
- ✅ Audit logging
- ✅ 61 LDS entities

**Questions?** Read the specs in `lds-voice-spec/reference-docs/`
