#!/usr/bin/env python3
"""
LDS-VOICE Complete Starter Kit
==============================

This is a fully runnable voice agent with:
- LDS entity loading and querying
- Voice synthesis (multiple providers)
- Video signal processing
- HIPAA compliance
- Safety breakers
- Audit logging

Run: python lds_voice_starter.py

Requirements:
    pip install groq pyttsx3 --break-system-packages

Optional (for better voices):
    pip install elevenlabs TTS --break-system-packages
"""

import json
import hashlib
import os
import sys
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from enum import Enum
from pathlib import Path


# =============================================================================
# CONFIGURATION
# =============================================================================

class Config:
    """Central configuration."""
    GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
    ELEVENLABS_API_KEY = os.environ.get("ELEVENLABS_API_KEY", "")
    
    # Defaults
    DEFAULT_LLM_MODEL = "llama-3.1-8b-instant"
    DEFAULT_VOICE = "system"  # "system", "elevenlabs", "coqui"
    
    # Safety
    PHI_KEYWORDS = ["diagnosis", "medication", "prescription", "patient", "medical record"]
    HIPAA_MODE = True
    
    # Paths
    ENTITY_DIR = Path("seed-data")
    AUDIT_LOG = Path("audit.jsonl")


# =============================================================================
# ENUMS
# =============================================================================

class Environment(Enum):
    PRIVATE = "private"
    PUBLIC = "public"
    UNKNOWN = "unknown"


class Gesture(Enum):
    NONE = "none"
    STOP = "stop"
    NOD = "nod"
    SHAKE = "shake"


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class VideoSignals:
    """Video signals extracted from camera (booleans, not footage)."""
    user_present: bool = True
    looking_at_screen: bool = True
    face_count: int = 1
    environment: Environment = Environment.PRIVATE
    gesture: Gesture = Gesture.NONE
    headphones_visible: bool = False


@dataclass
class AudioState:
    """Audio output state controlled by video signals."""
    playback: str = "active"  # "active", "paused", "stopped", "blocked"
    phi_allowed: bool = True
    volume: float = 1.0
    voice_mode: str = "normal"  # "normal", "phi_safe"


@dataclass
class AuditEntry:
    """Immutable audit log entry."""
    timestamp: str
    event_type: str
    entity_id: Optional[str]
    action: str
    details: Dict[str, Any]
    user_id: Optional[str] = None


# =============================================================================
# LDS ENTITY STORE
# =============================================================================

class LDSStore:
    """
    The LDS Entity Store - loads and queries LDS entities.
    
    This is the "truth store" that the Logic Kernel queries.
    """
    
    def __init__(self, entity_dir: Optional[Path] = None):
        self.entities: Dict[str, Dict] = {}
        self.entity_dir = entity_dir or Config.ENTITY_DIR
        self._load_embedded_entities()
        
    def _load_embedded_entities(self):
        """Load essential embedded entities for standalone operation."""
        
        # Video capability
        self.entities["lds:capability/video-input-v1"] = {
            "_lds": {"id": "lds:capability/video-input-v1", "type": "capability.video"},
            "core": {
                "modes": ["signal_only"],
                "storage": {"frames_stored": False, "retention_seconds": 0},
                "signals_extracted": ["user_present", "looking_at_screen", "face_count", 
                                      "environment_type", "gesture_detected", "headphones_visible"]
            }
        }
        
        # Video consent (default user)
        self.entities["lds:consent/video/default-v1"] = {
            "_lds": {"id": "lds:consent/video/default-v1", "type": "consent.video"},
            "core": {
                "allowed_signals": {
                    "presence_detection": {"enabled": True},
                    "attention_gating": {"enabled": True},
                    "gesture_control": {"enabled": True},
                    "environment_detection": {"enabled": True},
                    "headphone_detection": {"enabled": True}
                },
                "status": "active"
            }
        }
        
        # PHI classification
        self.entities["lds:control/phi-classification-v1"] = {
            "_lds": {"id": "lds:control/phi-classification-v1", "type": "control.phi"},
            "core": {
                "phi_identifiers": [
                    "name", "address", "date_of_birth", "ssn", "medical_record_number",
                    "diagnosis", "medication", "treatment", "lab_results"
                ],
                "safe_harbor_method": "redact_all_identifiers"
            }
        }
        
        # Voice governance
        self.entities["lds:control/voice-governance-v1"] = {
            "_lds": {"id": "lds:control/voice-governance-v1", "type": "control.voice"},
            "core": {
                "clone_rules": {
                    "require_explicit_consent": True,
                    "max_expiry_days": 365
                },
                "forbidden_uses": ["impersonation", "deepfake", "harassment"],
                "phi_rules": {
                    "clone_with_phi": False,
                    "public_space_phi": False
                }
            }
        }
        
        # PHI-safe fallback voice
        self.entities["lds:voice/profile/phi-safe-fallback-v1"] = {
            "_lds": {"id": "lds:voice/profile/phi-safe-fallback-v1", "type": "voice.profile"},
            "core": {
                "characteristics": ["neutral", "non-identifiable", "emotionally_flat"],
                "provider": "pyttsx3",
                "system_flags": {"mandatory": True, "cannot_be_disabled": True}
            }
        }
        
        # Disclosure policy
        self.entities["lds:control/disclosure-policy-v1"] = {
            "_lds": {"id": "lds:control/disclosure-policy-v1", "type": "control.disclosure"},
            "core": {
                "required_disclosures": ["data_source", "confidence_level", "phi_status"],
                "when_to_disclose": "on_request_or_low_confidence"
            }
        }
        
        # Video-audio enforcement rules
        self.entities["lds:rules/video-audio-enforcement-v1"] = {
            "_lds": {"id": "lds:rules/video-audio-enforcement-v1", "type": "rules.video_audio"},
            "core": {
                "rules": [
                    {"id": "gesture_stop", "priority": 1, 
                     "condition": "gesture == stop", "action": "playback = stopped"},
                    {"id": "eavesdropper", "priority": 2, 
                     "condition": "face_count > 1", "action": "phi_allowed = false"},
                    {"id": "public_space", "priority": 3, 
                     "condition": "environment == public", "action": "phi_allowed = false"},
                    {"id": "attention", "priority": 5, 
                     "condition": "looking_at_screen == false", "action": "playback = paused"},
                    {"id": "presence", "priority": 6, 
                     "condition": "user_present == false", "action": "playback = paused"},
                    {"id": "headphones", "priority": 7, 
                     "condition": "headphones_visible == true", "action": "phi_allowed = true"}
                ]
            }
        }
    
    def load_from_directory(self, directory: Path):
        """Load entities from JSON files in a directory."""
        if not directory.exists():
            return
            
        for json_file in directory.rglob("*.json"):
            try:
                with open(json_file) as f:
                    entity = json.load(f)
                    if "_lds" in entity and "id" in entity["_lds"]:
                        self.entities[entity["_lds"]["id"]] = entity
            except (json.JSONDecodeError, KeyError):
                pass
    
    def get(self, entity_id: str) -> Optional[Dict]:
        """Get an entity by ID."""
        return self.entities.get(entity_id)
    
    def query(self, entity_type: str = None, category: str = None) -> List[Dict]:
        """Query entities by type or category."""
        results = []
        for entity in self.entities.values():
            if entity_type and entity.get("_lds", {}).get("type") != entity_type:
                continue
            if category:
                categories = entity.get("vectors", {}).get("category", [])
                if category not in categories:
                    continue
            results.append(entity)
        return results


# =============================================================================
# AUDIT LOGGER
# =============================================================================

class AuditLogger:
    """Append-only audit log for compliance."""
    
    def __init__(self, log_path: Path = None):
        self.log_path = log_path or Config.AUDIT_LOG
        self.entries: List[AuditEntry] = []
    
    def log(self, event_type: str, action: str, entity_id: str = None, 
            details: Dict = None, user_id: str = None):
        """Log an audit event."""
        entry = AuditEntry(
            timestamp=datetime.now().isoformat(),
            event_type=event_type,
            entity_id=entity_id,
            action=action,
            details=details or {},
            user_id=user_id
        )
        self.entries.append(entry)
        
        # Append to file
        try:
            with open(self.log_path, "a") as f:
                f.write(json.dumps(entry.__dict__) + "\n")
        except IOError:
            pass
    
    def get_recent(self, n: int = 10) -> List[AuditEntry]:
        """Get most recent audit entries."""
        return self.entries[-n:]


# =============================================================================
# VIDEO LOGIC KERNEL
# =============================================================================

class VideoKernel:
    """
    Processes video signals and determines audio behavior.
    
    Visual Context → Audio Behavior (deterministic)
    """
    
    def __init__(self, store: LDSStore, audit: AuditLogger):
        self.store = store
        self.audit = audit
        self.audio_state = AudioState()
    
    def check_consent(self, user_id: str = "default") -> bool:
        """Check if user has video consent."""
        consent = self.store.get(f"lds:consent/video/{user_id}-v1")
        if not consent:
            return False
        return consent.get("core", {}).get("status") == "active"
    
    def process_signals(self, signals: VideoSignals, user_id: str = "default") -> AudioState:
        """Process video signals and return audio state."""
        
        # Check consent
        if not self.check_consent(user_id):
            self.audit.log("video", "blocked_no_consent", user_id=user_id)
            return AudioState(playback="blocked", phi_allowed=False)
        
        # Reset state
        self.audio_state = AudioState()
        
        # Apply rules in priority order
        
        # 1. Stop gesture (highest priority)
        if signals.gesture == Gesture.STOP:
            self.audio_state.playback = "stopped"
            self.audit.log("video", "gesture_stop", details={"gesture": "stop"})
            return self.audio_state
        
        # 2. Eavesdropper detection
        if signals.face_count > 1:
            self.audio_state.phi_allowed = False
            self.audio_state.voice_mode = "phi_safe"
            self.audit.log("security", "multi_face_detected", 
                          details={"face_count": signals.face_count})
        
        # 3. Public space
        if signals.environment == Environment.PUBLIC:
            self.audio_state.phi_allowed = False
            self.audio_state.voice_mode = "phi_safe"
            self.audit.log("security", "public_space_detected")
        
        # 4. Attention gating
        if not signals.looking_at_screen:
            self.audio_state.playback = "paused"
            self.audit.log("session", "attention_lost")
        
        # 5. Presence check
        if not signals.user_present:
            self.audio_state.playback = "paused"
            self.audit.log("session", "user_absent")
        
        # 6. Headphones enable PHI (if not already blocked)
        if signals.headphones_visible and self.audio_state.phi_allowed:
            self.audio_state.phi_allowed = True
            self.audit.log("security", "headphones_confirmed")
        
        return self.audio_state


# =============================================================================
# PHI DETECTOR
# =============================================================================

class PHIDetector:
    """Detects PHI in text for HIPAA compliance."""
    
    def __init__(self, store: LDSStore):
        self.store = store
        phi_entity = store.get("lds:control/phi-classification-v1")
        if phi_entity:
            self.phi_identifiers = phi_entity["core"].get("phi_identifiers", [])
        else:
            self.phi_identifiers = Config.PHI_KEYWORDS
    
    def contains_phi(self, text: str) -> bool:
        """Check if text contains PHI."""
        text_lower = text.lower()
        return any(keyword in text_lower for keyword in self.phi_identifiers)
    
    def classify(self, text: str) -> Dict[str, Any]:
        """Classify text for PHI content."""
        contains = self.contains_phi(text)
        detected = [kw for kw in self.phi_identifiers if kw in text.lower()]
        return {
            "contains_phi": contains,
            "detected_keywords": detected,
            "safe_to_speak": not contains or not Config.HIPAA_MODE
        }


# =============================================================================
# VOICE SYNTHESIZER
# =============================================================================

class VoiceSynthesizer:
    """Multi-provider voice synthesis with fallback chain."""
    
    def __init__(self, store: LDSStore, audit: AuditLogger):
        self.store = store
        self.audit = audit
        self.current_provider = Config.DEFAULT_VOICE
        self._init_providers()
    
    def _init_providers(self):
        """Initialize available voice providers."""
        self.providers = {}
        
        # Always available: pyttsx3 (system voices)
        try:
            import pyttsx3
            self.providers["system"] = pyttsx3.init()
            self.providers["system"].setProperty('rate', 150)
        except:
            pass
        
        # Optional: ElevenLabs
        if Config.ELEVENLABS_API_KEY:
            try:
                from elevenlabs import generate, set_api_key
                set_api_key(Config.ELEVENLABS_API_KEY)
                self.providers["elevenlabs"] = True
            except:
                pass
    
    def speak(self, text: str, voice_mode: str = "normal", 
              phi_allowed: bool = True) -> bool:
        """
        Synthesize and speak text.
        
        Returns True if speech was produced, False if blocked.
        """
        
        # PHI check
        if not phi_allowed and Config.HIPAA_MODE:
            # Switch to PHI-safe mode
            voice_mode = "phi_safe"
            self.audit.log("voice", "phi_safe_mode_activated")
        
        # Select provider based on mode
        if voice_mode == "phi_safe":
            provider = "system"  # Local only for PHI safety
        else:
            provider = self.current_provider
        
        # Speak using available provider
        if provider == "system" and "system" in self.providers:
            try:
                self.providers["system"].say(text)
                self.providers["system"].runAndWait()
                self.audit.log("voice", "synthesis_complete", 
                              details={"provider": "system", "length": len(text)})
                return True
            except:
                pass
        
        elif provider == "elevenlabs" and "elevenlabs" in self.providers:
            try:
                from elevenlabs import generate, play
                audio = generate(text=text, voice="Rachel")
                play(audio)
                self.audit.log("voice", "synthesis_complete",
                              details={"provider": "elevenlabs", "length": len(text)})
                return True
            except:
                # Fallback to system
                return self.speak(text, voice_mode, phi_allowed)
        
        # No provider available - print instead
        print(f"[VOICE]: {text}")
        return False


# =============================================================================
# LLM CLIENT
# =============================================================================

class LLMClient:
    """LLM client for generating responses."""
    
    def __init__(self, store: LDSStore, audit: AuditLogger):
        self.store = store
        self.audit = audit
        self.client = None
        self._init_client()
    
    def _init_client(self):
        """Initialize Groq client."""
        if Config.GROQ_API_KEY:
            try:
                from groq import Groq
                self.client = Groq(api_key=Config.GROQ_API_KEY)
            except:
                pass
    
    def generate(self, prompt: str, system_prompt: str = None) -> str:
        """Generate a response from the LLM."""
        
        if not self.client:
            return self._fallback_response(prompt)
        
        try:
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            
            response = self.client.chat.completions.create(
                model=Config.DEFAULT_LLM_MODEL,
                messages=messages,
                max_tokens=500,
                temperature=0.7
            )
            
            result = response.choices[0].message.content
            self.audit.log("llm", "generation_complete",
                          details={"model": Config.DEFAULT_LLM_MODEL, 
                                   "prompt_length": len(prompt),
                                   "response_length": len(result)})
            return result
            
        except Exception as e:
            self.audit.log("llm", "generation_failed", details={"error": str(e)})
            return self._fallback_response(prompt)
    
    def _fallback_response(self, prompt: str) -> str:
        """Fallback when LLM is unavailable."""
        return f"I received your message: '{prompt[:50]}...' but I'm currently unable to generate a full response. Please check the API configuration."


# =============================================================================
# MAIN AGENT
# =============================================================================

class LDSVoiceAgent:
    """
    The complete LDS Voice Agent.
    
    Integrates:
    - LDS entity store
    - Video signal processing
    - PHI detection
    - Voice synthesis
    - LLM generation
    - Audit logging
    """
    
    def __init__(self):
        # Initialize components
        self.store = LDSStore()
        self.audit = AuditLogger()
        self.video = VideoKernel(self.store, self.audit)
        self.phi = PHIDetector(self.store)
        self.voice = VoiceSynthesizer(self.store, self.audit)
        self.llm = LLMClient(self.store, self.audit)
        
        # State
        self.audio_state = AudioState()
        self.current_user = "default"
        
        # System prompt for LLM
        self.system_prompt = """You are a helpful voice assistant powered by the LDS (Linked Data Substrate) platform.

You follow these principles:
1. Only state facts that are grounded in truth
2. Disclose uncertainty when appropriate
3. Never make up information
4. Respect privacy and HIPAA compliance
5. Be concise and clear for voice output

Keep responses under 100 words for voice synthesis."""
        
        self.audit.log("system", "agent_initialized")
    
    def load_entities(self, directory: str):
        """Load additional entities from a directory."""
        self.store.load_from_directory(Path(directory))
        self.audit.log("system", "entities_loaded", details={"directory": directory})
    
    def update_video_signals(self, signals: VideoSignals):
        """Update video signals and recalculate audio state."""
        self.audio_state = self.video.process_signals(signals, self.current_user)
        return self.audio_state
    
    def process_input(self, text: str, video_signals: VideoSignals = None) -> str:
        """
        Process user input and generate a response.
        
        This is the main entry point for the agent.
        """
        
        # 1. Update video state if signals provided
        if video_signals:
            self.audio_state = self.update_video_signals(video_signals)
        
        # 2. Check if we should respond at all
        if self.audio_state.playback == "stopped":
            self.audit.log("agent", "response_blocked", details={"reason": "stopped"})
            return "[Response blocked by stop gesture]"
        
        if self.audio_state.playback == "paused":
            self.audit.log("agent", "response_paused", details={"reason": "paused"})
            return "[Waiting for your attention...]"
        
        if self.audio_state.playback == "blocked":
            self.audit.log("agent", "response_blocked", details={"reason": "no_consent"})
            return "[Video consent required]"
        
        # 3. Generate response from LLM
        response = self.llm.generate(text, self.system_prompt)
        
        # 4. Check response for PHI
        phi_check = self.phi.classify(response)
        
        # 5. Determine if we can speak this response
        can_speak = True
        voice_mode = "normal"
        
        if phi_check["contains_phi"]:
            if not self.audio_state.phi_allowed:
                # PHI detected but not allowed - modify response
                response = f"[PHI content detected but blocked in current environment. Please check in a private space or use text mode.]"
                can_speak = False
            else:
                voice_mode = "phi_safe"  # Use secure voice
        
        # 6. Speak the response
        if can_speak and self.audio_state.playback == "active":
            self.voice.speak(response, voice_mode, self.audio_state.phi_allowed)
        
        self.audit.log("agent", "response_generated",
                      details={"phi_detected": phi_check["contains_phi"],
                               "spoken": can_speak,
                               "voice_mode": voice_mode})
        
        return response
    
    def get_status(self) -> Dict[str, Any]:
        """Get current agent status."""
        return {
            "audio_state": {
                "playback": self.audio_state.playback,
                "phi_allowed": self.audio_state.phi_allowed,
                "voice_mode": self.audio_state.voice_mode
            },
            "entities_loaded": len(self.store.entities),
            "audit_entries": len(self.audit.entries),
            "hipaa_mode": Config.HIPAA_MODE
        }


# =============================================================================
# CLI INTERFACE
# =============================================================================

def run_interactive():
    """Run interactive CLI mode."""
    print("\n" + "="*60)
    print("LDS-VOICE Agent")
    print("="*60)
    print("\nInitializing...")
    
    agent = LDSVoiceAgent()
    
    # Default video signals (user present, private space)
    signals = VideoSignals()
    
    print("\n✅ Agent ready!")
    print(f"📊 Status: {agent.get_status()}")
    print("\nCommands:")
    print("  /status     - Show agent status")
    print("  /public     - Simulate public space")
    print("  /private    - Simulate private space")
    print("  /stop       - Simulate stop gesture")
    print("  /away       - Simulate user looking away")
    print("  /back       - Simulate user looking back")
    print("  /headphones - Toggle headphones")
    print("  /quit       - Exit")
    print("\nOr just type your message to chat.\n")
    
    while True:
        try:
            user_input = input("You: ").strip()
            
            if not user_input:
                continue
            
            # Handle commands
            if user_input.startswith("/"):
                cmd = user_input.lower()
                
                if cmd == "/quit":
                    print("Goodbye!")
                    break
                    
                elif cmd == "/status":
                    print(f"\n📊 {json.dumps(agent.get_status(), indent=2)}\n")
                    
                elif cmd == "/public":
                    signals.environment = Environment.PUBLIC
                    agent.update_video_signals(signals)
                    print("🏪 [Simulated: Public space detected]")
                    
                elif cmd == "/private":
                    signals.environment = Environment.PRIVATE
                    agent.update_video_signals(signals)
                    print("🏠 [Simulated: Private space]")
                    
                elif cmd == "/stop":
                    signals.gesture = Gesture.STOP
                    agent.update_video_signals(signals)
                    print("✋ [Simulated: Stop gesture]")
                    signals.gesture = Gesture.NONE  # Reset
                    
                elif cmd == "/away":
                    signals.looking_at_screen = False
                    agent.update_video_signals(signals)
                    print("👀 [Simulated: User looking away]")
                    
                elif cmd == "/back":
                    signals.looking_at_screen = True
                    signals.user_present = True
                    agent.update_video_signals(signals)
                    print("👁️ [Simulated: User attention restored]")
                    
                elif cmd == "/headphones":
                    signals.headphones_visible = not signals.headphones_visible
                    agent.update_video_signals(signals)
                    status = "on" if signals.headphones_visible else "off"
                    print(f"🎧 [Simulated: Headphones {status}]")
                    
                else:
                    print(f"Unknown command: {cmd}")
                    
                continue
            
            # Process normal input
            response = agent.process_input(user_input, signals)
            print(f"\nAgent: {response}\n")
            
        except KeyboardInterrupt:
            print("\n\nGoodbye!")
            break
        except EOFError:
            break


def run_demo():
    """Run a quick demo showing the system capabilities."""
    print("\n" + "="*60)
    print("LDS-VOICE Demo")
    print("="*60)
    
    agent = LDSVoiceAgent()
    signals = VideoSignals()
    
    demos = [
        ("Normal query in private space", 
         "What is the weather like today?",
         VideoSignals(environment=Environment.PRIVATE, headphones_visible=True)),
        
        ("PHI query with headphones (allowed)",
         "What was my last diagnosis?",
         VideoSignals(environment=Environment.PRIVATE, headphones_visible=True)),
        
        ("Public space detection (PHI blocked)",
         "Tell me about my medical records",
         VideoSignals(environment=Environment.PUBLIC)),
        
        ("Multiple faces detected (eavesdropper)",
         "What medications am I taking?",
         VideoSignals(face_count=2, environment=Environment.PRIVATE)),
        
        ("Stop gesture",
         "Keep talking about this topic...",
         VideoSignals(gesture=Gesture.STOP)),
    ]
    
    for title, query, video_signals in demos:
        print(f"\n{'─'*60}")
        print(f"📋 Scenario: {title}")
        print(f"   Query: {query}")
        print(f"   Video: env={video_signals.environment.value}, "
              f"faces={video_signals.face_count}, "
              f"headphones={video_signals.headphones_visible}, "
              f"gesture={video_signals.gesture.value}")
        
        response = agent.process_input(query, video_signals)
        print(f"   Response: {response[:100]}...")
        print(f"   Audio State: {agent.audio_state}")
    
    print(f"\n{'─'*60}")
    print(f"\n✅ Demo complete! {len(agent.audit.entries)} audit entries logged.")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "--demo":
            run_demo()
        elif sys.argv[1] == "--help":
            print(__doc__)
        else:
            print(f"Unknown argument: {sys.argv[1]}")
            print("Usage: python lds_voice_starter.py [--demo]")
    else:
        run_interactive()
