#!/usr/bin/env python3
"""
LDS-VOICE Video Safety Test Suite

This script validates the core safety logic:
Visual Context dictates Audio Behavior.

It simulates video signals (no webcam required) to prove
the architecture works deterministically.

Run: python test_lds_video.py
"""

import unittest
import json
from datetime import datetime
from dataclasses import dataclass
from typing import Dict, Any, Optional
from enum import Enum


# =============================================================================
# 1. THE TRUTH STORE (Video Capabilities, Consent & Rules)
# =============================================================================

RAW_LDS_STORE = {
    # The Video Capability
    "lds:capability/video-input-v1": {
        "_lds": {
            "id": "lds:capability/video-input-v1",
            "type": "capability.video"
        },
        "core": {
            "modes": ["signal_only", "frame_sampled"],
            "storage": {"frames_stored": False, "retention_seconds": 0},
            "signals_extracted": [
                "user_present", "looking_at_screen", "face_count",
                "environment_type", "gesture_detected", "headphones_visible"
            ],
            "explicitly_disabled": [
                "facial_recognition", "emotion_detection", "recording"
            ]
        }
    },
    
    # User Video Consent (matches default user_id in process_video_signals)
    "lds:consent/video/user-001-v1": {
        "_lds": {
            "id": "lds:consent/video/user-001",
            "type": "consent.video"
        },
        "core": {
            "allowed_signals": {
                "presence_detection": {"enabled": True},
                "attention_gating": {"enabled": True},
                "gesture_control": {"enabled": True},
                "environment_detection": {"enabled": True},
                "headphone_detection": {"enabled": True}
            },
            "explicitly_denied": {
                "facial_recognition": True,
                "emotion_detection": True,
                "recording": True
            },
            "expires_at": "2026-01-07T00:00:00Z",
            "status": "active"
        }
    },
    
    # Video-Audio Enforcement Rules
    "lds:rules/video-audio-enforcement-v1": {
        "_lds": {
            "id": "lds:rules/video-audio-enforcement-v1",
            "type": "rules.video_audio"
        },
        "core": {
            "rules": [
                {
                    "id": "gesture_stop",
                    "priority": 1,
                    "condition": "signal.gesture == 'stop'",
                    "action": {"audio.playback": "stopped"},
                    "immediate": True
                },
                {
                    "id": "eavesdropper_detection",
                    "priority": 2,
                    "condition": "signal.face_count > 1",
                    "action": {"audio.phi_allowed": False},
                    "immediate": True
                },
                {
                    "id": "public_space_phi_block",
                    "priority": 3,
                    "condition": "signal.environment == 'public'",
                    "action": {"audio.phi_allowed": False}
                },
                {
                    "id": "attention_gating",
                    "priority": 5,
                    "condition": "signal.looking_at_screen == False",
                    "action": {"audio.playback": "paused"}
                },
                {
                    "id": "presence_required",
                    "priority": 6,
                    "condition": "signal.user_present == False",
                    "action": {"audio.playback": "paused"}
                },
                {
                    "id": "headphones_phi_enable",
                    "priority": 7,
                    "condition": "signal.headphones_visible == True",
                    "action": {"audio.phi_allowed": True}
                }
            ]
        }
    }
}


# =============================================================================
# 2. VIDEO SIGNAL TYPES
# =============================================================================

class Environment(Enum):
    PRIVATE = "private"
    PUBLIC = "public"
    UNKNOWN = "unknown"


class Gesture(Enum):
    NONE = "none"
    STOP = "stop"
    NOD = "nod"
    SHAKE = "shake"
    WAVE = "wave"


@dataclass
class VideoSignals:
    """Represents extracted video signals - booleans and enums, NOT footage."""
    user_present: bool = True
    looking_at_screen: bool = True
    face_count: int = 1
    environment: Environment = Environment.PRIVATE
    gesture: Gesture = Gesture.NONE
    headphones_visible: bool = False
    
    # Confidence scores (0.0 - 1.0)
    confidence: Dict[str, float] = None
    
    def __post_init__(self):
        if self.confidence is None:
            self.confidence = {
                "user_present": 0.98,
                "looking_at_screen": 0.95,
                "face_count": 0.99,
                "environment": 0.85,
                "gesture": 0.90,
                "headphones_visible": 0.92
            }


@dataclass
class AudioState:
    """Represents the audio output state, controlled by video signals."""
    playback: str = "active"  # "active", "paused", "stopped"
    phi_allowed: bool = True
    volume: float = 1.0
    voice_mode: str = "normal"  # "normal", "phi_safe"


# =============================================================================
# 3. THE KERNEL (Video Signal Processor)
# =============================================================================

class VideoLogicKernel:
    """
    Processes video signals and applies LDS rules to determine audio behavior.
    
    This is the core of the "Visual Context → Audio Behavior" architecture.
    """
    
    def __init__(self, store: Dict[str, Any]):
        self.store = store
        self.audio_state = AudioState()
        self.audit_log = []
        
    def check_consent(self, user_id: str) -> bool:
        """Verify user has consented to video signal processing."""
        consent_id = f"lds:consent/video/{user_id}-v1"
        consent = self.store.get(consent_id)
        
        if not consent:
            return False
            
        # For testing, just check status (skip datetime comparison)
        return consent["core"].get("status") == "active"
    
    def process_video_signals(
        self, 
        signals: VideoSignals, 
        user_id: str = "user-001"
    ) -> AudioState:
        """
        Process video signals and apply rules to determine audio state.
        
        This is deterministic - same signals always produce same output.
        """
        
        # 1. Check consent first
        if not self.check_consent(user_id):
            self._log_event("consent_check_failed", {"user_id": user_id})
            return AudioState(playback="blocked", phi_allowed=False)
        
        # Reset to defaults
        self.audio_state = AudioState()
        
        # 2. Apply rules in priority order
        rules = self.store["lds:rules/video-audio-enforcement-v1"]["core"]["rules"]
        rules_sorted = sorted(rules, key=lambda r: r["priority"])
        
        for rule in rules_sorted:
            if self._evaluate_condition(rule["condition"], signals):
                self._apply_action(rule["action"])
                self._log_event(rule["id"], {
                    "condition": rule["condition"],
                    "action": rule["action"]
                })
                
                # If immediate and stops playback, break
                if rule.get("immediate") and self.audio_state.playback == "stopped":
                    break
        
        return self.audio_state
    
    def _evaluate_condition(self, condition: str, signals: VideoSignals) -> bool:
        """Evaluate a rule condition against current signals."""
        
        # Parse simple conditions
        if "signal.gesture == 'stop'" in condition:
            return signals.gesture == Gesture.STOP
        elif "signal.face_count > 1" in condition:
            return signals.face_count > 1
        elif "signal.environment == 'public'" in condition:
            return signals.environment == Environment.PUBLIC
        elif "signal.looking_at_screen == False" in condition:
            return not signals.looking_at_screen
        elif "signal.user_present == False" in condition:
            return not signals.user_present
        elif "signal.headphones_visible == True" in condition:
            return signals.headphones_visible
            
        return False
    
    def _apply_action(self, action: Dict[str, Any]) -> None:
        """Apply a rule action to the audio state."""
        
        if "audio.playback" in action:
            self.audio_state.playback = action["audio.playback"]
        if "audio.phi_allowed" in action:
            self.audio_state.phi_allowed = action["audio.phi_allowed"]
        if "audio.volume" in action:
            self.audio_state.volume = action["audio.volume"]
    
    def _log_event(self, event_type: str, data: Dict[str, Any]) -> None:
        """Log an audit event."""
        self.audit_log.append({
            "timestamp": datetime.now().isoformat(),
            "event": event_type,
            "data": data
        })


# =============================================================================
# 4. THE VALIDATION SUITE
# =============================================================================

class TestVideoSafety(unittest.TestCase):
    """
    Test suite validating that Visual Context → Audio Behavior works correctly.
    
    These tests prove:
    1. Public space detection blocks PHI
    2. Multiple faces (eavesdroppers) blocks PHI
    3. Attention loss pauses audio
    4. Stop gesture immediately stops audio
    5. User absence pauses audio
    6. Headphones enable PHI
    """
    
    def setUp(self):
        self.kernel = VideoLogicKernel(RAW_LDS_STORE)
    
    # =========================================================================
    # SAFETY TESTS
    # =========================================================================
    
    def test_01_public_space_blocks_phi(self):
        """If camera sees a public space (coffee shop), agent must NOT speak PHI."""
        print("\n📷 TEST 1: Public Space Safety")
        print("   Scenario: User is in a coffee shop")
        
        signals = VideoSignals(
            user_present=True,
            looking_at_screen=True,
            face_count=1,
            environment=Environment.PUBLIC,
            headphones_visible=False
        )
        
        state = self.kernel.process_video_signals(signals)
        
        self.assertFalse(
            state.phi_allowed, 
            "PHI should be BLOCKED in public space"
        )
        print("   ✅ Result: PHI blocked in public space")
        print(f"   Audio State: playback={state.playback}, phi_allowed={state.phi_allowed}")
    
    def test_02_eavesdropper_detection(self):
        """If a second face appears, PHI must stop immediately."""
        print("\n📷 TEST 2: Eavesdropper Detection")
        print("   Scenario: A second person walks into view")
        
        signals = VideoSignals(
            user_present=True,
            looking_at_screen=True,
            face_count=2,  # Two faces!
            environment=Environment.PRIVATE,
            headphones_visible=False  # No headphones
        )
        
        state = self.kernel.process_video_signals(signals)
        
        self.assertFalse(
            state.phi_allowed, 
            "PHI should be BLOCKED when 2+ faces detected"
        )
        print("   ✅ Result: PHI blocked when multiple faces detected")
        print(f"   Audio State: phi_allowed={state.phi_allowed}")
    
    def test_03_attention_pause(self):
        """If user looks away, agent should politely pause."""
        print("\n📷 TEST 3: Attention Gating")
        print("   Scenario: User looks away from screen")
        
        signals = VideoSignals(
            user_present=True,
            looking_at_screen=False,  # Not looking!
            face_count=1,
            environment=Environment.PRIVATE
        )
        
        state = self.kernel.process_video_signals(signals)
        
        self.assertEqual(
            state.playback, "paused",
            "Playback should PAUSE when eye contact lost"
        )
        print("   ✅ Result: Audio paused when attention lost")
        print(f"   Audio State: playback={state.playback}")
    
    def test_04_gesture_stop(self):
        """Stop gesture must immediately halt audio."""
        print("\n📷 TEST 4: Stop Gesture")
        print("   Scenario: User raises hand in stop gesture")
        
        signals = VideoSignals(
            user_present=True,
            looking_at_screen=True,
            face_count=1,
            environment=Environment.PRIVATE,
            gesture=Gesture.STOP
        )
        
        state = self.kernel.process_video_signals(signals)
        
        self.assertEqual(
            state.playback, "stopped",
            "Playback should STOP on stop gesture"
        )
        print("   ✅ Result: Audio immediately stopped on gesture")
        print(f"   Audio State: playback={state.playback}")
    
    def test_05_user_absence(self):
        """If user walks away, audio should pause."""
        print("\n📷 TEST 5: User Absence")
        print("   Scenario: No face detected (user walked away)")
        
        signals = VideoSignals(
            user_present=False,  # Nobody there!
            looking_at_screen=False,
            face_count=0,
            environment=Environment.PRIVATE
        )
        
        state = self.kernel.process_video_signals(signals)
        
        self.assertEqual(
            state.playback, "paused",
            "Playback should PAUSE when user absent"
        )
        print("   ✅ Result: Audio paused when user absent")
        print(f"   Audio State: playback={state.playback}")
    
    def test_06_headphones_enable_phi(self):
        """If headphones visible, PHI should be allowed."""
        print("\n📷 TEST 6: Headphones Enable PHI")
        print("   Scenario: User wearing headphones in private space")
        
        signals = VideoSignals(
            user_present=True,
            looking_at_screen=True,
            face_count=1,
            environment=Environment.PRIVATE,
            headphones_visible=True
        )
        
        state = self.kernel.process_video_signals(signals)
        
        self.assertTrue(
            state.phi_allowed,
            "PHI should be ALLOWED when headphones visible"
        )
        self.assertEqual(state.playback, "active")
        print("   ✅ Result: PHI allowed with headphones")
        print(f"   Audio State: playback={state.playback}, phi_allowed={state.phi_allowed}")
    
    # =========================================================================
    # EDGE CASE TESTS
    # =========================================================================
    
    def test_07_priority_ordering(self):
        """Stop gesture should override other rules."""
        print("\n📷 TEST 7: Priority Ordering")
        print("   Scenario: Multiple conditions true, stop gesture highest priority")
        
        signals = VideoSignals(
            user_present=True,
            looking_at_screen=True,
            face_count=2,  # Eavesdropper
            environment=Environment.PUBLIC,  # Public space
            gesture=Gesture.STOP,  # Stop gesture
            headphones_visible=True
        )
        
        state = self.kernel.process_video_signals(signals)
        
        # Stop gesture has highest priority
        self.assertEqual(
            state.playback, "stopped",
            "Stop gesture should take priority"
        )
        print("   ✅ Result: Stop gesture overrides other conditions")
        print(f"   Audio State: playback={state.playback}")
    
    def test_08_private_safe_scenario(self):
        """Normal private scenario should allow full audio."""
        print("\n📷 TEST 8: Private Safe Scenario")
        print("   Scenario: User alone in private space with headphones")
        
        signals = VideoSignals(
            user_present=True,
            looking_at_screen=True,
            face_count=1,
            environment=Environment.PRIVATE,
            gesture=Gesture.NONE,
            headphones_visible=True
        )
        
        state = self.kernel.process_video_signals(signals)
        
        self.assertEqual(state.playback, "active")
        self.assertTrue(state.phi_allowed)
        print("   ✅ Result: Full audio enabled in safe scenario")
        print(f"   Audio State: playback={state.playback}, phi_allowed={state.phi_allowed}")
    
    def test_09_audit_log_generated(self):
        """Processing should generate audit log entries."""
        print("\n📷 TEST 9: Audit Logging")
        print("   Scenario: Process signals and check audit log")
        
        signals = VideoSignals(
            user_present=True,
            environment=Environment.PUBLIC
        )
        
        self.kernel.process_video_signals(signals)
        
        self.assertGreater(
            len(self.kernel.audit_log), 0,
            "Audit log should contain entries"
        )
        print(f"   ✅ Result: {len(self.kernel.audit_log)} audit log entries generated")
        for entry in self.kernel.audit_log:
            print(f"      - {entry['event']}")


class TestVideoConsent(unittest.TestCase):
    """Test video consent handling."""
    
    def setUp(self):
        self.kernel = VideoLogicKernel(RAW_LDS_STORE)
    
    def test_missing_consent_blocks_processing(self):
        """Without consent, video processing should be blocked."""
        print("\n🔒 TEST: Missing Consent")
        print("   Scenario: User without video consent")
        
        signals = VideoSignals()
        
        # Process with non-existent user
        state = self.kernel.process_video_signals(signals, user_id="unknown-user")
        
        self.assertEqual(
            state.playback, "blocked",
            "Should block processing without consent"
        )
        self.assertFalse(state.phi_allowed)
        print("   ✅ Result: Processing blocked without consent")


# =============================================================================
# 5. DEMO MODE
# =============================================================================

def demo_video_signals():
    """Interactive demo of video signal processing."""
    print("\n" + "="*60)
    print("LDS-VOICE Video Signal Demo")
    print("="*60)
    
    kernel = VideoLogicKernel(RAW_LDS_STORE)
    
    scenarios = [
        ("Private Office, User Present", VideoSignals(
            user_present=True,
            looking_at_screen=True,
            face_count=1,
            environment=Environment.PRIVATE,
            headphones_visible=True
        )),
        ("Coffee Shop (Public)", VideoSignals(
            user_present=True,
            looking_at_screen=True,
            face_count=1,
            environment=Environment.PUBLIC
        )),
        ("Someone Walked In", VideoSignals(
            user_present=True,
            looking_at_screen=True,
            face_count=2,
            environment=Environment.PRIVATE
        )),
        ("User Looked Away", VideoSignals(
            user_present=True,
            looking_at_screen=False,
            face_count=1,
            environment=Environment.PRIVATE
        )),
        ("Stop Gesture", VideoSignals(
            user_present=True,
            looking_at_screen=True,
            face_count=1,
            environment=Environment.PRIVATE,
            gesture=Gesture.STOP
        )),
    ]
    
    for name, signals in scenarios:
        state = kernel.process_video_signals(signals)
        
        print(f"\n📷 Scenario: {name}")
        print(f"   Signals: present={signals.user_present}, " +
              f"looking={signals.looking_at_screen}, " +
              f"faces={signals.face_count}, " +
              f"env={signals.environment.value}")
        print(f"   Result:  playback={state.playback}, " +
              f"phi_allowed={state.phi_allowed}")
        
        # Show what would happen
        if state.playback == "stopped":
            print("   🛑 AUDIO: Immediately stopped")
        elif state.playback == "paused":
            print("   ⏸️  AUDIO: Paused, waiting for user")
        elif not state.phi_allowed:
            print("   🔒 AUDIO: Playing, but PHI blocked")
        else:
            print("   ✅ AUDIO: Full audio enabled")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == '--demo':
        demo_video_signals()
    else:
        print("\n" + "="*60)
        print("LDS-VOICE Video Safety Test Suite")
        print("Visual Context → Audio Behavior")
        print("="*60)
        
        # Run tests
        unittest.main(verbosity=2)
