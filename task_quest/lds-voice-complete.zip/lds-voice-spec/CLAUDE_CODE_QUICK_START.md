# LDS-VOICE: Claude Code Quick Start

**Copy this entire prompt to Claude Code to begin building.**

---

## CONTEXT

You are building LDS-VOICE, a voice-enabled AI agent that speaks only from pre-computed truth stored in LDS (Logic Data System) files.

**The core principle is non-negotiable:**
> The LLM never decides what is true. It only renders what LDS already knows.

## YOUR TASK

Build the complete LDS-VOICE system following enterprise documentation standards.

## DIRECTORY STRUCTURE

Create exactly this structure:

```
lds-voice/
├── README.md
├── CHANGELOG.md
├── requirements.txt
├── .env.example
├── .gitignore
├── docs/
│   ├── ARCHITECTURE.md
│   ├── LDS_SPECIFICATION.md
│   ├── API_REFERENCE.md
│   └── VOICE_POLICY_GUIDE.md
├── lds/
│   ├── entities/
│   │   ├── materials/
│   │   ├── assemblies/
│   │   └── profiles/
│   └── schemas/
├── kernel/
│   ├── __init__.py
│   ├── loader.py
│   ├── validator.py
│   ├── hasher.py
│   ├── supersedes.py
│   ├── inference.py
│   ├── indexer.py
│   └── query.py
├── voice/
│   ├── __init__.py
│   ├── policy.py
│   ├── intent.py
│   └── composer.py
├── audio/
│   ├── __init__.py
│   ├── stt.py
│   └── tts.py
├── llm/
│   ├── __init__.py
│   ├── groq_client.py
│   └── prompts.py
├── tests/
│   └── (test files for each module)
├── agent.py
├── main.py
└── config.py
```

## LDS FILE FORMAT (CRITICAL)

Every LDS file has exactly 5 sections:

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:namespace/type/name",
    "type": "entity_type",
    "created_at": "ISO8601",
    "content_hash": "sha256:<64-hex-chars>",
    "origin": "authority-id",
    "supersedes": "lds:..." // optional
  },
  "vectors": {
    "category": ["tag1", "tag2"],
    "spatial": null,
    "temporal": null,
    "causal": []
  },
  "core": {
    // Domain truth data - NO LDS refs allowed
  },
  "inference": {
    "relates_to": [],
    "implies": [],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

**Hash computation:**
```
sha256(canonical_json(vectors + core + inference + media))
```

Canonical JSON = sorted keys recursively.

## DOCUMENTATION REQUIREMENTS

Every file MUST have:

1. **Module docstring** with purpose, description, dependencies, example
2. **Function docstrings** with Args, Returns, Raises, Example
3. **Type hints** on all functions
4. **Comments** explaining non-obvious logic

Example:
```python
"""
LDS-VOICE: Entity Loader
========================

Purpose:
    Load and validate LDS entity files from disk.

Description:
    Recursively scans directories for .json files, validates
    each against the LDS specification, and builds an in-memory
    entity store indexed by entity ID.

Dependencies:
    - json (stdlib)
    - pathlib (stdlib)
    - kernel.validator

Example:
    >>> from kernel.loader import load_lds_entities
    >>> entities = load_lds_entities("lds/entities")
    >>> print(len(entities))
    42

Author: Lefebvre Design Solutions
Version: 1.0.0
"""
```

## KEY MODULES TO BUILD

### kernel/loader.py
- Load all .json files recursively
- Validate 5 required sections
- Return dict: id → entity

### kernel/validator.py
- Validate _lds required fields
- Verify content_hash
- Check no LDS refs in core
- Check inference arrays exist

### kernel/hasher.py
- Canonical JSON stringify (sorted keys, recursive)
- SHA-256 hash computation
- Format: "sha256:<64-hex-chars>"

### kernel/supersedes.py
- Build supersedes graph
- Identify superseded entities
- resolve_latest(entities) → current only
- get_latest(base_id) → single entity
- list_versions(base_id) → version chain

### kernel/inference.py
- extract_truth(entity) → safe facts
- Filter based on voice policy

### voice/policy.py
- Load voice profile entity
- Filter core data by allowed_domains
- Filter by fact_categories
- Apply inference implications

### llm/groq_client.py
- Initialize with GROQ_API_KEY
- render_response(structured_facts, voice_profile) → text
- System prompt constrains LLM to only speak provided facts

### llm/prompts.py
```python
RENDERER_PROMPT = """
You are a technical assistant.
You speak ONLY the facts provided below.
Do NOT add any information not explicitly stated.
Do NOT use marketing language or superlatives.
Do NOT speculate or make assumptions.
If information is not provided, say "That information is not available."

VOICE PROFILE: {profile_name}
CONSTRAINTS: {constraints}

FACTS TO SPEAK:
{structured_facts}
"""
```

### agent.py
```python
def run_agent(voice_profile_id: str):
    # 1. Load all entities
    # 2. Resolve to latest versions
    # 3. Parse user input to intent
    # 4. Query kernel for matching entities
    # 5. Extract inference-safe facts
    # 6. Apply voice policy filtering
    # 7. Render via Groq LLM
    # 8. Speak response
```

## TESTING REQUIREMENTS

Create test files for every module:
- test_loader.py
- test_validator.py
- test_hasher.py
- test_supersedes.py
- test_policy.py

Minimum test coverage: 80%
100% on validation and hash logic.

## VOICE PROFILE STRUCTURE

Voice profiles control what the agent can say:

```json
{
  "_lds": {
    "id": "lds:voice/profile/technical-truth",
    "type": "voice_profile"
  },
  "core": {
    "name": "Technical Truth Profile",
    "persona": {
      "role": "senior_engineer",
      "tone": "professional"
    },
    "fact_categories": {
      "always_include": ["dimensions", "ratings"],
      "never_include": ["unit_cost", "roi"]
    }
  },
  "inference": {
    "implies": [
      "no_marketing_language",
      "cite_source_entity"
    ]
  }
}
```

## BUILD ORDER

1. **Phase 1**: Project setup (structure, requirements, config)
2. **Phase 2**: kernel/hasher.py (foundation for validation)
3. **Phase 3**: kernel/validator.py (uses hasher)
4. **Phase 4**: kernel/loader.py (uses validator)
5. **Phase 5**: kernel/supersedes.py (uses loader)
6. **Phase 6**: kernel/inference.py
7. **Phase 7**: voice/policy.py
8. **Phase 8**: llm/prompts.py and llm/groq_client.py
9. **Phase 9**: audio/stt.py and audio/tts.py (can be stubs)
10. **Phase 10**: agent.py and main.py
11. **Phase 11**: Tests
12. **Phase 12**: Documentation

## EXECUTION COMMAND

After building, the system should run with:

```bash
# Terminal mode (for testing)
python main.py --mode terminal --profile technical-truth

# Voice mode
python main.py --mode voice --profile technical-truth
```

## REMEMBER

- The LLM NEVER invents facts
- All truth comes from LDS files
- Content hashes ensure integrity
- Supersedes chains handle versions
- Voice profiles filter what can be spoken
- Document EVERYTHING

---

**Now build LDS-VOICE. Start with Phase 1.**
