# LDS Voice System Specification

**Extension to LDS-VOICE**  
**Version**: 1.0.0  
**Date**: 2025-01-07  

---

## 1. Architecture

```
┌────────────────────────────────────────────────────────────────────────────┐
│                         LDS VOICE SYSTEM                                   │
├────────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│  ┌──────────────┐                                                          │
│  │  Voice Input │                                                          │
│  │    (Mic)     │                                                          │
│  └──────┬───────┘                                                          │
│         │                                                                  │
│         ▼                                                                  │
│  ┌──────────────┐     ┌─────────────────────────────────────────────────┐ │
│  │   STT        │     │              LDS KERNEL                         │ │
│  │ (Whisper)    │────►│  ┌─────────────────────────────────────────┐   │ │
│  └──────────────┘     │  │  Truth Layer                            │   │ │
│                       │  │  - Entity Store                         │   │ │
│                       │  │  - Supersedes Resolution                │   │ │
│                       │  └─────────────────────────────────────────┘   │ │
│                       │                                                 │ │
│                       │  ┌─────────────────────────────────────────┐   │ │
│                       │  │  Permission Layer                       │   │ │
│                       │  │  - Feature Flags                        │   │ │
│                       │  │  - Consent Verification                 │   │ │
│                       │  │  - Revocation Checks                    │   │ │
│                       │  └─────────────────────────────────────────┘   │ │
│                       │                                                 │ │
│                       │  ┌─────────────────────────────────────────┐   │ │
│                       │  │  Adapter Layer                          │   │ │
│                       │  │  - Voice Adapters (ElevenLabs, Coqui)   │   │ │
│                       │  │  - API Adapters (Calendar, Email)       │   │ │
│                       │  │  - Storage Adapters                     │   │ │
│                       │  └─────────────────────────────────────────┘   │ │
│                       └─────────────────────────────────────────────────┘ │
│                                      │                                     │
│                                      ▼                                     │
│  ┌──────────────┐     ┌──────────────────────────────────┐                │
│  │     LLM      │◄────│       Voice Composer             │                │
│  │   (Groq)     │     │  - Persona Selection             │                │
│  └──────┬───────┘     │  - Acoustic Selection            │                │
│         │             │  - Runtime Switching             │                │
│         │             └──────────────────────────────────┘                │
│         ▼                            │                                     │
│  ┌──────────────┐                    ▼                                     │
│  │     TTS      │◄───────────────────┘                                     │
│  │  (Adapter)   │                                                          │
│  └──────┬───────┘                                                          │
│         │                                                                  │
│         ▼                                                                  │
│  ┌──────────────┐                                                          │
│  │ Voice Output │                                                          │
│  │  (Speaker)   │                                                          │
│  └──────────────┘                                                          │
│                                                                            │
└────────────────────────────────────────────────────────────────────────────┘

KEY SEPARATION:
- LLM never controls voice selection
- TTS never controls truth content
- All permissions flow through LDS
```

---

## 2. Voice Adapter Entities

### 2.1 ElevenLabs Adapter

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:adapter/tts/elevenlabs-v1",
    "type": "adapter.tts",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:COMPUTE",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "adapter",
      "tts",
      "elevenlabs",
      "cloud",
      "ui:selector"
    ]
  },
  "core": {
    "name": "ElevenLabs TTS Adapter",
    "provider": "elevenlabs",
    "api_version": "v1",
    "base_url": "https://api.elevenlabs.io/v1",
    "auth_method": "api_key",
    "auth_env_var": "ELEVENLABS_API_KEY",
    
    "endpoints": {
      "text_to_speech": "/text-to-speech/{voice_id}",
      "voices": "/voices",
      "models": "/models"
    },
    
    "supported_models": [
      {
        "id": "eleven_monolingual_v1",
        "name": "Eleven Monolingual v1",
        "languages": ["en"],
        "latency": "standard"
      },
      {
        "id": "eleven_multilingual_v2",
        "name": "Eleven Multilingual v2",
        "languages": ["en", "es", "fr", "de", "it", "pt", "pl", "hi", "ar"],
        "latency": "standard"
      },
      {
        "id": "eleven_turbo_v2",
        "name": "Eleven Turbo v2",
        "languages": ["en"],
        "latency": "low"
      }
    ],
    
    "default_settings": {
      "model_id": "eleven_turbo_v2",
      "stability": 0.5,
      "similarity_boost": 0.75,
      "style": 0.0,
      "use_speaker_boost": true
    },
    
    "rate_limits": {
      "requests_per_minute": 100,
      "characters_per_month": 10000
    },
    
    "output_format": "mp3_44100_128",
    "streaming_supported": true
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "cloud_dependency",
      "api_key_required",
      "usage_metered"
    ],
    "conflicts_with": [
      "offline_only_mode",
      "no_cloud_policy"
    ],
    "requires": [
      "ELEVENLABS_API_KEY"
    ]
  },
  "media": {
    "documentation": "https://docs.elevenlabs.io/api-reference"
  }
}
```

### 2.2 Coqui TTS Adapter (Local)

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:adapter/tts/coqui-local-v1",
    "type": "adapter.tts",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:COMPUTE",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "adapter",
      "tts",
      "coqui",
      "local",
      "offline",
      "ui:selector"
    ]
  },
  "core": {
    "name": "Coqui TTS Local Adapter",
    "provider": "coqui",
    "deployment": "local",
    "requires_gpu": false,
    "requires_internet": false,
    
    "supported_models": [
      {
        "id": "tts_models/en/ljspeech/tacotron2-DDC",
        "name": "LJSpeech Tacotron2",
        "language": "en",
        "quality": "standard",
        "speed": "medium"
      },
      {
        "id": "tts_models/en/ljspeech/vits",
        "name": "LJSpeech VITS",
        "language": "en",
        "quality": "high",
        "speed": "fast"
      },
      {
        "id": "tts_models/en/vctk/vits",
        "name": "VCTK VITS Multi-Speaker",
        "language": "en",
        "quality": "high",
        "speed": "fast",
        "multi_speaker": true
      },
      {
        "id": "tts_models/multilingual/multi-dataset/xtts_v2",
        "name": "XTTS v2",
        "language": "multilingual",
        "quality": "premium",
        "speed": "slow",
        "voice_cloning": true
      }
    ],
    
    "default_settings": {
      "model_id": "tts_models/en/ljspeech/vits",
      "speaker_id": null,
      "language": "en"
    },
    
    "voice_cloning": {
      "supported": true,
      "min_audio_seconds": 6,
      "recommended_audio_seconds": 30,
      "supported_formats": ["wav", "mp3", "flac"]
    },
    
    "output_format": "wav",
    "sample_rate": 22050,
    "streaming_supported": false
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "offline_capable",
      "no_api_key_needed",
      "local_compute_required"
    ],
    "conflicts_with": [
      "cloud_only_mode"
    ],
    "requires": []
  },
  "media": {
    "documentation": "https://github.com/coqui-ai/TTS"
  }
}
```

### 2.3 pyttsx3 Fallback Adapter (System TTS)

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:adapter/tts/pyttsx3-v1",
    "type": "adapter.tts",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:COMPUTE",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "adapter",
      "tts",
      "pyttsx3",
      "system",
      "fallback",
      "offline"
    ]
  },
  "core": {
    "name": "System TTS Fallback",
    "provider": "pyttsx3",
    "deployment": "system",
    "requires_gpu": false,
    "requires_internet": false,
    "requires_api_key": false,
    
    "platform_engines": {
      "windows": "sapi5",
      "macos": "nsss",
      "linux": "espeak"
    },
    
    "default_settings": {
      "rate": 150,
      "volume": 1.0,
      "voice_index": 0
    },
    
    "quality": "basic",
    "latency": "instant",
    "streaming_supported": false
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "always_available",
      "zero_latency",
      "no_dependencies"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

---

## 3. Acoustic Profile Entities

### 3.1 Licensed Voice Profile

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:voice/acoustic/technical-neutral-v1",
    "type": "voice.acoustic",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:COMPUTE",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "voice",
      "acoustic",
      "licensed",
      "professional",
      "ui:selector"
    ]
  },
  "core": {
    "name": "Technical Neutral Voice",
    "description": "Professional, clear voice suitable for technical content",
    
    "provider_config": {
      "elevenlabs": {
        "voice_id": "21m00Tcm4TlvDq8ikWAM",
        "voice_name": "Rachel",
        "model_id": "eleven_turbo_v2",
        "settings": {
          "stability": 0.72,
          "similarity_boost": 0.65,
          "style": 0.0,
          "use_speaker_boost": true
        }
      },
      "coqui": {
        "model_id": "tts_models/en/ljspeech/vits",
        "speaker_id": null
      },
      "pyttsx3": {
        "voice_index": 0,
        "rate": 150
      }
    },
    
    "characteristics": {
      "gender_expression": "neutral",
      "accent": "north-american",
      "age_range": "adult",
      "tone": "professional",
      "pace": "measured"
    },
    
    "licensing": {
      "license_type": "commercial",
      "license_scope": ["ai_agent", "commercial_use", "broadcast"],
      "consent_verified": true,
      "consent_document_id": null,
      "attribution_required": false
    },
    
    "suitability": [
      "technical_explanations",
      "professional_communications",
      "long_form_speech",
      "customer_facing"
    ]
  },
  "inference": {
    "relates_to": [
      "lds:adapter/tts/elevenlabs-v1",
      "lds:adapter/tts/coqui-local-v1",
      "lds:adapter/tts/pyttsx3-v1"
    ],
    "implies": [
      "may_be_used_for_ai_agent",
      "suitable_for_long_form_speech",
      "professional_presentation"
    ],
    "conflicts_with": [
      "voice:celebrity",
      "voice:real_person_unlicensed"
    ],
    "requires": []
  },
  "media": {
    "sample_audio": "audio://samples/technical-neutral-demo.mp3"
  }
}
```

### 3.2 Custom Cloned Voice (With Consent)

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:voice/acoustic/custom-clone-001",
    "type": "voice.acoustic.clone",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:COMPUTE",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "voice",
      "acoustic",
      "clone",
      "custom",
      "consent-verified"
    ]
  },
  "core": {
    "name": "Custom Voice Clone - Project Lead",
    "description": "Cloned voice of authorized spokesperson",
    
    "clone_metadata": {
      "source_recordings_hours": 3.5,
      "recording_quality": "studio",
      "speaker_role": "authorized_spokesperson",
      "training_date": "2025-01-01"
    },
    
    "provider_config": {
      "elevenlabs": {
        "voice_id": "custom_voice_abc123",
        "model_id": "eleven_multilingual_v2",
        "settings": {
          "stability": 0.65,
          "similarity_boost": 0.80,
          "style": 0.1
        }
      },
      "coqui": {
        "model_id": "tts_models/multilingual/multi-dataset/xtts_v2",
        "reference_audio": "audio://clones/project-lead-reference.wav"
      }
    },
    
    "consent": {
      "consent_verified": true,
      "consent_document_id": "consent-2025-01-voice-001",
      "consent_date": "2025-01-01",
      "consenting_party": "John Smith",
      "consenting_party_role": "Project Lead",
      "scope": ["internal_use", "customer_demos"],
      "revocable": true,
      "revocation_contact": "legal@company.com",
      "expiration_date": "2026-01-01"
    },
    
    "restrictions": {
      "allowed_contexts": ["internal_communications", "authorized_demos"],
      "forbidden_contexts": ["public_broadcast", "impersonation", "third_party"],
      "requires_disclosure": true,
      "disclosure_text": "This voice is AI-generated based on an authorized recording."
    }
  },
  "inference": {
    "relates_to": [
      "lds:adapter/tts/elevenlabs-v1",
      "lds:adapter/tts/coqui-local-v1"
    ],
    "implies": [
      "consent_verified",
      "revocable_at_any_time",
      "disclosure_required"
    ],
    "conflicts_with": [
      "voice:unlicensed",
      "public_broadcast_context"
    ],
    "requires": [
      "consent_verified:true",
      "consent_not_expired",
      "consent_not_revoked"
    ]
  },
  "media": {
    "consent_document": "pdf://legal/voice-consent-001.pdf",
    "sample_audio": "audio://samples/custom-clone-demo.mp3"
  }
}
```

---

## 4. Voice + Persona Composition

### 4.1 Composed Voice Entity

A composed voice combines:
- **Persona** (what to say, how to think)
- **Acoustic** (how it sounds)
- **Constraints** (what's allowed)

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:voice/composed/technical-assistant-v1",
    "type": "voice.composed",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:COMPUTE",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "voice",
      "composed",
      "production",
      "ui:panel"
    ]
  },
  "core": {
    "name": "Technical Assistant Voice",
    "description": "Production voice combining technical persona with professional acoustic",
    
    "composition": {
      "persona_id": "lds:voice/profile/technical-truth",
      "acoustic_id": "lds:voice/acoustic/technical-neutral-v1",
      "adapter_priority": [
        "lds:adapter/tts/elevenlabs-v1",
        "lds:adapter/tts/coqui-local-v1",
        "lds:adapter/tts/pyttsx3-v1"
      ]
    },
    
    "runtime_overrides": {
      "allow_acoustic_switch": true,
      "allow_persona_switch": false,
      "allow_adapter_fallback": true
    },
    
    "speech_synthesis": {
      "pre_processing": {
        "expand_abbreviations": true,
        "normalize_numbers": true,
        "add_pauses_at_periods": true,
        "pause_duration_ms": 300
      },
      "post_processing": {
        "normalize_volume": true,
        "target_db": -16,
        "remove_silence": true,
        "silence_threshold_db": -40
      }
    },
    
    "disclosure": {
      "required": true,
      "timing": "on_first_interaction",
      "text": "I'm an AI assistant. My voice is synthesized."
    }
  },
  "inference": {
    "relates_to": [
      "lds:voice/profile/technical-truth",
      "lds:voice/acoustic/technical-neutral-v1",
      "lds:adapter/tts/elevenlabs-v1"
    ],
    "implies": [
      "production_ready",
      "multi_adapter_support",
      "graceful_degradation"
    ],
    "conflicts_with": [],
    "requires": [
      "lds:voice/profile/technical-truth",
      "lds:voice/acoustic/technical-neutral-v1"
    ]
  },
  "media": {}
}
```

### 4.2 Superintendent Composed Voice

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:voice/composed/field-superintendent-v1",
    "type": "voice.composed",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:COMPUTE",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "voice",
      "composed",
      "field",
      "construction"
    ]
  },
  "core": {
    "name": "Field Superintendent Voice",
    "description": "Direct, practical voice for construction site use",
    
    "composition": {
      "persona_id": "lds:voice/profile/site-superintendent",
      "acoustic_id": "lds:voice/acoustic/technical-neutral-v1",
      "adapter_priority": [
        "lds:adapter/tts/pyttsx3-v1",
        "lds:adapter/tts/coqui-local-v1"
      ]
    },
    
    "runtime_overrides": {
      "allow_acoustic_switch": false,
      "allow_persona_switch": false,
      "allow_adapter_fallback": true
    },
    
    "speech_synthesis": {
      "pre_processing": {
        "expand_abbreviations": true,
        "normalize_numbers": true,
        "add_pauses_at_periods": false,
        "emphasis_on_warnings": true
      },
      "post_processing": {
        "normalize_volume": true,
        "target_db": -12,
        "boost_clarity": true
      }
    },
    
    "environment": {
      "optimized_for": "noisy_environment",
      "speech_rate": "slightly_faster",
      "articulation": "clear"
    }
  },
  "inference": {
    "relates_to": [
      "lds:voice/profile/site-superintendent",
      "lds:voice/acoustic/technical-neutral-v1"
    ],
    "implies": [
      "offline_capable",
      "field_optimized",
      "low_latency"
    ],
    "conflicts_with": [
      "cloud_only_mode"
    ],
    "requires": [
      "lds:voice/profile/site-superintendent"
    ]
  },
  "media": {}
}
```

---

## 5. Revocation System

### 5.1 Revocation Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:revocation/voice/custom-clone-001",
    "type": "revocation.voice",
    "created_at": "2025-01-15T10:30:00Z",
    "content_hash": "sha256:COMPUTE",
    "origin": "legal-department"
  },
  "vectors": {
    "category": [
      "revocation",
      "voice",
      "legal",
      "immediate"
    ]
  },
  "core": {
    "revoked_entity_id": "lds:voice/acoustic/custom-clone-001",
    "revocation_type": "consent_withdrawn",
    "revocation_date": "2025-01-15T10:30:00Z",
    "effective_immediately": true,
    
    "reason": {
      "category": "consent_withdrawal",
      "description": "Voice owner has requested removal of their voice clone",
      "requested_by": "John Smith",
      "request_date": "2025-01-15"
    },
    
    "required_actions": [
      "stop_all_usage_immediately",
      "delete_from_provider",
      "remove_local_cache",
      "log_compliance"
    ],
    
    "compliance": {
      "deletion_confirmed": false,
      "deletion_date": null,
      "deleted_from": [],
      "compliance_officer": null
    },
    
    "fallback": {
      "replacement_voice_id": "lds:voice/acoustic/technical-neutral-v1",
      "notify_users": true,
      "notification_text": "Voice has been changed due to licensing update."
    }
  },
  "inference": {
    "relates_to": [
      "lds:voice/acoustic/custom-clone-001"
    ],
    "implies": [
      "immediate_effect",
      "legal_requirement",
      "compliance_mandatory"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {
    "revocation_request": "pdf://legal/revocation-request-001.pdf"
  }
}
```

### 5.2 Feature Flags with Voice Control

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:control/features-v1",
    "type": "control.features",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:COMPUTE",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "control",
      "features",
      "ui:toggle"
    ]
  },
  "core": {
    "voice_features": {
      "tts_enabled": true,
      "voice_cloning_enabled": true,
      "custom_voices_enabled": true,
      "voice_switching_enabled": true,
      "elevenlabs_enabled": true,
      "coqui_enabled": true,
      "fallback_to_system": true
    },
    
    "api_features": {
      "external_api_calls": false,
      "calendar_access": false,
      "email_sending": false,
      "web_browsing": false,
      "file_system_access": false
    },
    
    "safety_features": {
      "consent_verification_required": true,
      "revocation_check_enabled": true,
      "disclosure_required": true,
      "audit_logging_enabled": true
    }
  },
  "_schema": {
    "voice_features.tts_enabled": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Text-to-Speech",
      "description": "Enable voice output"
    },
    "voice_features.voice_cloning_enabled": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Voice Cloning",
      "description": "Allow custom cloned voices",
      "dangerous": true
    },
    "voice_features.voice_switching_enabled": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Runtime Voice Switching",
      "description": "Allow changing voice during session"
    },
    "safety_features.consent_verification_required": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Consent Verification",
      "description": "Require consent check for cloned voices",
      "dangerous": true,
      "warning": "Disabling consent verification may violate regulations"
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "restricted_agent",
      "safety_first"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

---

## 6. Runtime Voice Switching

### 6.1 Voice Switch Request Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:event/voice-switch/2025-01-07T12-00-00Z",
    "type": "event.voice_switch",
    "created_at": "2025-01-07T12:00:00Z",
    "content_hash": "sha256:COMPUTE",
    "origin": "system:voice-composer"
  },
  "vectors": {
    "category": [
      "event",
      "voice",
      "switch"
    ]
  },
  "core": {
    "session_id": "session-2025-01-07T10-00-00Z",
    "switch_type": "user_requested",
    
    "previous": {
      "composed_voice_id": "lds:voice/composed/technical-assistant-v1",
      "acoustic_id": "lds:voice/acoustic/technical-neutral-v1",
      "adapter_id": "lds:adapter/tts/elevenlabs-v1"
    },
    
    "new": {
      "composed_voice_id": "lds:voice/composed/field-superintendent-v1",
      "acoustic_id": "lds:voice/acoustic/technical-neutral-v1",
      "adapter_id": "lds:adapter/tts/pyttsx3-v1"
    },
    
    "reason": "user_preference",
    "timestamp": "2025-01-07T12:00:00Z",
    
    "validation": {
      "permissions_checked": true,
      "consent_verified": true,
      "revocation_checked": true,
      "switch_allowed": true
    }
  },
  "inference": {
    "relates_to": [
      "lds:voice/composed/technical-assistant-v1",
      "lds:voice/composed/field-superintendent-v1"
    ],
    "implies": [
      "voice_change_logged",
      "audit_trail"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

---

## 7. Implementation Guide

### 7.1 Revocation Check Flow

```python
def check_voice_usable(voice_id: str, kernel) -> tuple[bool, str]:
    """
    Check if a voice can be used.
    
    Returns:
        (usable: bool, reason: str)
    """
    # 1. Check if voice exists
    voice = kernel.get(voice_id)
    if not voice:
        return False, "Voice entity not found"
    
    # 2. Check feature flags
    features = kernel.get_latest("lds:control/features")
    if voice["_lds"]["type"] == "voice.acoustic.clone":
        if not features["core"]["voice_features"]["voice_cloning_enabled"]:
            return False, "Voice cloning is disabled"
        if not features["core"]["voice_features"]["custom_voices_enabled"]:
            return False, "Custom voices are disabled"
    
    # 3. Check for revocation
    revocations = kernel.query_by_type("revocation.voice")
    for rev in revocations:
        if rev["core"]["revoked_entity_id"] == voice_id:
            if rev["core"]["effective_immediately"]:
                return False, f"Voice revoked: {rev['core']['reason']['category']}"
    
    # 4. Check consent (for cloned voices)
    if voice["_lds"]["type"] == "voice.acoustic.clone":
        consent = voice["core"].get("consent", {})
        
        if not consent.get("consent_verified"):
            return False, "Consent not verified"
        
        if consent.get("expiration_date"):
            from datetime import datetime
            exp = datetime.fromisoformat(consent["expiration_date"])
            if datetime.utcnow() > exp:
                return False, "Consent has expired"
    
    return True, "Voice usable"
```

### 7.2 Voice Switching Flow

```python
def switch_voice(
    session_id: str,
    new_composed_voice_id: str,
    kernel,
    reason: str = "user_requested"
) -> dict:
    """
    Switch to a new composed voice.
    
    Returns switch event or raises PermissionError.
    """
    # 1. Get current voice
    current = kernel.get_session_voice(session_id)
    
    # 2. Get new composed voice
    new_voice = kernel.get(new_composed_voice_id)
    if not new_voice:
        raise ValueError(f"Composed voice not found: {new_composed_voice_id}")
    
    # 3. Check if switching is allowed
    if not new_voice["core"]["runtime_overrides"].get("allow_acoustic_switch", True):
        if current["acoustic_id"] != new_voice["core"]["composition"]["acoustic_id"]:
            raise PermissionError("Voice does not allow acoustic switching")
    
    # 4. Verify all components
    acoustic_id = new_voice["core"]["composition"]["acoustic_id"]
    usable, reason_msg = check_voice_usable(acoustic_id, kernel)
    if not usable:
        raise PermissionError(f"Cannot use voice: {reason_msg}")
    
    # 5. Create switch event
    switch_event = {
        "session_id": session_id,
        "switch_type": reason,
        "previous": current,
        "new": {
            "composed_voice_id": new_composed_voice_id,
            "acoustic_id": acoustic_id,
            "adapter_id": new_voice["core"]["composition"]["adapter_priority"][0]
        },
        "validation": {
            "permissions_checked": True,
            "consent_verified": True,
            "revocation_checked": True,
            "switch_allowed": True
        }
    }
    
    # 6. Update session
    kernel.set_session_voice(session_id, switch_event["new"])
    
    return switch_event
```

---

## 8. File List for seed-data/voice/

| File | Type | Purpose |
|------|------|---------|
| `adapter-elevenlabs.lds.json` | `adapter.tts` | ElevenLabs cloud adapter |
| `adapter-coqui.lds.json` | `adapter.tts` | Coqui local adapter |
| `adapter-pyttsx3.lds.json` | `adapter.tts` | System TTS fallback |
| `acoustic-technical-neutral.lds.json` | `voice.acoustic` | Licensed professional voice |
| `acoustic-custom-clone.lds.json` | `voice.acoustic.clone` | Custom cloned voice |
| `composed-technical-assistant.lds.json` | `voice.composed` | Technical persona + voice |
| `composed-field-superintendent.lds.json` | `voice.composed` | Field persona + voice |
| `features-v1.lds.json` | `control.features` | Feature flags |

---

**End of Voice System Specification**
