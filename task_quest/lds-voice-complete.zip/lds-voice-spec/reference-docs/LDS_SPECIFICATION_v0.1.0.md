# LDS Format Specification

**Logic Data System**  
**Version 0.1.0**  
**Status: Draft**  
**Date: 2025-01-07**  
**Origin: Lefebvre Design Solutions**

---

## 0. Abstract

LDS (Logic Data System) is a data format specification designed for machine reasoning. Unlike formats designed for human readability, LDS encodes pre-computed semantic relationships, inference hooks, and multimodal references directly into the data structure.

**Core Thesis**: Shift intelligence from the model to the data. Eliminate repeated semantic computation at inference time.

---

## 1. Terminology

The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHALL NOT", "SHOULD", "SHOULD NOT", "RECOMMENDED", "MAY", and "OPTIONAL" in this document are to be interpreted as described in RFC 2119.

---

## 2. File Format

### 2.1 File Extension

- `.lds` — Logic Data System file (text or binary)
- `.ldsb` — Binary-encoded LDS file (reserved for future specification)

### 2.2 MIME Types

- `application/vnd.lds+json` — JSON-encoded LDS
- `application/vnd.lds` — Binary-encoded LDS (reserved)

### 2.3 Encoding

- Text format: UTF-8, no BOM
- Binary format: To be specified in v0.2

### 2.4 Structure

An LDS file is a JSON object containing exactly five top-level keys:

```
{
  "_lds": { ... },      // REQUIRED - Metadata
  "vectors": { ... },   // REQUIRED - Semantic indexing
  "core": { ... },      // REQUIRED - Domain data
  "inference": { ... }, // REQUIRED - Pre-computed reasoning
  "media": { ... }      // REQUIRED - Multimodal references
}
```

Additional top-level keys are NOT PERMITTED.

---

## 3. Section Specifications

### 3.1 `_lds` — Metadata Block

The `_lds` block contains identity and integrity information.

#### 3.1.1 Required Fields

| Field | Type | Mutability | Description |
|-------|------|------------|-------------|
| `v` | string | IMMUTABLE | Specification version (semver) |
| `id` | string | IMMUTABLE | Globally unique identifier (see §4) |
| `type` | string | IMMUTABLE | Entity type classification |
| `created_at` | string | IMMUTABLE | ISO 8601 timestamp |
| `content_hash` | string | IMMUTABLE | Integrity hash (see §3.1.3) |
| `origin` | string | IMMUTABLE | Issuing authority identifier |

#### 3.1.2 Optional Fields

| Field | Type | Mutability | Description |
|-------|------|------------|-------------|
| `supersedes` | string | IMMUTABLE | ID of entity this replaces |
| `expires_at` | string | IMMUTABLE | ISO 8601 expiration timestamp |
| `schema` | string | IMMUTABLE | URI to domain schema definition |

#### 3.1.3 Content Hash

The `content_hash` field MUST be computed as:

```
sha256( canonical_json( vectors + core + inference + media ) )
```

Format: `sha256:<64-character-hex-string>`

The hash MUST NOT include the `_lds` block itself.

#### 3.1.4 Immutability

All fields in `_lds` are IMMUTABLE after creation. To modify an entity, a new entity MUST be created with a new `id` and the `supersedes` field pointing to the previous entity.

LDS is append-only by design.

---

### 3.2 `vectors` — Semantic Indexing Block

The `vectors` block contains pre-computed semantic coordinates for matching and retrieval.

#### 3.2.1 Required Fields

| Field | Type | Description |
|-------|------|-------------|
| `category` | array[string] | Semantic classification tags |

#### 3.2.2 Optional Fields

| Field | Type | Description |
|-------|------|-------------|
| `spatial` | object \| null | Geometric coordinates |
| `temporal` | object \| null | Scheduling coordinates |
| `causal` | array[string] | Dependency identifiers |

#### 3.2.3 Category Vector

The `category` array MUST contain at least one string.

Tags SHOULD be:
- Lowercase
- Alphanumeric with hyphens
- Domain-specific but consistent within a corpus

Example: `["structural", "steel", "beam", "wide-flange"]`

#### 3.2.4 Spatial Vector (when present)

```json
{
  "spatial": {
    "origin": [x, y, z],           // REQUIRED if spatial present
    "bounds": [[x1,y1,z1], [x2,y2,z2]],  // OPTIONAL
    "coordinate_system": "string"  // OPTIONAL, default: "cartesian"
  }
}
```

Units: Millimeters (mm) unless otherwise specified in domain schema.

#### 3.2.5 Temporal Vector (when present)

```json
{
  "temporal": {
    "install_phase": integer | null,  // Construction phase number
    "sequence": integer | null        // Order within phase
  }
}
```

#### 3.2.6 Causal Vector

The `causal` array contains LDS identifiers (§4) that MUST exist before this entity can be instantiated.

This is a hard dependency declaration, not a suggestion.

---

### 3.3 `core` — Domain Data Block

The `core` block contains domain-specific truth data.

#### 3.3.1 Requirements

- MUST be a JSON object
- MUST NOT contain nested LDS structures
- MUST NOT contain probabilistic or AI-generated values
- SHOULD conform to a declared schema (via `_lds.schema`)

#### 3.3.2 Constraints

Core data represents **ground truth**. Values in `core`:

- MUST be deterministic
- MUST be auditable
- MUST NOT change without creating a new entity

#### 3.3.3 Domain Schemas

Domain-specific schemas (construction, mechanical, electrical) are defined in separate documents. The `_lds.schema` field MAY reference these.

---

### 3.4 `inference` — Pre-computed Reasoning Block

The `inference` block contains declared affordances — relationships and constraints that an AI system can traverse without computation.

#### 3.4.1 Required Fields

| Field | Type | Description |
|-------|------|-------------|
| `relates_to` | array[string] | Connected entity IDs |
| `implies` | array[string] | Logical consequences |
| `conflicts_with` | array[string] | Incompatible conditions |
| `requires` | array[string] | Prerequisite entity IDs |

All four fields are REQUIRED. Use empty arrays `[]` when not applicable.

#### 3.4.2 Reference Types

**Hard References** (MUST resolve):
- `relates_to`
- `requires`

Hard references point to LDS identifiers that MUST exist in the corpus for the entity to be valid in context.

**Soft References** (MAY resolve):
- `implies`
- `conflicts_with`

Soft references are semantic tags or conditions that do not require corresponding LDS entities.

#### 3.4.3 Inference vs. Rules Engine

The `inference` block is **declarative**, not **executable**.

It declares: "These relationships exist."  
It does NOT declare: "Execute this logic."

LDS is not a rules engine. It is a knowledge substrate.

---

### 3.5 `media` — Multimodal Reference Block

The `media` block contains URI references to associated resources.

#### 3.5.1 Requirements

- MUST be a JSON object
- Keys are semantic labels (e.g., `spec_sheet`, `cad_model`)
- Values are URI strings

#### 3.5.2 URI Schemes

| Scheme | Description |
|--------|-------------|
| `dwg://` | CAD drawings, 3D models |
| `pdf://` | Documents, specifications |
| `vid://` | Video content |
| `img://` | Images, photographs |
| `lds://` | Reference to another LDS entity |
| `https://` | Web resources |

#### 3.5.3 Resolution

Media URIs are **indirection pointers**, not embedded content.

LDS files MUST NOT embed binary media data.

Resolution of URIs is implementation-dependent and MAY be:
- Immediate (eager loading)
- Deferred (lazy loading)
- Cached
- Proxied

---

## 4. Identity Model

### 4.1 Identifier Format

LDS identifiers follow the pattern:

```
lds:<namespace>/<type>/<name>
```

Examples:
- `lds:construction/fastener/bolt-hex-m10x30`
- `lds:electrical/panel/200a-residential`
- `lds:acme-corp/beam/custom-w12x26-modified`

### 4.2 Namespaces

Namespaces are:
- Lowercase alphanumeric with hyphens
- Hierarchical (forward-slash separated)
- Controlled by the `origin` authority

### 4.3 Uniqueness

Within a corpus, the combination of `origin` + `id` MUST be unique.

Global uniqueness is achieved through namespace coordination (future specification).

### 4.4 Reference Semantics

When an LDS file references another entity:

```json
"relates_to": ["lds:construction/fastener/nut-hex-m10"]
```

The reference:
- MUST use the full identifier
- MAY resolve to an entity in the same corpus
- MAY resolve to an entity in a federated corpus
- MUST be validated at corpus-build time for hard references

---

## 5. What LDS Is Not

To prevent scope creep and maintain trust, the following boundaries are normative:

### 5.1 LDS does NOT embed media

Media is referenced, never embedded. LDS files remain lightweight.

### 5.2 LDS does NOT perform reasoning

LDS declares relationships. It does not execute logic, evaluate conditions, or make decisions.

### 5.3 LDS does NOT replace domain tools

LDS is not a BIM system, CAD tool, or project management platform. It is a data substrate that those tools can produce and consume.

### 5.4 LDS does NOT store probabilistic data

The `core` block contains ground truth only. AI-generated predictions, confidence scores, or probabilistic outputs MUST NOT be stored in `core`.

### 5.5 LDS does NOT guarantee real-time consistency

LDS is append-only. Updates create new entities. Consistency is eventual, not transactional.

---

## 6. Binary Format (Reserved)

The binary `.ldsb` format is anticipated for v0.2.

Design goals:
- Compiled, non-human-readable
- Optimized for traversal, not editing
- Analogous to bytecode vs. source

The binary format will be a **compilation target**, not a replacement for JSON-encoded LDS.

---

## 7. Conformance

### 7.1 Levels

**LDS-Core**: Implements §2, §3, §4  
**LDS-Full**: Implements all sections including domain schemas

### 7.2 Validation

A conforming LDS file:
- Passes JSON syntax validation
- Contains all REQUIRED fields
- Has a valid `content_hash`
- Has no additional top-level keys

---

## 8. Grounding Statement

The phrase "Speed of Existence" used in LDS documentation refers to the elimination of repeated semantic computation at inference time — not physical signal transmission.

When relationships are pre-declared, AI traversal replaces AI reasoning. The limiting factor becomes data access latency, not model computation.

---

## Appendix A: Canonical Example

See: `examples/hello-world.lds`

---

## Appendix B: Changelog

**v0.1.0** (2025-01-07)
- Initial specification draft
- Five-section container model
- Identity and reference model
- Normative boundaries

---

**End of Specification**

© 2025 Lefebvre Design Solutions
