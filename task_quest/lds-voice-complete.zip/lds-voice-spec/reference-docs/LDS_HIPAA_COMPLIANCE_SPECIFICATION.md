# LDS-VOICE HIPAA Compliance Specification

**Healthcare-Grade Voice Agent Compliance**  
**Version**: 1.0.0  
**Date**: 2025-01-07  

---

## Overview

This specification extends LDS-VOICE with HIPAA-compliant PHI handling. The core insight:

> **HIPAA does not require secrecy by default — it requires controlled, auditable disclosure.**

That's exactly what LDS provides.

---

## 1. HIPAA → LDS Mapping

| HIPAA Requirement | LDS Mechanism |
|-------------------|---------------|
| Minimum Necessary | Reasoning scope + redaction |
| Access Control | Feature flags + role entities |
| Audit Trail | Append-only LDS entities |
| Consent | Explicit consent entities |
| Revocation | Supersedes + invalidation |
| Safeguards | Policy-enforced rendering |

---

## 2. Required Entity Types

### 2.1 PHI Classification Policy

Explicitly marks what constitutes PHI.

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:policy/data-classification-phi-v1",
    "type": "policy.data_classification",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "compliance-officer"
  },
  "vectors": {
    "category": ["policy", "hipaa", "phi", "classification"]
  },
  "core": {
    "classification_name": "HIPAA PHI Classification",
    "version": "1.0",
    
    "phi_fields": [
      "patient_name",
      "date_of_birth",
      "social_security_number",
      "medical_record_number",
      "health_plan_beneficiary_number",
      "account_number",
      "certificate_license_number",
      "vehicle_identifiers",
      "device_identifiers",
      "web_urls",
      "ip_addresses",
      "biometric_identifiers",
      "full_face_photographs",
      "diagnosis",
      "treatment",
      "medication",
      "lab_results",
      "vital_signs",
      "psychiatric_notes",
      "substance_abuse_records",
      "hiv_status",
      "genetic_information"
    ],
    
    "sensitive_phi_fields": [
      "psychiatric_notes",
      "substance_abuse_records",
      "hiv_status",
      "genetic_information"
    ],
    
    "non_phi_fields": [
      "system_metrics",
      "device_status",
      "general_health_info",
      "appointment_reminders",
      "facility_information",
      "provider_directory"
    ],
    
    "phi_detection_keywords": [
      "patient", "diagnosis", "medication", "dose", "treatment",
      "prescription", "symptoms", "condition", "blood", "test results"
    ],
    
    "redaction_policy": {
      "redact_on_unauthorized": true,
      "redaction_marker": "[REDACTED]",
      "log_redactions": true
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "phi_handling_required",
      "automatic_redaction_enabled",
      "minimum_necessary_enforced"
    ],
    "conflicts_with": [
      "unrestricted_data_access"
    ],
    "requires": []
  },
  "media": {
    "hipaa_reference": "https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html"
  }
}
```

### 2.2 Patient Consent Entity

**No implicit consent. Ever.**

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:consent/patient-001-v1",
    "type": "consent.hipaa",
    "created_at": "2025-01-07T12:00:00Z",
    "content_hash": "sha256:...",
    "origin": "patient-portal"
  },
  "vectors": {
    "category": ["consent", "hipaa", "patient", "active"]
  },
  "core": {
    "consent_type": "hipaa_authorization",
    "subject_id": "patient-001",
    "subject_name_hash": "sha256:...",
    
    "granted_by": "patient",
    "granted_at": "2025-01-07T12:00:00Z",
    "witness": "intake_coordinator_jane",
    
    "allowed_uses": [
      "voice_assistant_interaction",
      "care_coordination",
      "treatment_planning",
      "medication_management"
    ],
    
    "disallowed_uses": [
      "marketing",
      "training_data",
      "analytics",
      "third_party_sharing",
      "research_without_irb"
    ],
    
    "allowed_recipients": [
      "attending_physician",
      "registered_nurse",
      "care_coordinator"
    ],
    
    "scope": {
      "phi_categories": ["treatment", "medication", "vitals", "lab_results"],
      "excluded_categories": ["psychiatric_notes", "substance_abuse"]
    },
    
    "delivery_permissions": {
      "voice_disclosure": true,
      "text_disclosure": true,
      "print_disclosure": false
    },
    
    "expires_at": "2026-01-07T00:00:00Z",
    "revocable": true,
    "revocation_contact": "privacy@hospital.org"
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "phi_processing_allowed",
      "voice_disclosure_permitted",
      "minimum_necessary_applies"
    ],
    "conflicts_with": [],
    "requires": [
      "valid_patient_identity"
    ]
  },
  "media": {
    "signed_consent_pdf": "pdf://consents/patient-001-hipaa-auth.pdf",
    "consent_form_version": "HIPAA-AUTH-2025-v1"
  }
}
```

### 2.3 Access Role Entity (Minimum Necessary)

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:role/clinician-nurse-v1",
    "type": "role.access",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "hr-system"
  },
  "vectors": {
    "category": ["role", "hipaa", "clinician", "access-control"]
  },
  "core": {
    "role_name": "registered_nurse",
    "role_code": "RN",
    "department": "inpatient_care",
    
    "allowed_phi_scope": [
      "treatment",
      "medication",
      "vitals",
      "lab_results",
      "allergies",
      "care_plan"
    ],
    
    "forbidden_phi_scope": [
      "billing",
      "psychiatric_notes",
      "substance_abuse_records",
      "hiv_status",
      "genetic_information",
      "legal_records"
    ],
    
    "allowed_actions": [
      "view_patient_chart",
      "update_vitals",
      "document_care",
      "request_medication_review"
    ],
    
    "forbidden_actions": [
      "modify_diagnosis",
      "prescribe_medication",
      "access_billing",
      "export_records"
    ],
    
    "supervision": {
      "requires_supervision": false,
      "supervisor_role": "attending_physician"
    },
    
    "training_requirements": [
      "hipaa_annual_training",
      "phi_handling_certification"
    ]
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "minimum_necessary_enforced",
      "role_based_access_control"
    ],
    "conflicts_with": [
      "unrestricted_access"
    ],
    "requires": [
      "active_employment",
      "hipaa_training_current"
    ]
  },
  "media": {}
}
```

### 2.4 Ambient Safety Control

**Voice is disclosure. Public space = no PHI.**

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:control/ambient-safety-v1",
    "type": "control.hipaa",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "privacy-officer"
  },
  "vectors": {
    "category": ["control", "hipaa", "safety", "ambient", "ui:dashboard"]
  },
  "core": {
    "safety_mode": "strict",
    
    "ambient_detection": {
      "assume_public_space": true,
      "require_private_confirmation": true,
      "check_headphones": true,
      "check_proximity": true
    },
    
    "voice_disclosure_rules": {
      "phi_over_speaker": false,
      "phi_over_headphones": true,
      "phi_requires_confirmation": true,
      "confirmation_phrase": "You are authorized to hear this information. Should I continue?"
    },
    
    "fallback_behavior": {
      "on_public_space": "text_only",
      "on_no_headphones": "text_only",
      "on_uncertainty": "text_only",
      "fallback_message": "For privacy reasons, I can't discuss patient-specific information aloud."
    },
    
    "phi_voice_modifications": {
      "lower_volume": true,
      "volume_reduction_db": -6,
      "slower_pace": true,
      "pace_reduction_percent": 20,
      "add_warning_prefix": true
    },
    
    "logging": {
      "log_ambient_checks": true,
      "log_delivery_mode": true,
      "log_phi_disclosures": true
    }
  },
  "_schema": {
    "safety_mode": {
      "type": "string",
      "ui": "dropdown",
      "options": ["strict", "standard", "permissive"],
      "default": "strict",
      "label": "Safety Mode",
      "dangerous": true
    },
    "ambient_detection.assume_public_space": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Assume Public Space",
      "description": "When uncertain, assume public space (safer)"
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "voice_phi_restricted",
      "ambient_aware",
      "privacy_first"
    ],
    "conflicts_with": [
      "unrestricted_voice_disclosure"
    ],
    "requires": []
  },
  "media": {}
}
```

### 2.5 HIPAA Compliance Status Entity

**Live dashboard of compliance state.**

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:compliance/hipaa-status-v1",
    "type": "compliance.hipaa",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:compliance-monitor"
  },
  "vectors": {
    "category": ["compliance", "hipaa", "status", "ui:dashboard"]
  },
  "core": {
    "overall_status": "compliant",
    "last_verified": "2025-01-07T12:00:00Z",
    
    "checklist": {
      "consent_management": {
        "status": "pass",
        "description": "Patient consent entities validated",
        "last_check": "2025-01-07T12:00:00Z"
      },
      "access_control": {
        "status": "pass",
        "description": "Role-based access control active",
        "last_check": "2025-01-07T12:00:00Z"
      },
      "phi_classification": {
        "status": "pass",
        "description": "PHI classification policy loaded",
        "last_check": "2025-01-07T12:00:00Z"
      },
      "ambient_safety": {
        "status": "pass",
        "description": "Ambient safety mode active",
        "last_check": "2025-01-07T12:00:00Z"
      },
      "audit_logging": {
        "status": "pass",
        "description": "Append-only audit trail active",
        "last_check": "2025-01-07T12:00:00Z"
      },
      "stt_phi_safe": {
        "status": "pass",
        "description": "PHI-safe STT adapter available",
        "last_check": "2025-01-07T12:00:00Z"
      },
      "tts_phi_safe": {
        "status": "pass",
        "description": "PHI-safe TTS adapter available",
        "last_check": "2025-01-07T12:00:00Z"
      },
      "vendor_baa": {
        "status": "warning",
        "description": "Some vendors lack BAA",
        "last_check": "2025-01-07T12:00:00Z",
        "affected_vendors": ["groq"]
      },
      "encryption_at_rest": {
        "status": "pass",
        "description": "Data encrypted at rest",
        "last_check": "2025-01-07T12:00:00Z"
      },
      "encryption_in_transit": {
        "status": "pass",
        "description": "TLS 1.3 enforced",
        "last_check": "2025-01-07T12:00:00Z"
      }
    },
    
    "blocking_issues": [],
    "warnings": ["vendor_baa"],
    
    "operational_mode": {
      "phi_voice_enabled": false,
      "phi_text_enabled": true,
      "reason": "vendor_baa_incomplete"
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "hipaa_monitoring_active",
      "compliance_dashboard_available"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

### 2.6 Vendor BAA Registry

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:vendor/registry-v1",
    "type": "vendor.registry",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "legal-department"
  },
  "vectors": {
    "category": ["vendor", "baa", "hipaa", "compliance"]
  },
  "core": {
    "vendors": [
      {
        "vendor_id": "groq",
        "vendor_name": "Groq Inc.",
        "service_type": "llm",
        "baa_signed": false,
        "phi_allowed": false,
        "notes": "Use for non-PHI reasoning only"
      },
      {
        "vendor_id": "azure-openai",
        "vendor_name": "Microsoft Azure OpenAI",
        "service_type": "llm",
        "baa_signed": true,
        "baa_date": "2025-01-01",
        "baa_document_id": "BAA-AZURE-2025-001",
        "phi_allowed": true,
        "notes": "Approved for PHI processing"
      },
      {
        "vendor_id": "elevenlabs",
        "vendor_name": "ElevenLabs",
        "service_type": "tts",
        "baa_signed": false,
        "phi_allowed": false,
        "notes": "Use only for non-PHI voice"
      },
      {
        "vendor_id": "whisper-local",
        "vendor_name": "OpenAI Whisper (Local)",
        "service_type": "stt",
        "baa_signed": false,
        "phi_allowed": true,
        "notes": "On-device, no data transmission"
      },
      {
        "vendor_id": "coqui-local",
        "vendor_name": "Coqui TTS (Local)",
        "service_type": "tts",
        "baa_signed": false,
        "phi_allowed": true,
        "notes": "On-device, no data transmission"
      }
    ],
    
    "deployment_matrix": {
      "llm_phi": "azure-openai",
      "llm_non_phi": "groq",
      "stt_phi": "whisper-local",
      "stt_non_phi": "any",
      "tts_phi": "coqui-local",
      "tts_non_phi": "elevenlabs"
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "vendor_compliance_tracked",
      "baa_status_known"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

### 2.7 PHI-Safe STT Adapter

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:adapter/stt-whisper-local-v1",
    "type": "adapter.stt",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": ["adapter", "stt", "whisper", "local", "hipaa-safe", "phi-allowed"]
  },
  "core": {
    "name": "Whisper Local STT (HIPAA-Safe)",
    "provider": "openai-whisper",
    "execution": "on_device",
    "model": "whisper-large-v3",
    
    "hipaa_compliance": {
      "phi_allowed": true,
      "baa_required": false,
      "reason": "No data leaves device"
    },
    
    "data_handling": {
      "audio_stored": false,
      "transcription_stored": false,
      "telemetry_sent": false
    },
    
    "performance": {
      "latency_ms": 800,
      "accuracy": 0.95,
      "languages": ["en", "es", "fr", "de"]
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "phi_safe_input",
      "no_external_transmission",
      "hipaa_compliant_stt"
    ],
    "conflicts_with": [],
    "requires": [
      "local_gpu_available"
    ]
  },
  "media": {}
}
```

### 2.8 PHI-Safe TTS Adapter

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:adapter/tts-coqui-hipaa-v1",
    "type": "adapter.tts",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": ["adapter", "tts", "coqui", "local", "hipaa-safe", "phi-allowed"]
  },
  "core": {
    "name": "Coqui TTS (HIPAA-Safe)",
    "provider": "coqui",
    "execution": "on_device",
    
    "hipaa_compliance": {
      "phi_allowed": true,
      "baa_required": false,
      "reason": "No data leaves device",
      "voice_isolation": true
    },
    
    "data_handling": {
      "text_stored": false,
      "audio_stored": false,
      "telemetry_sent": false
    },
    
    "voice_config": {
      "model": "tts_models/en/ljspeech/vits",
      "phi_voice_modifications": {
        "volume_reduction_db": -6,
        "slower_pace": true
      }
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "phi_safe_output",
      "no_external_transmission",
      "hipaa_compliant_tts"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

### 2.9 PHI-Safe Fallback Voice

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:voice/acoustic/phi-safe-fallback-v1",
    "type": "voice.acoustic",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": ["voice", "acoustic", "hipaa", "fallback", "safe"]
  },
  "core": {
    "name": "PHI-Safe Fallback Voice",
    "description": "Voice profile used when PHI cannot be spoken",
    
    "style": "neutral-professional",
    "emotion": "calm",
    "clarity_boost": 0.9,
    
    "phi_policy": {
      "disallows_phi": true,
      "purpose": "Safe fallback when voice PHI disclosure not permitted"
    },
    
    "allowed_content": [
      "process_explanation",
      "next_steps",
      "privacy_notice",
      "general_guidance",
      "appointment_reminders",
      "facility_information"
    ],
    
    "forbidden_content": [
      "patient_identifiers",
      "clinical_details",
      "diagnosis",
      "treatment",
      "medication",
      "lab_results"
    ],
    
    "fallback_phrases": {
      "phi_blocked": "For privacy reasons, I can't discuss patient-specific information aloud.",
      "text_redirect": "I've displayed the information privately on your screen.",
      "confirmation_needed": "To hear this information, please confirm you're in a private setting."
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "safe_disclosure_only",
      "no_phi_voice",
      "privacy_compliant"
    ],
    "conflicts_with": [
      "phi_voice_disclosure"
    ],
    "requires": []
  },
  "media": {}
}
```

### 2.10 HIPAA Audit Event Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:audit/phi-access-2025-01-07T14-22-00Z",
    "type": "audit.hipaa",
    "created_at": "2025-01-07T14:22:00Z",
    "content_hash": "sha256:...",
    "origin": "system:audit-logger"
  },
  "vectors": {
    "category": ["audit", "hipaa", "phi-access", "immutable"]
  },
  "core": {
    "event_type": "phi_access",
    "timestamp": "2025-01-07T14:22:00Z",
    
    "actor": {
      "role": "registered_nurse",
      "role_entity_id": "lds:role/clinician-nurse-v1",
      "session_id": "session-2025-01-07T10-00-00Z"
    },
    
    "subject": {
      "patient_id": "patient-001",
      "consent_id": "lds:consent/patient-001-v1"
    },
    
    "access_details": {
      "phi_scope": ["medication", "vitals"],
      "access_type": "voice_response",
      "delivery_mode": "text",
      "reason_for_text": "public_space_detected"
    },
    
    "ambient_context": {
      "headphones_connected": false,
      "private_space_confirmed": false,
      "safety_mode": "strict"
    },
    
    "consent_validation": {
      "consent_valid": true,
      "consent_checked_at": "2025-01-07T14:22:00Z",
      "scope_within_consent": true
    },
    
    "redactions_applied": [],
    
    "outcome": "success"
  },
  "inference": {
    "relates_to": [
      "lds:consent/patient-001-v1",
      "lds:role/clinician-nurse-v1"
    ],
    "implies": [
      "audit_complete",
      "immutable_record"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

---

## 3. Runtime Enforcement Rules

### 3.1 Hard Rules (Not Prompts)

```python
# Rule 1: No Consent → No PHI
def check_consent(patient_id: str) -> bool:
    consent = kernel.get_latest(f"lds:consent/{patient_id}-*")
    if not consent:
        raise PHIRefusal("HIPAA: No valid patient consent")
    if consent["core"].get("expires_at"):
        if datetime.utcnow() > parse(consent["core"]["expires_at"]):
            raise PHIRefusal("HIPAA: Patient consent has expired")
    return True

# Rule 2: Role-Based Access Control
def check_access(role_id: str, phi_scope: List[str]) -> bool:
    role = kernel.get(role_id)
    allowed = set(role["core"]["allowed_phi_scope"])
    forbidden = set(role["core"]["forbidden_phi_scope"])
    
    for scope in phi_scope:
        if scope in forbidden:
            raise PHIRefusal(f"HIPAA: Access to {scope} denied for role")
        if scope not in allowed:
            raise PHIRefusal(f"HIPAA: {scope} not in allowed scope")
    return True

# Rule 3: Automatic Redaction
def redact_phi(text: str, allowed_scope: List[str]) -> str:
    phi_policy = kernel.get("lds:policy/data-classification-phi-v1")
    for field in phi_policy["core"]["phi_fields"]:
        if field not in allowed_scope:
            text = redact_field(text, field)
    return text

# Rule 4: Voice Is Disclosure
def check_voice_disclosure(phi_present: bool, ambient: dict) -> bool:
    if not phi_present:
        return True  # Non-PHI can always be spoken
    
    safety = kernel.get("lds:control/ambient-safety-v1")
    
    if safety["core"]["ambient_detection"]["assume_public_space"]:
        if not ambient.get("private_confirmed"):
            return False
    
    if safety["core"]["voice_disclosure_rules"]["phi_over_speaker"] == False:
        if not ambient.get("headphones_connected"):
            return False
    
    return True
```

### 3.2 Refusal Responses

When PHI cannot be disclosed:

```
Voice: "For privacy reasons, I can't discuss patient-specific information aloud."

Text: "I've displayed the information privately on your screen."

No Consent: "I can't help with that because I don't have valid authorization."

Role Denied: "I can't disclose that information based on your access level."
```

---

## 4. Audit & Logging

### 4.1 Audit Requirements

Every PHI interaction creates an immutable audit entity:

- **Append-only**: No updates, only new entities
- **Immutable**: Content hash prevents tampering
- **Queryable**: Can generate compliance reports
- **Retention**: 6 years minimum (HIPAA requirement)

### 4.2 Audit Report Generation

```python
def generate_hipaa_audit_report(start_date, end_date):
    audits = kernel.query_by_type("audit.hipaa")
    
    filtered = [
        a for a in audits
        if start_date <= parse(a["core"]["timestamp"]) <= end_date
    ]
    
    return {
        "report_generated": now(),
        "period": {"start": start_date, "end": end_date},
        "total_phi_accesses": len(filtered),
        "by_role": group_by(filtered, "actor.role"),
        "by_patient": group_by(filtered, "subject.patient_id"),
        "by_delivery_mode": group_by(filtered, "access_details.delivery_mode"),
        "redactions": [a for a in filtered if a["core"]["redactions_applied"]],
        "denials": [a for a in filtered if a["core"]["outcome"] == "denied"]
    }
```

---

## 5. Deployment Architecture

### 5.1 Component Requirements

| Component | HIPAA Requirement | Options |
|-----------|-------------------|---------|
| LLM (PHI) | BAA required | Azure OpenAI, On-prem |
| LLM (non-PHI) | No BAA needed | Groq, any |
| STT | On-device OR BAA | Whisper local |
| TTS (PHI) | On-device OR BAA | Coqui local |
| TTS (non-PHI) | No BAA needed | ElevenLabs |
| Storage | Encrypted at rest | Any encrypted store |
| Transport | TLS 1.2+ | Enforced |

### 5.2 Deployment Options

**Option 1: Hybrid (Recommended)**
- Groq → non-PHI reasoning
- Azure OpenAI → PHI processing
- Whisper local → STT
- Coqui local → TTS for PHI
- ElevenLabs → TTS for non-PHI

**Option 2: Fully BAA**
- Azure OpenAI → all LLM
- Azure Speech → STT/TTS
- Azure Storage → data

**Option 3: On-Prem**
- Local LLM (Llama, Mistral)
- Whisper local
- Coqui local
- Zero external PHI exposure

---

## 6. What This Provides

| Capability | Status |
|------------|--------|
| PHI-aware routing | ✅ |
| Consent enforcement | ✅ |
| Role-based access | ✅ |
| Voice safety gating | ✅ |
| Automatic redaction | ✅ |
| Append-only audit | ✅ |
| Compliance dashboard | ✅ |
| Vendor BAA tracking | ✅ |
| Explainable denials | ✅ |

---

## 7. What This Does NOT Solve

HIPAA still requires (outside LDS scope):

- ✗ Encrypted storage at rest (infrastructure)
- ✗ Secure transport TLS (infrastructure)
- ✗ BAA with vendors (legal)
- ✗ Organizational policies (HR)
- ✗ Physical security (facilities)
- ✗ Employee training (HR)

LDS supports compliance — it does not replace legal obligations.

---

## 8. Entity Checklist

| Entity | Type | Purpose |
|--------|------|---------|
| `lds:policy/data-classification-phi-v1` | `policy.data_classification` | PHI field list |
| `lds:consent/patient-*` | `consent.hipaa` | Patient authorization |
| `lds:role/*` | `role.access` | Role-based access |
| `lds:control/ambient-safety-v1` | `control.hipaa` | Voice safety rules |
| `lds:compliance/hipaa-status-v1` | `compliance.hipaa` | Dashboard status |
| `lds:vendor/registry-v1` | `vendor.registry` | BAA tracking |
| `lds:adapter/stt-whisper-local-v1` | `adapter.stt` | PHI-safe STT |
| `lds:adapter/tts-coqui-hipaa-v1` | `adapter.tts` | PHI-safe TTS |
| `lds:voice/acoustic/phi-safe-fallback-v1` | `voice.acoustic` | Safe fallback |
| `lds:audit/*` | `audit.hipaa` | Access logs |

---

**This is not a toy. This is the minimum viable compliant agent.**

Most "HIPAA AI" systems cannot prove their compliance.  
Yours can — because every decision is encoded in LDS.

---

**End of HIPAA Compliance Specification**
