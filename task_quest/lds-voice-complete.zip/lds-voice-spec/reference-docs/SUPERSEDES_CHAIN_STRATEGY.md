# LDS Supersedes Chain Strategy

**Version Control in an Append-Only System**  
**Version 1.0.0**  
**Status: Draft**

---

## 1. The Problem

LDS is **append-only** by design (Spec §3.1.4). Entities are immutable. But construction projects require revisions:

- Material specs change
- Assembly designs evolve
- Errors are corrected
- Regulatory requirements update

How do you version data that cannot be modified?

---

## 2. The Solution: Supersedes Chains

Instead of modifying entities, you create **new entities** that declare they replace old ones.

```
Entity v1  ←──supersedes──  Entity v2  ←──supersedes──  Entity v3 (current)
```

The `supersedes` field in `_lds` points to the entity being replaced.

---

## 3. Identity Model for Versions

### 3.1 Base ID vs Version ID

Every entity has a **base identity** and a **version identity**:

```
Base ID:    lds:construction/glazing/neural-glass-panel
Version ID: lds:construction/glazing/neural-glass-panel-v2
```

**Pattern**:
```
lds:<namespace>/<type>/<base-name>           # Original
lds:<namespace>/<type>/<base-name>-v2        # Revision 2
lds:<namespace>/<type>/<base-name>-v3        # Revision 3
lds:<namespace>/<type>/<base-name>-rev-2025-01-15  # Date-based
```

### 3.2 Version Suffix Conventions

| Pattern | Use Case |
|---------|----------|
| `-v2`, `-v3` | Sequential revisions |
| `-rev-YYYY-MM-DD` | Date-based revisions |
| `-draft`, `-final` | Document lifecycle |
| `-superseded` | Explicitly deprecated |

---

## 4. Supersedes Field Usage

### 4.1 Basic Chain

**Original Entity (v1)**:
```json
{
  "_lds": {
    "id": "lds:construction/glazing/lng-p-2025",
    "created_at": "2025-01-01T00:00:00Z"
    // No supersedes field - this is the original
  }
}
```

**Revision (v2)**:
```json
{
  "_lds": {
    "id": "lds:construction/glazing/lng-p-2025-v2",
    "created_at": "2025-03-15T00:00:00Z",
    "supersedes": "lds:construction/glazing/lng-p-2025"
  }
}
```

**Revision (v3)**:
```json
{
  "_lds": {
    "id": "lds:construction/glazing/lng-p-2025-v3",
    "created_at": "2025-06-01T00:00:00Z",
    "supersedes": "lds:construction/glazing/lng-p-2025-v2"
  }
}
```

### 4.2 Chain Traversal

The Logic Kernel can traverse the chain in either direction:

**Forward** (oldest to newest):
```
v1 → v2 → v3
```

**Backward** (newest to oldest):
```
v3 → v2 → v1
```

### 4.3 Finding Current Version

```javascript
// Kernel API
kernel.get_latest("lds:construction/glazing/lng-p-2025")
// Returns: lds:construction/glazing/lng-p-2025-v3

kernel.list_versions("lds:construction/glazing/lng-p-2025")
// Returns: [v1, v2, v3] in chronological order
```

---

## 5. Reference Handling

### 5.1 The Reference Problem

When Entity A references Entity B, and B gets superseded:

```
Entity A → relates_to → Entity B (v1)
                              ↑
                        superseded by B (v2)
```

Should A's reference automatically update?

### 5.2 Reference Resolution Strategies

**Strategy 1: Explicit References (Default)**
- References point to specific version IDs
- No automatic resolution
- Consumer decides whether to follow chain

```json
"relates_to": ["lds:construction/glazing/lng-p-2025-v2"]
// Always points to v2, even if v3 exists
```

**Strategy 2: Base References**
- References point to base ID without version
- Kernel resolves to latest at query time

```json
"relates_to": ["lds:construction/glazing/lng-p-2025"]
// Kernel resolves to current version (v3)
```

**Strategy 3: Pinned with Awareness**
- Reference includes version
- Kernel flags when superseded version is referenced

```json
// Query result includes warning:
{
  "entity": "...",
  "warnings": [
    "relates_to references superseded entity: lng-p-2025-v2 → lng-p-2025-v3"
  ]
}
```

### 5.3 Recommended Approach

Use **explicit version references** for:
- Contractual documents
- Approved submittals
- As-built records

Use **base references** for:
- Active design work
- Queries that need current data
- Dependency resolution

---

## 6. Expiration and Deprecation

### 6.1 Soft Deprecation

The superseded entity remains valid but is marked as replaced:

```json
{
  "_lds": {
    "id": "lds:construction/glazing/lng-p-2025",
    "superseded_by": "lds:construction/glazing/lng-p-2025-v2"
    // Note: This is a reverse pointer, not in spec but useful
  }
}
```

### 6.2 Hard Expiration

Use `expires_at` for entities with limited validity:

```json
{
  "_lds": {
    "id": "lds:construction/permit/electrical-2025-001",
    "expires_at": "2026-01-15T00:00:00Z"
  }
}
```

Kernel behavior:
- Before expiration: Entity is valid
- After expiration: Entity is flagged, may be excluded from queries

---

## 7. Multi-Entity Revisions

When revising an assembly, you may need to revise multiple related entities:

```
Assembly v1 ────────────────→ Assembly v2
    │                              │
    ├── relates_to                 ├── relates_to
    │   Material A                 │   Material A-v2 (also revised)
    │   Material B                 │   Material B (unchanged)
    │                              │
    └── requires                   └── requires
        Equipment X                    Equipment X
```

### 7.1 Atomic Revision Sets

For coordinated revisions, use a **revision set** pattern:

```json
{
  "_lds": {
    "id": "lds:revision-set/lng-p-2025-update-2025-03",
    "type": "revision_set"
  },
  "core": {
    "description": "March 2025 specification update",
    "entities_revised": [
      {
        "old": "lds:construction/glazing/lng-p-2025",
        "new": "lds:construction/glazing/lng-p-2025-v2"
      },
      {
        "old": "lds:lefebvre/material/neural-glass-lng-p-2025",
        "new": "lds:lefebvre/material/neural-glass-lng-p-2025-v2"
      }
    ]
  }
}
```

---

## 8. Kernel Operations

### 8.1 Version Queries

```javascript
// Get specific version
kernel.get("lds:construction/glazing/lng-p-2025-v2")

// Get latest version
kernel.get_latest("lds:construction/glazing/lng-p-2025")

// Get all versions
kernel.list_versions("lds:construction/glazing/lng-p-2025")
// Returns: [v1, v2, v3] sorted by created_at

// Check if superseded
kernel.is_superseded("lds:construction/glazing/lng-p-2025")
// Returns: { superseded: true, by: "...-v3" }
```

### 8.2 Reference Resolution

```javascript
// Resolve to latest
kernel.resolve("lds:construction/glazing/lng-p-2025", { latest: true })
// Returns: lds:construction/glazing/lng-p-2025-v3

// Resolve with warnings
kernel.resolve("lds:construction/glazing/lng-p-2025-v1", { warn_superseded: true })
// Returns: { id: "...-v1", warning: "superseded by ...-v3" }
```

---

## 9. Best Practices

### 9.1 When to Create a New Version

**DO create new version**:
- Specification changes (dimensions, ratings, materials)
- Error corrections
- Regulatory updates
- Design revisions

**DON'T create new version**:
- Metadata-only changes (use separate metadata entity)
- Typo fixes in descriptions (if non-contractual)
- Adding media references (consider media entity)

### 9.2 Chain Length Limits

Keep chains reasonable:
- **Recommended max**: 10 versions
- **Beyond 10**: Consider creating a new base entity with clean lineage

### 9.3 Documentation

Every superseding entity SHOULD include in `core`:

```json
"revision_notes": {
  "summary": "Updated thermal performance ratings",
  "changes": [
    "R-value increased from 6.8 to 7.2",
    "Added condensation resistance rating"
  ],
  "reason": "Laboratory testing results"
}
```

---

## 10. Example: Complete Revision Chain

### Original (January 2025)
```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:construction/glazing/lng-p-2025",
    "type": "glazing_assembly",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:abc123...",
    "origin": "lefebvre-design-solutions"
  },
  "core": {
    "name": "Lefebvre Neural-Glass Panel",
    "model": "LNG-P-2025",
    "thermal_performance": {
      "r_value_imperial": 6.8
    }
  }
}
```

### Revision 2 (March 2025)
```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:construction/glazing/lng-p-2025-v2",
    "type": "glazing_assembly",
    "created_at": "2025-03-15T00:00:00Z",
    "content_hash": "sha256:def456...",
    "origin": "lefebvre-design-solutions",
    "supersedes": "lds:construction/glazing/lng-p-2025"
  },
  "core": {
    "name": "Lefebvre Neural-Glass Panel",
    "model": "LNG-P-2025",
    "thermal_performance": {
      "r_value_imperial": 7.2,
      "condensation_resistance": 72
    },
    "revision_notes": {
      "summary": "Thermal performance update",
      "changes": ["R-value: 6.8 → 7.2", "Added CR rating"],
      "reason": "Third-party testing certification"
    }
  }
}
```

---

## 11. Summary

| Concept | Implementation |
|---------|----------------|
| Immutability | Entities never change after creation |
| Versioning | New entity with `supersedes` pointer |
| ID Pattern | `base-name` → `base-name-v2` → `base-name-v3` |
| Resolution | Kernel follows chain to find latest |
| References | Explicit version OR base ID (strategy choice) |
| Expiration | Optional `expires_at` field |

**Key Principle**: The chain is the version history. The graph is always consistent. The past is preserved.

---

**End of Strategy Document**

© 2025 Lefebvre Design Solutions
