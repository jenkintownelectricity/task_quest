# LDS-VOICE Platform Specification

**Multi-Tenant Architecture, RBAC, White-Labeling & Monetization**  
**Version**: 1.0.0  
**Date**: 2025-01-07  

---

## Overview

This specification transforms LDS-VOICE from a single-tenant system into a **multi-tenant platform** with:

- **LDS-Native RBAC** — Roles are versioned entities, not hidden database tables
- **White-Label Tenants** — Complete brand/voice/UI customization
- **Trust Dashboard** — Live compliance proof, not static security pages
- **Monetizable Audit** — Sell the guardrails, not the minutes

---

## 1. Multi-Tenant Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         LDS PLATFORM                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        SYSTEM ROOT                                   │   │
│  │  • Can create Tenants                                               │   │
│  │  • Can supersede Kernel logic                                       │   │
│  │  • Can provision HIPAA mode                                         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                │                                            │
│                ┌───────────────┼───────────────┐                           │
│                ▼               ▼               ▼                           │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐              │
│  │  TENANT A       │ │  TENANT B       │ │  TENANT C       │              │
│  │  "Aura Health"  │ │  "TechCorp"     │ │  "LegalAI"      │              │
│  │                 │ │                 │ │                 │              │
│  │  brand.*        │ │  brand.*        │ │  brand.*        │              │
│  │  voice.*        │ │  voice.*        │ │  voice.*        │              │
│  │  ui.*           │ │  ui.*           │ │  ui.*           │              │
│  │  policy.*       │ │  policy.*       │ │  policy.*       │              │
│  │  audit.*        │ │  audit.*        │ │  audit.*        │              │
│  └─────────────────┘ └─────────────────┘ └─────────────────┘              │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        SHARED KERNEL                                 │   │
│  │  • LDS Logic Engine                                                 │   │
│  │  • Breaker System                                                   │   │
│  │  • Compliance Framework                                             │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.1 Tenant Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:tenant/aura-health",
    "type": "tenant.profile",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:tenant-provisioner"
  },
  "vectors": {
    "category": ["tenant", "healthcare", "hipaa", "active"]
  },
  "core": {
    "tenant_id": "aura-health",
    "display_name": "Aura Health Concierge",
    "status": "active",
    
    "provisioned_at": "2025-01-07T00:00:00Z",
    "provisioned_by": "system:root",
    
    "tier": {
      "plan": "compliance",
      "monthly_base": 2500,
      "usage_multiplier": 1.3,
      "audit_retention_days": 2555,
      "features": [
        "hipaa_mode",
        "custom_voice",
        "legal_export",
        "dedicated_support"
      ]
    },
    
    "namespace": {
      "prefix": "lds:tenant/aura-health/",
      "allowed_entity_types": [
        "brand.*",
        "voice.*",
        "ui.*",
        "policy.*",
        "audit.*",
        "consent.*"
      ]
    },
    
    "compliance": {
      "hipaa_enabled": true,
      "soc2_mode": false,
      "data_residency": "us-east-1",
      "baa_signed": true,
      "baa_document_id": "BAA-AURA-2025-001"
    },
    
    "contacts": {
      "owner_email": "admin@aura.health",
      "billing_email": "billing@aura.health",
      "compliance_email": "privacy@aura.health"
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "isolated_namespace",
      "compliance_monitored",
      "audit_enabled"
    ],
    "conflicts_with": [],
    "requires": [
      "valid_subscription",
      "baa_if_hipaa"
    ]
  },
  "media": {
    "baa_document": "pdf://contracts/aura-health-baa.pdf"
  }
}
```

---

## 2. LDS-Native RBAC

### 2.1 The Philosophy

Traditional RBAC is a hidden database table. In LDS:

- **Roles are versioned entities**
- **Permission changes have a paper trail**
- **Access control is auditable**

### 2.2 Role Hierarchy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           ROLE HIERARCHY                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  SYSTEM ROOT                                                         │   │
│  │  • Can create Tenants                                               │   │
│  │  • Can supersede Kernel logic                                       │   │
│  │  • Can provision compliance modes (HIPAA, SOC2)                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                  │                                          │
│                                  ▼                                          │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  TENANT OWNER                                                        │   │
│  │  • Can supersede: brand.*, voice.*, ui.*, billing.*                 │   │
│  │  • Cannot touch: compliance.hipaa (only root can provision)         │   │
│  │  • Can assign: Content Manager, Compliance Officer                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                    │                              │                         │
│                    ▼                              ▼                         │
│  ┌─────────────────────────────┐  ┌─────────────────────────────────────┐ │
│  │  CONTENT MANAGER            │  │  COMPLIANCE OFFICER                 │ │
│  │  • Can supersede:           │  │  • Read-only access to:             │ │
│  │    voice.style              │  │    audit.*, consent.*               │ │
│  │    ui.theme                 │  │  • Can trigger:                     │ │
│  │  • Cannot touch:            │  │    revocation events                │ │
│  │    policy.*, audit.*        │  │  • Cannot supersede anything        │ │
│  └─────────────────────────────┘  └─────────────────────────────────────┘ │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.3 Role Definition Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:role/tenant-owner-v1",
    "type": "role.definition",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:rbac-manager"
  },
  "vectors": {
    "category": ["role", "tenant", "owner", "write-access"]
  },
  "core": {
    "role_name": "Tenant Owner",
    "role_code": "TENANT_OWNER",
    "description": "Full control over tenant brand, voice, and UI. Cannot modify compliance policies.",
    
    "permissions": {
      "can_supersede": [
        "brand.*",
        "voice.style",
        "voice.acoustic",
        "ui.theme",
        "ui.layout",
        "billing.*"
      ],
      "can_create": [
        "brand.*",
        "voice.*",
        "ui.*",
        "user.*"
      ],
      "can_read": [
        "*"
      ],
      "can_delete": [],
      "can_assign_roles": [
        "content-manager",
        "compliance-officer"
      ]
    },
    
    "forbidden": {
      "cannot_supersede": [
        "policy.hipaa",
        "policy.compliance",
        "kernel.*",
        "system.*"
      ],
      "cannot_create": [
        "tenant.*",
        "role.*"
      ],
      "cannot_read": [
        "system.secrets",
        "other_tenant.*"
      ]
    },
    
    "scope": {
      "tenant_bound": true,
      "cross_tenant": false
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "write_access",
      "tenant_scoped",
      "can_delegate"
    ],
    "conflicts_with": [
      "role:compliance-officer"
    ],
    "requires": [
      "active_tenant",
      "valid_subscription"
    ]
  },
  "media": {}
}
```

### 2.4 Content Manager Role

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:role/content-manager-v1",
    "type": "role.definition",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:rbac-manager"
  },
  "vectors": {
    "category": ["role", "tenant", "content", "limited-write"]
  },
  "core": {
    "role_name": "Content Manager",
    "role_code": "CONTENT_MANAGER",
    "description": "Can modify voice style and UI theme. Cannot touch policy or audit.",
    
    "permissions": {
      "can_supersede": [
        "voice.style",
        "ui.theme"
      ],
      "can_create": [
        "voice.style",
        "ui.theme"
      ],
      "can_read": [
        "brand.*",
        "voice.*",
        "ui.*"
      ],
      "can_delete": [],
      "can_assign_roles": []
    },
    
    "forbidden": {
      "cannot_supersede": [
        "policy.*",
        "audit.*",
        "consent.*",
        "brand.profile"
      ],
      "cannot_read": [
        "audit.*",
        "consent.*",
        "billing.*"
      ]
    },
    
    "scope": {
      "tenant_bound": true,
      "cross_tenant": false
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "limited_write_access",
      "content_focused"
    ],
    "conflicts_with": [],
    "requires": [
      "assigned_by_owner"
    ]
  },
  "media": {}
}
```

### 2.5 Compliance Officer Role

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:role/compliance-officer-v1",
    "type": "role.definition",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:rbac-manager"
  },
  "vectors": {
    "category": ["role", "tenant", "compliance", "read-only", "audit"]
  },
  "core": {
    "role_name": "Compliance Officer",
    "role_code": "COMPLIANCE_OFFICER",
    "description": "Read-only access to audit logs and consent records. Can trigger revocation events.",
    
    "permissions": {
      "can_supersede": [],
      "can_create": [
        "revocation.*",
        "audit.review"
      ],
      "can_read": [
        "audit.*",
        "consent.*",
        "policy.*",
        "compliance.*"
      ],
      "can_delete": [],
      "can_assign_roles": [],
      "special_actions": [
        "trigger_revocation",
        "export_audit_pdf",
        "request_compliance_report"
      ]
    },
    
    "forbidden": {
      "cannot_supersede": ["*"],
      "cannot_create": [
        "brand.*",
        "voice.*",
        "ui.*"
      ],
      "cannot_read": [
        "billing.*",
        "system.secrets"
      ]
    },
    
    "scope": {
      "tenant_bound": true,
      "cross_tenant": false
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "audit_access",
      "compliance_focused",
      "separation_of_duties"
    ],
    "conflicts_with": [
      "role:tenant-owner"
    ],
    "requires": [
      "compliance_training"
    ]
  },
  "media": {}
}
```

### 2.6 User Assignment Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:tenant/aura-health/user/sarah-chen",
    "type": "user.assignment",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "tenant:aura-health:admin"
  },
  "vectors": {
    "category": ["user", "assignment", "aura-health"]
  },
  "core": {
    "user_id": "sarah-chen",
    "email": "sarah.chen@aura.health",
    "display_name": "Dr. Sarah Chen",
    
    "tenant_id": "aura-health",
    
    "roles": [
      {
        "role_id": "lds:role/tenant-owner-v1",
        "assigned_at": "2025-01-07T00:00:00Z",
        "assigned_by": "system:root"
      }
    ],
    
    "status": "active",
    "last_login": "2025-01-07T12:00:00Z",
    
    "mfa_enabled": true,
    "sessions": []
  },
  "inference": {
    "relates_to": [
      "lds:tenant/aura-health",
      "lds:role/tenant-owner-v1"
    ],
    "implies": [
      "authenticated_user",
      "tenant_member"
    ],
    "conflicts_with": [],
    "requires": [
      "valid_email",
      "mfa_if_required"
    ]
  },
  "media": {}
}
```

---

## 3. White-Label System

### 3.1 Brand Profile Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:tenant/aura-health/brand/profile-v1",
    "type": "brand.profile",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "tenant:aura-health:owner"
  },
  "vectors": {
    "category": ["brand", "luxury", "medical", "high-touch"]
  },
  "core": {
    "brand_name": "Aura Concierge",
    "tagline": "Your Personal Health Navigator",
    
    "personality": {
      "tone": "empathetic-exclusive",
      "formality": "professional-warm",
      "patience_level": "infinite",
      "vocabulary": "sophisticated-accessible"
    },
    
    "voice_characteristics": {
      "speaking_pace": "measured",
      "pause_style": "thoughtful",
      "emphasis": "gentle",
      "emotional_range": "calm-reassuring"
    },
    
    "content_rules": {
      "always_use": [
        "patient's name when known",
        "empathetic acknowledgments",
        "clear next steps"
      ],
      "never_use": [
        "medical jargon without explanation",
        "dismissive language",
        "rushed responses"
      ],
      "greetings": {
        "morning": "Good morning. How may I assist you with your care today?",
        "afternoon": "Good afternoon. How may I help you?",
        "evening": "Good evening. What can I do for you?"
      }
    },
    
    "legal": {
      "company_name": "Aura Health Technologies, Inc.",
      "terms_url": "https://aura.health/terms",
      "privacy_url": "https://aura.health/privacy",
      "hipaa_notice": "https://aura.health/hipaa"
    },
    
    "signature": {
      "signed_by": "Dr. Sarah Chen",
      "signed_at": "2025-01-07T00:00:00Z",
      "role": "Chief Medical Officer"
    }
  },
  "inference": {
    "relates_to": [
      "lds:tenant/aura-health"
    ],
    "implies": [
      "luxury_experience",
      "high_touch_service",
      "medical_context"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {
    "logo_light": "https://aura.health/logo-light.svg",
    "logo_dark": "https://aura.health/logo-dark.svg",
    "favicon": "https://aura.health/favicon.ico"
  }
}
```

### 3.2 Voice Style Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:tenant/aura-health/voice/style-v1",
    "type": "voice.style",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "tenant:aura-health:owner"
  },
  "vectors": {
    "category": ["voice", "style", "luxury", "calm"]
  },
  "core": {
    "style_name": "Aura Calm",
    "description": "Soft, high-fidelity voice for luxury healthcare",
    
    "provider": "elevenlabs",
    "voice_id": "21m00Tcm4TlvDq8ikWAM",
    "voice_name": "Rachel",
    "model_id": "eleven_turbo_v2",
    
    "settings": {
      "stability": 0.8,
      "similarity_boost": 0.7,
      "style": 0.1,
      "speed": 0.9,
      "use_speaker_boost": true
    },
    
    "behavior": {
      "silence_behavior": "thoughtful_pause",
      "pause_after_greeting_ms": 500,
      "pause_before_sensitive_ms": 300,
      "breathing_room": true
    },
    
    "fallback": {
      "provider": "pyttsx3",
      "rate": 130,
      "voice_index": 0
    }
  },
  "inference": {
    "relates_to": [
      "lds:tenant/aura-health/brand/profile-v1"
    ],
    "implies": [
      "premium_voice",
      "calming_effect"
    ],
    "conflicts_with": [],
    "requires": [
      "elevenlabs_subscription"
    ]
  },
  "media": {
    "sample_audio": "audio://samples/aura-voice-demo.mp3"
  }
}
```

### 3.3 UI Theme Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:tenant/aura-health/ui/theme-v1",
    "type": "ui.theme",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "tenant:aura-health:owner"
  },
  "vectors": {
    "category": ["ui", "theme", "luxury", "medical"]
  },
  "core": {
    "theme_name": "Aura Navy Gold",
    "description": "Luxurious navy and gold theme for high-end medical concierge",
    
    "colors": {
      "primary": "#1A237E",
      "primary_light": "#534bae",
      "primary_dark": "#000051",
      "secondary": "#D4AF37",
      "secondary_light": "#ffdf6a",
      "secondary_dark": "#9e7f00",
      "background": "#FAFAFA",
      "surface": "#FFFFFF",
      "error": "#B00020",
      "success": "#2E7D32",
      "warning": "#ED6C02",
      "text_primary": "#212121",
      "text_secondary": "#757575",
      "text_on_primary": "#FFFFFF",
      "text_on_secondary": "#000000"
    },
    
    "typography": {
      "font_family": "'Cormorant Garamond', 'Georgia', serif",
      "font_family_mono": "'Fira Code', monospace",
      "heading_weight": 600,
      "body_weight": 400,
      "line_height": 1.6
    },
    
    "spacing": {
      "unit": 8,
      "container_max_width": 1200
    },
    
    "borders": {
      "radius_sm": 4,
      "radius_md": 8,
      "radius_lg": 16,
      "width": 1
    },
    
    "shadows": {
      "sm": "0 1px 2px rgba(0,0,0,0.05)",
      "md": "0 4px 6px rgba(0,0,0,0.1)",
      "lg": "0 10px 15px rgba(0,0,0,0.1)"
    },
    
    "components": {
      "button": {
        "border_radius": 8,
        "padding": "12px 24px",
        "font_weight": 500
      },
      "input": {
        "border_radius": 8,
        "border_color": "#E0E0E0",
        "focus_color": "#1A237E"
      },
      "card": {
        "border_radius": 16,
        "shadow": "md"
      }
    },
    
    "branding": {
      "logo_url": "https://aura.health/logo.svg",
      "logo_width": 120,
      "favicon_url": "https://aura.health/favicon.ico",
      "powered_by_visible": false
    }
  },
  "inference": {
    "relates_to": [
      "lds:tenant/aura-health/brand/profile-v1"
    ],
    "implies": [
      "luxury_aesthetic",
      "professional_appearance"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {
    "preview_image": "image://themes/aura-preview.png"
  }
}
```

### 3.4 Tenant Policy Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:tenant/aura-health/policy/compliance-v1",
    "type": "policy.compliance",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:root"
  },
  "vectors": {
    "category": ["policy", "compliance", "hipaa", "strict"]
  },
  "core": {
    "policy_name": "Aura Health Compliance Policy",
    
    "hipaa": {
      "mode": "strict",
      "enforced_by": "system:root",
      "baa_required": true,
      "phi_redaction": true,
      "ambient_safety": true,
      "audit_retention_years": 7
    },
    
    "consent": {
      "require_every_session": false,
      "require_for_phi": true,
      "consent_expiry_days": 365,
      "revocation_immediate": true
    },
    
    "marketing": {
      "allow_marketing": false,
      "allow_analytics": false,
      "allow_training_data": false
    },
    
    "data_handling": {
      "residency": "us-east-1",
      "encryption_at_rest": true,
      "encryption_in_transit": true,
      "backup_enabled": true,
      "backup_retention_days": 90
    },
    
    "voice": {
      "phi_over_voice_allowed": true,
      "require_headphones_for_phi": true,
      "require_private_confirmation": true
    }
  },
  "inference": {
    "relates_to": [
      "lds:tenant/aura-health"
    ],
    "implies": [
      "hipaa_compliant",
      "strict_privacy",
      "audit_enabled"
    ],
    "conflicts_with": [
      "marketing_mode"
    ],
    "requires": [
      "baa_signed",
      "compliance_tier"
    ]
  },
  "media": {}
}
```

---

## 4. Trust Dashboard

### 4.1 The Philosophy

Most companies have a static "Security" page. Yours is a **Live Logic Dashboard** that renders directly from the tenant's active LDS state.

**This proves you aren't a "black box" AI. You are a "glass box" system.**

### 4.2 Trust Dashboard Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:tenant/aura-health/trust/dashboard-v1",
    "type": "trust.dashboard",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:trust-generator"
  },
  "vectors": {
    "category": ["trust", "dashboard", "compliance", "public"]
  },
  "core": {
    "dashboard_title": "Verified Operational Logic",
    "tenant_id": "aura-health",
    "generated_at": "2025-01-07T12:00:00Z",
    
    "widgets": [
      {
        "id": "identity-provenance",
        "title": "Identity Provenance",
        "type": "provenance",
        "content": {
          "statement": "This agent is running on Aura Health v4 logic",
          "signed_by": "Dr. Sarah Chen",
          "signed_at": "2025-01-07T00:00:00Z",
          "role": "Chief Medical Officer"
        },
        "source_entity": "lds:tenant/aura-health/brand/profile-v1"
      },
      {
        "id": "no-hallucination",
        "title": "No-Hallucination Guarantee",
        "type": "guarantee",
        "content": {
          "reasoning_scope": "bounded",
          "external_knowledge": "disabled",
          "source_citations": "required",
          "hallucination_guard": "armed"
        },
        "source_entity": "lds:control/reasoning-scope-v1"
      },
      {
        "id": "compliance-state",
        "title": "Live Compliance State",
        "type": "compliance",
        "content": {
          "hipaa_mode": {"status": "active", "enforced_by": "system:root"},
          "encryption": {"status": "verified", "type": "AES-256"},
          "data_residency": {"region": "us-east-1", "location": "Virginia, USA"},
          "voice_privacy": {"status": "active", "redaction": "enabled"}
        },
        "source_entity": "lds:tenant/aura-health/policy/compliance-v1"
      },
      {
        "id": "audit-summary",
        "title": "Public Audit Log",
        "type": "audit",
        "content": {
          "recent_events": [
            {
              "timestamp": "14:02 PM",
              "event": "Refused query regarding [REDACTED] due to missing consent",
              "outcome": "denied"
            },
            {
              "timestamp": "14:05 PM",
              "event": "Answered coverage question citing Policy Document #442",
              "outcome": "success"
            }
          ],
          "total_queries_today": 47,
          "compliance_rate": "100%"
        },
        "source_entity": "lds:audit/*"
      }
    ],
    
    "public_url": "https://aura.health/trust",
    "embed_allowed": true,
    "refresh_interval_seconds": 60
  },
  "inference": {
    "relates_to": [
      "lds:tenant/aura-health/brand/profile-v1",
      "lds:tenant/aura-health/policy/compliance-v1"
    ],
    "implies": [
      "transparency",
      "verifiable_compliance",
      "glass_box_ai"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

---

## 5. Pricing & Monetization

### 5.1 Pricing Philosophy

> **Do not sell the minutes. Sell the Guardrails.**

You are selling **Risk Reduction** and **Operational Governance**.

### 5.2 Pricing Tiers

| Feature | Growth (SMB) | Compliance (Clinic) | Sovereign (Enterprise) |
|---------|--------------|---------------------|------------------------|
| **Price** | $499/mo + usage | $2,500/mo + usage | Custom ($50k+/yr) |
| **LDS History** | 30 Days | 7 Years (Legal) | Perpetual |
| **Compliance** | Standard | HIPAA / SOC2 | Custom Policy |
| **Voice** | Library (10) | Custom Cloned | Multi-Speaker |
| **Audit** | Admin View | Legal Export PDF | Real-time SIEM |
| **Support** | Email | Dedicated Engineer | BAA Signed |
| **White-Label** | Basic | Full | Complete |

### 5.3 Pricing Structure Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:pricing/tiers-v1",
    "type": "pricing.structure",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:billing"
  },
  "vectors": {
    "category": ["pricing", "monetization", "tiers"]
  },
  "core": {
    "tiers": [
      {
        "tier_id": "growth",
        "name": "Growth",
        "target": "SMB",
        "pricing": {
          "monthly_base": 499,
          "usage_multiplier": 1.3,
          "overage_per_minute": 0.05
        },
        "features": {
          "audit_retention_days": 30,
          "compliance_modes": ["standard"],
          "voice_library_size": 10,
          "custom_voice": false,
          "audit_export": false,
          "white_label": "basic",
          "support": "email",
          "sla": "99.5%"
        }
      },
      {
        "tier_id": "compliance",
        "name": "Compliance",
        "target": "Healthcare / Fintech",
        "pricing": {
          "monthly_base": 2500,
          "usage_multiplier": 1.3,
          "overage_per_minute": 0.04
        },
        "features": {
          "audit_retention_days": 2555,
          "compliance_modes": ["hipaa", "soc2"],
          "voice_library_size": 50,
          "custom_voice": true,
          "audit_export": true,
          "white_label": "full",
          "support": "dedicated",
          "sla": "99.9%",
          "baa_available": true
        }
      },
      {
        "tier_id": "sovereign",
        "name": "Sovereign",
        "target": "Enterprise",
        "pricing": {
          "annual_minimum": 50000,
          "custom_pricing": true
        },
        "features": {
          "audit_retention_days": -1,
          "compliance_modes": ["custom"],
          "voice_library_size": -1,
          "custom_voice": true,
          "multi_speaker": true,
          "audit_export": true,
          "siem_integration": true,
          "white_label": "complete",
          "support": "dedicated_team",
          "sla": "99.99%",
          "baa_available": true,
          "on_prem_option": true
        }
      }
    ],
    
    "add_ons": [
      {
        "addon_id": "audit-as-service",
        "name": "Audit-as-a-Service",
        "description": "Monthly PDF certificate proving AI operated within LDS bounds 100%",
        "monthly_price": 500,
        "available_tiers": ["compliance", "sovereign"]
      },
      {
        "addon_id": "custom-voice-training",
        "name": "Custom Voice Training",
        "description": "Train a custom voice model with LDS acoustic-profile",
        "setup_price": 5000,
        "monthly_price": 200,
        "available_tiers": ["compliance", "sovereign"]
      },
      {
        "addon_id": "white-label-complete",
        "name": "Complete White-Label License",
        "description": "Custom domain, 'Powered by' removal, custom integrations",
        "setup_price": 15000,
        "annual_license": 5000,
        "available_tiers": ["sovereign"]
      }
    ]
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "monetization_strategy",
      "tiered_pricing"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

---

## 6. Tenant Bootstrap Payload

### 6.1 Complete Bootstrap for "Aura Health"

```json
[
  {
    "_lds": { "id": "lds:tenant/aura-health", "type": "tenant.profile" },
    "core": {
      "tenant_id": "aura-health",
      "display_name": "Aura Health Concierge",
      "tier": { "plan": "compliance" },
      "compliance": { "hipaa_enabled": true, "baa_signed": true }
    }
  },
  {
    "_lds": { "id": "lds:tenant/aura-health/brand/profile-v1", "type": "brand.profile" },
    "vectors": { "category": ["luxury", "medical", "high-touch"] },
    "core": {
      "brand_name": "Aura Concierge",
      "personality": { "tone": "empathetic-exclusive", "patience_level": "infinite" },
      "signature": { "signed_by": "Dr. Sarah Chen", "role": "CMO" }
    }
  },
  {
    "_lds": { "id": "lds:tenant/aura-health/voice/style-v1", "type": "voice.style" },
    "core": {
      "provider": "elevenlabs",
      "voice_id": "21m00Tcm4TlvDq8ikWAM",
      "settings": { "stability": 0.8, "speed": 0.9 },
      "behavior": { "silence_behavior": "thoughtful_pause" }
    }
  },
  {
    "_lds": { "id": "lds:tenant/aura-health/ui/theme-v1", "type": "ui.theme" },
    "core": {
      "colors": { "primary": "#1A237E", "secondary": "#D4AF37", "background": "#FAFAFA" },
      "typography": { "font_family": "'Cormorant Garamond', serif" },
      "branding": { "logo_url": "https://aura.health/logo.svg", "powered_by_visible": false }
    }
  },
  {
    "_lds": { "id": "lds:tenant/aura-health/policy/compliance-v1", "type": "policy.compliance" },
    "core": {
      "hipaa": { "mode": "strict", "phi_redaction": true },
      "marketing": { "allow_marketing": false },
      "consent": { "require_for_phi": true }
    }
  }
]
```

### 6.2 Result

Instantly:
- Agent speaks slowly with premium voice
- Uses sophisticated vocabulary
- Wears navy and gold UI
- Refuses medical questions without verified patient ID
- Logs everything for HIPAA compliance

---

## 7. What You've Built

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      THE MONETIZATION MACHINE                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  1. INGESTS TRUTH (LDS Files)                                              │
│     └── Versioned, auditable, immutable                                    │
│                                                                             │
│  2. ENFORCES SAFETY (Kernel)                                               │
│     └── Breakers, consent, RBAC                                            │
│                                                                             │
│  3. PROJECTS BRAND (White-Labeling)                                        │
│     └── Voice, UI, personality                                             │
│                                                                             │
│  4. MONETIZES TRUST (Audit Logs)                                           │
│     └── Compliance certificates, SIEM feeds                                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

**End of Platform Specification**
