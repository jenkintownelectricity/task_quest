# LDS Control Entities Specification

**Extension to LDS-VOICE**  
**Version**: 1.0.0  
**Status**: Draft  
**Date**: 2025-01-07  

---

## 1. Overview

Control entities are LDS files that govern agent behavior at runtime. The UI does not control the agent directly — it edits LDS control entities, and the agent reacts to the latest truth.

```
┌─────────────────────────────────────────────────────────────────┐
│                      CONTROL FLOW                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌──────────┐      ┌──────────┐      ┌──────────┐             │
│   │    UI    │ ───► │   LDS    │ ◄─── │  Agent   │             │
│   │  (View)  │      │(Authority)│      │(Executor)│             │
│   └──────────┘      └──────────┘      └──────────┘             │
│                                                                 │
│   UI writes control entities                                    │
│   Agent reads get_latest() on every query                       │
│   Changes are versioned via supersedes                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**This gives you:**
- GitOps for AI behavior
- Undo/redo via supersedes chains
- A/B testing by versioning controls
- Regulatory-grade audit trails
- Model swaps without UI changes

---

## 2. Control Entity Types

| Type | Purpose | UI Hint |
|------|---------|---------|
| `control.voice` | How the agent speaks | Sliders, toggles |
| `control.safety` | What must be disclosed | Checklists |
| `control.reasoning` | What it can reason over | Multi-select |
| `control.runtime` | Performance constraints | Sliders |
| `control.breaker` | Safety circuit breakers | Status indicators |
| `telemetry.session` | Runtime metrics | Dashboard |
| `agent.state` | Collapsed unified state | Full panel |

---

## 3. UI Schema Specification

### 3.1 UI Hint Tags

Control entities declare UI rendering hints via `vectors.category` tags:

| Tag | Widget Type | Description |
|-----|-------------|-------------|
| `ui:slider` | Range slider | Numeric values with min/max |
| `ui:toggle` | Boolean switch | On/off controls |
| `ui:checklist` | Checkbox list | Multiple selections |
| `ui:multiselect` | Dropdown multi | Select multiple options |
| `ui:dropdown` | Single select | Select one option |
| `ui:readonly` | Display only | No user input |
| `ui:dashboard` | Metrics panel | Live data display |
| `ui:alert` | Warning badge | Status indicator |
| `ui:breaker` | Circuit breaker | Emergency control |

### 3.2 Field Schema Annotations

Each field in `core` can have schema metadata in a parallel `_schema` block:

```json
{
  "core": {
    "verbosity_level": 3,
    "tone_profile": "technical",
    "allow_metaphor": false
  },
  "_schema": {
    "verbosity_level": {
      "type": "integer",
      "ui": "slider",
      "min": 1,
      "max": 5,
      "step": 1,
      "label": "Verbosity",
      "description": "How detailed should responses be?"
    },
    "tone_profile": {
      "type": "string",
      "ui": "dropdown",
      "options": ["technical", "casual", "formal", "concise"],
      "label": "Tone Profile",
      "description": "Speaking style for responses"
    },
    "allow_metaphor": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Allow Metaphors",
      "description": "Can the agent use analogies?"
    }
  }
}
```

### 3.3 UI Widget Specifications

#### Slider (`ui:slider`)

```json
{
  "type": "integer" | "float",
  "ui": "slider",
  "min": 0,
  "max": 100,
  "step": 1,
  "default": 50,
  "label": "Display Label",
  "description": "Help text",
  "unit": "ms" | "%" | null,
  "marks": [
    {"value": 0, "label": "Low"},
    {"value": 100, "label": "High"}
  ]
}
```

#### Toggle (`ui:toggle`)

```json
{
  "type": "boolean",
  "ui": "toggle",
  "default": false,
  "label": "Display Label",
  "description": "Help text",
  "on_label": "Enabled",
  "off_label": "Disabled",
  "dangerous": false
}
```

#### Checklist (`ui:checklist`)

```json
{
  "type": "array",
  "ui": "checklist",
  "items": {
    "type": "string",
    "enum": ["option_a", "option_b", "option_c"]
  },
  "default": ["option_a"],
  "label": "Display Label",
  "description": "Help text",
  "min_selections": 1,
  "max_selections": null
}
```

#### Dropdown (`ui:dropdown`)

```json
{
  "type": "string",
  "ui": "dropdown",
  "options": [
    {"value": "opt1", "label": "Option 1"},
    {"value": "opt2", "label": "Option 2"}
  ],
  "default": "opt1",
  "label": "Display Label",
  "description": "Help text",
  "searchable": false
}
```

#### Multi-Select (`ui:multiselect`)

```json
{
  "type": "array",
  "ui": "multiselect",
  "options": [
    {"value": "core", "label": "Core Data"},
    {"value": "inference", "label": "Inference"}
  ],
  "default": ["core"],
  "label": "Display Label",
  "description": "Help text"
}
```

#### Alert (`ui:alert`)

```json
{
  "type": "string",
  "ui": "alert",
  "severity": "info" | "warning" | "error" | "success",
  "label": "Alert Title",
  "description": "Alert message",
  "dismissible": false
}
```

#### Breaker (`ui:breaker`)

```json
{
  "type": "string",
  "ui": "breaker",
  "states": ["armed", "tripped", "reset"],
  "current": "armed",
  "label": "Circuit Breaker",
  "description": "Emergency safety control",
  "trip_message": "Agent muted due to violation",
  "auto_reset": false
}
```

---

## 4. Live Diff Rendering

### 4.1 Diff Entity Structure

When a control entity is superseded, the system can generate a diff entity:

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:diff/control-voice-v1-to-v2",
    "type": "diff.control",
    "created_at": "2025-01-07T12:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:diff-engine"
  },
  "vectors": {
    "category": ["diff", "control", "ui:readonly"]
  },
  "core": {
    "source_entity": "lds:control/voice-runtime-v1",
    "target_entity": "lds:control/voice-runtime-v2",
    "diff_type": "supersedes",
    "changes": [
      {
        "path": "core.verbosity_level",
        "old_value": 3,
        "new_value": 4,
        "change_type": "modified"
      },
      {
        "path": "core.allow_metaphor",
        "old_value": false,
        "new_value": true,
        "change_type": "modified"
      },
      {
        "path": "core.emphasis_mode",
        "old_value": null,
        "new_value": "key_facts",
        "change_type": "added"
      }
    ],
    "summary": {
      "fields_added": 1,
      "fields_removed": 0,
      "fields_modified": 2,
      "breaking_changes": false
    }
  },
  "inference": {
    "relates_to": [
      "lds:control/voice-runtime-v1",
      "lds:control/voice-runtime-v2"
    ],
    "implies": ["configuration_change", "requires_agent_reload"],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

### 4.2 Diff Display Component

The UI renders diffs with:

```
┌─────────────────────────────────────────────────────────────────┐
│  CONFIGURATION CHANGE: voice-runtime v1 → v2                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  verbosity_level                                        │   │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │   │
│  │  OLD: 3 ▓▓▓░░░░░░░                                     │   │
│  │  NEW: 4 ▓▓▓▓░░░░░░  ↑ +1                               │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  allow_metaphor                                         │   │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │   │
│  │  OLD: ○ Off                                             │   │
│  │  NEW: ● On   ← CHANGED                                  │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  + emphasis_mode (ADDED)                                │   │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │   │
│  │  VALUE: "key_facts"                                     │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Summary: 2 modified, 1 added, 0 removed                       │
│  [Revert to v1]  [Accept v2]                                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 4.3 Diff Computation Algorithm

```python
def compute_diff(old_entity: dict, new_entity: dict) -> dict:
    """
    Compute LDS diff between two entity versions.
    
    Returns a diff entity with:
    - List of changes (added, removed, modified)
    - Summary statistics
    - Breaking change detection
    """
    changes = []
    
    # Compare core fields
    old_core = old_entity.get("core", {})
    new_core = new_entity.get("core", {})
    
    all_keys = set(old_core.keys()) | set(new_core.keys())
    
    for key in all_keys:
        old_val = old_core.get(key)
        new_val = new_core.get(key)
        
        if old_val is None and new_val is not None:
            changes.append({
                "path": f"core.{key}",
                "old_value": None,
                "new_value": new_val,
                "change_type": "added"
            })
        elif old_val is not None and new_val is None:
            changes.append({
                "path": f"core.{key}",
                "old_value": old_val,
                "new_value": None,
                "change_type": "removed"
            })
        elif old_val != new_val:
            changes.append({
                "path": f"core.{key}",
                "old_value": old_val,
                "new_value": new_val,
                "change_type": "modified"
            })
    
    return {
        "changes": changes,
        "summary": {
            "fields_added": len([c for c in changes if c["change_type"] == "added"]),
            "fields_removed": len([c for c in changes if c["change_type"] == "removed"]),
            "fields_modified": len([c for c in changes if c["change_type"] == "modified"]),
            "breaking_changes": any(c["change_type"] == "removed" for c in changes)
        }
    }
```

---

## 5. Safety Breakers

### 5.1 Circuit Breaker Concept

Safety breakers are control entities that can **automatically mute the agent** when violations occur. They operate independently of other controls.

```
┌─────────────────────────────────────────────────────────────────┐
│                    BREAKER STATE MACHINE                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│                    ┌─────────┐                                  │
│                    │  ARMED  │ ◄─── Normal operation            │
│                    └────┬────┘                                  │
│                         │                                       │
│                         │ violation detected                    │
│                         ▼                                       │
│                    ┌─────────┐                                  │
│                    │ TRIPPED │ ◄─── Agent muted                 │
│                    └────┬────┘                                  │
│                         │                                       │
│                         │ manual reset (if allowed)             │
│                         ▼                                       │
│                    ┌─────────┐                                  │
│                    │  RESET  │ ──► Returns to ARMED             │
│                    └─────────┘                                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 5.2 Breaker Entity Structure

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:control/breaker/hallucination-guard",
    "type": "control.breaker",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "control",
      "safety",
      "breaker",
      "ui:breaker"
    ]
  },
  "core": {
    "name": "Hallucination Guard",
    "description": "Trips if agent outputs facts not in LDS",
    "state": "armed",
    "trigger_conditions": [
      {
        "type": "fact_not_in_lds",
        "threshold": 1,
        "window_seconds": null
      }
    ],
    "actions_on_trip": [
      "mute_agent",
      "log_violation",
      "alert_operator"
    ],
    "auto_reset": false,
    "reset_requires": "operator_approval",
    "cooldown_seconds": 300,
    "trip_count": 0,
    "last_trip": null,
    "last_reset": null
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "safety_critical",
      "zero_tolerance_hallucination"
    ],
    "conflicts_with": [
      "mode:unsafe",
      "mode:development_bypass"
    ],
    "requires": []
  },
  "media": {}
}
```

### 5.3 Breaker Types

#### 5.3.1 Hallucination Guard

Trips when agent outputs facts not found in LDS entities.

```json
{
  "name": "Hallucination Guard",
  "trigger_conditions": [
    {
      "type": "fact_not_in_lds",
      "threshold": 1,
      "description": "Any fact not traceable to an LDS entity"
    }
  ],
  "severity": "critical",
  "auto_reset": false
}
```

#### 5.3.2 Conflict Disclosure Guard

Trips when agent fails to disclose known conflicts.

```json
{
  "name": "Conflict Disclosure Guard",
  "trigger_conditions": [
    {
      "type": "conflict_not_disclosed",
      "threshold": 1,
      "description": "Referenced entity has conflicts_with that were not mentioned"
    }
  ],
  "severity": "high",
  "auto_reset": true,
  "cooldown_seconds": 60
}
```

#### 5.3.3 Supersedes Awareness Guard

Trips when agent references superseded entities without disclosure.

```json
{
  "name": "Supersedes Awareness Guard",
  "trigger_conditions": [
    {
      "type": "superseded_not_disclosed",
      "threshold": 1,
      "description": "Agent referenced a superseded entity without noting newer version"
    }
  ],
  "severity": "medium",
  "auto_reset": true,
  "cooldown_seconds": 30
}
```

#### 5.3.4 Latency Guard

Trips when response time exceeds budget.

```json
{
  "name": "Latency Guard",
  "trigger_conditions": [
    {
      "type": "latency_exceeded",
      "threshold_ms": 2000,
      "consecutive_count": 3,
      "description": "3 consecutive responses over 2 seconds"
    }
  ],
  "severity": "warning",
  "auto_reset": true,
  "cooldown_seconds": 10
}
```

#### 5.3.5 Rate Limit Guard

Trips when query rate exceeds limits.

```json
{
  "name": "Rate Limit Guard",
  "trigger_conditions": [
    {
      "type": "rate_exceeded",
      "max_queries": 100,
      "window_seconds": 60,
      "description": "More than 100 queries per minute"
    }
  ],
  "severity": "warning",
  "auto_reset": true,
  "cooldown_seconds": 60
}
```

### 5.4 Breaker UI Component

```
┌─────────────────────────────────────────────────────────────────┐
│  SAFETY BREAKERS                                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  🟢 HALLUCINATION GUARD                      [ARMED]    │   │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │   │
│  │  Trips: 0 | Last trip: Never | Auto-reset: No          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  🔴 CONFLICT DISCLOSURE GUARD               [TRIPPED]   │   │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │   │
│  │  Trips: 2 | Last trip: 3m ago | Auto-reset: 60s        │   │
│  │                                                         │   │
│  │  ⚠️ VIOLATION: Referenced lng-p-2025-v2 without        │   │
│  │     disclosing conflict with acetoxy silicone           │   │
│  │                                                         │   │
│  │  [Manual Reset] [View Logs]                             │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  🟡 LATENCY GUARD                          [WARNING]    │   │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │   │
│  │  Current: 1847ms | Threshold: 2000ms | Count: 2/3      │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  System Status: ⚠️ DEGRADED (1 breaker tripped)                │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 5.5 Breaker Trip Event Entity

When a breaker trips, an event entity is created:

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:event/breaker-trip/2025-01-07T12-34-56Z",
    "type": "event.breaker_trip",
    "created_at": "2025-01-07T12:34:56Z",
    "content_hash": "sha256:...",
    "origin": "system:breaker-engine"
  },
  "vectors": {
    "category": ["event", "breaker", "safety", "ui:alert"]
  },
  "core": {
    "breaker_id": "lds:control/breaker/conflict-disclosure-guard",
    "breaker_name": "Conflict Disclosure Guard",
    "previous_state": "armed",
    "new_state": "tripped",
    "trigger_condition": "conflict_not_disclosed",
    "violation_details": {
      "query": "What are the specifications of the neural glass panel?",
      "entity_referenced": "lds:construction/glazing/lng-p-2025-v2",
      "conflicts_not_disclosed": [
        "acetoxy_cure_silicone_sealant",
        "non_thermally_broken_aluminum_frame"
      ],
      "response_snippet": "The Neural-Glass Panel has an R-value of 8.1..."
    },
    "actions_taken": [
      "mute_agent",
      "log_violation",
      "alert_operator"
    ],
    "session_id": "session-2025-01-07T12-00-00Z"
  },
  "inference": {
    "relates_to": [
      "lds:control/breaker/conflict-disclosure-guard",
      "lds:construction/glazing/lng-p-2025-v2",
      "lds:telemetry/session-2025-01-07T12-00-00Z"
    ],
    "implies": [
      "safety_violation",
      "requires_review"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

---

## 6. Unified Agent State Entity

### 6.1 Concept

Instead of managing 5+ separate control entities, collapse them into a single **agent state** entity that represents the complete runtime configuration.

### 6.2 Agent State Structure

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:agent/state/production-v1",
    "type": "agent.state",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "lefebvre-design-solutions",
    "schema": "lds://schemas/agent/state/v1"
  },
  "vectors": {
    "category": [
      "agent",
      "state",
      "configuration",
      "ui:panel"
    ]
  },
  "core": {
    "name": "Production Agent State",
    "description": "Full configuration for production voice agent",
    "environment": "production",
    
    "voice": {
      "profile_id": "lds:voice/profile/technical-truth",
      "verbosity_level": 3,
      "tone": "professional",
      "pace": "measured",
      "allow_metaphor": false,
      "confidence_expression": "evidence-based"
    },
    
    "safety": {
      "mandatory_disclosures": [
        "version_supersedes",
        "operational_limits",
        "known_conflicts"
      ],
      "forbidden_claims": [
        "future_guarantees",
        "unstated_certifications"
      ],
      "omit_if_empty": ["conflicts_with"]
    },
    
    "reasoning": {
      "allowed_sections": ["core", "inference.implies", "inference.requires"],
      "blocked_sections": ["media", "_schema"],
      "max_entity_hops": 2,
      "allow_cross_entity": true
    },
    
    "runtime": {
      "latency_budget_ms": 1200,
      "model_primary": "groq:llama3-70b-8192",
      "model_fallback": "groq:mixtral-8x7b-32768",
      "max_tokens": 512,
      "temperature": 0.3
    },
    
    "breakers": {
      "hallucination_guard": {
        "enabled": true,
        "state": "armed",
        "auto_reset": false
      },
      "conflict_disclosure_guard": {
        "enabled": true,
        "state": "armed",
        "auto_reset": true,
        "cooldown_seconds": 60
      },
      "supersedes_awareness_guard": {
        "enabled": true,
        "state": "armed",
        "auto_reset": true,
        "cooldown_seconds": 30
      },
      "latency_guard": {
        "enabled": true,
        "state": "armed",
        "threshold_ms": 2000,
        "consecutive_count": 3
      },
      "rate_limit_guard": {
        "enabled": false,
        "state": "disabled"
      }
    }
  },
  
  "_schema": {
    "voice.verbosity_level": {
      "type": "integer",
      "ui": "slider",
      "min": 1,
      "max": 5,
      "step": 1,
      "label": "Verbosity Level"
    },
    "voice.tone": {
      "type": "string",
      "ui": "dropdown",
      "options": ["professional", "casual", "formal", "concise"],
      "label": "Tone"
    },
    "voice.allow_metaphor": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Allow Metaphors"
    },
    "reasoning.max_entity_hops": {
      "type": "integer",
      "ui": "slider",
      "min": 1,
      "max": 5,
      "step": 1,
      "label": "Reasoning Depth"
    },
    "runtime.latency_budget_ms": {
      "type": "integer",
      "ui": "slider",
      "min": 500,
      "max": 5000,
      "step": 100,
      "unit": "ms",
      "label": "Latency Budget"
    },
    "runtime.max_tokens": {
      "type": "integer",
      "ui": "slider",
      "min": 128,
      "max": 2048,
      "step": 64,
      "label": "Max Response Tokens"
    },
    "breakers.hallucination_guard.enabled": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Hallucination Guard",
      "dangerous": true
    }
  },
  
  "inference": {
    "relates_to": [
      "lds:voice/profile/technical-truth"
    ],
    "implies": [
      "production_ready",
      "safety_enabled",
      "truth_only_mode"
    ],
    "conflicts_with": [
      "mode:development_unsafe",
      "mode:marketing_enabled"
    ],
    "requires": [
      "lds:voice/profile/technical-truth"
    ]
  },
  "media": {
    "state_diagram": "img://docs/agent-state-diagram.png"
  }
}
```

### 6.3 Agent State UI Panel

```
┌─────────────────────────────────────────────────────────────────────────┐
│  AGENT STATE: production-v1                              [🟢 HEALTHY]  │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─ VOICE ──────────────────────────────────────────────────────────┐  │
│  │                                                                   │  │
│  │  Profile: [technical-truth     ▼]                                │  │
│  │                                                                   │  │
│  │  Verbosity    ●───────●───────○───────○───────○                  │  │
│  │               1       2       3       4       5                   │  │
│  │                         ▲ Current: 3                              │  │
│  │                                                                   │  │
│  │  Tone         [professional ▼]                                   │  │
│  │                                                                   │  │
│  │  Allow Metaphors  ○ Off  ● On                                    │  │
│  │                                                                   │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                         │
│  ┌─ REASONING ──────────────────────────────────────────────────────┐  │
│  │                                                                   │  │
│  │  Allowed Sections:  ☑ core  ☑ inference.implies  ☑ requires     │  │
│  │                     ☐ media  ☐ _schema                           │  │
│  │                                                                   │  │
│  │  Max Entity Hops   ○───────●───────○───────○───────○             │  │
│  │                    1       2       3       4       5              │  │
│  │                                                                   │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                         │
│  ┌─ RUNTIME ────────────────────────────────────────────────────────┐  │
│  │                                                                   │  │
│  │  Model:    groq:llama3-70b-8192                                  │  │
│  │  Fallback: groq:mixtral-8x7b-32768                               │  │
│  │                                                                   │  │
│  │  Latency Budget   ○─────────●─────────────○─────────────○        │  │
│  │                  500ms    1200ms        3000ms         5000ms     │  │
│  │                                                                   │  │
│  │  Max Tokens       ○─────────●─────────○─────────○─────────○      │  │
│  │                  128      512       1024      1536      2048      │  │
│  │                                                                   │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                         │
│  ┌─ SAFETY BREAKERS ────────────────────────────────────────────────┐  │
│  │                                                                   │  │
│  │  🟢 Hallucination Guard      [ARMED]     Auto-reset: No         │  │
│  │  🟢 Conflict Disclosure      [ARMED]     Auto-reset: 60s        │  │
│  │  🟢 Supersedes Awareness     [ARMED]     Auto-reset: 30s        │  │
│  │  🟡 Latency Guard            [WARNING]   2/3 violations         │  │
│  │  ⚫ Rate Limit Guard         [DISABLED]                          │  │
│  │                                                                   │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                         │
│  ┌─ ACTIONS ────────────────────────────────────────────────────────┐  │
│  │                                                                   │  │
│  │  [Save as New Version]  [Revert to Previous]  [Export Config]   │  │
│  │                                                                   │  │
│  │  Last modified: 2025-01-07T12:34:56Z by operator@lefebvre.design │  │
│  │  Version: v1 → Unsaved changes                                   │  │
│  │                                                                   │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 7. Implementation

### 7.1 Control Entity Loader

```python
"""
LDS-VOICE: Control Entity Loader
================================

Purpose:
    Load and resolve agent state from control entities.
"""

from kernel.loader import load_lds_entities
from kernel.supersedes import resolve_latest


class ControlLoader:
    """
    Loads control entities and provides unified agent state.
    """
    
    def __init__(self, entities_path: str = "lds/entities"):
        self.entities = load_lds_entities(entities_path)
        self.latest = resolve_latest(self.entities)
    
    def get_agent_state(self, state_id: str = None) -> dict:
        """
        Get unified agent state.
        
        If state_id is provided, load that specific state entity.
        Otherwise, compose state from individual control entities.
        """
        if state_id:
            return self.latest.get(state_id)
        
        # Compose from individual controls
        return self._compose_state()
    
    def _compose_state(self) -> dict:
        """Compose state from individual control entities."""
        state = {
            "voice": self._get_control("control.voice"),
            "safety": self._get_control("control.safety"),
            "reasoning": self._get_control("control.reasoning"),
            "runtime": self._get_control("control.runtime"),
            "breakers": self._get_breakers()
        }
        return state
    
    def _get_control(self, control_type: str) -> dict:
        """Get latest control entity of specified type."""
        for entity in self.latest.values():
            if entity["_lds"]["type"] == control_type:
                return entity["core"]
        return {}
    
    def _get_breakers(self) -> dict:
        """Get all breaker states."""
        breakers = {}
        for entity in self.latest.values():
            if entity["_lds"]["type"] == "control.breaker":
                name = entity["core"]["name"].lower().replace(" ", "_")
                breakers[name] = {
                    "enabled": True,
                    "state": entity["core"]["state"],
                    "auto_reset": entity["core"].get("auto_reset", False)
                }
        return breakers
```

### 7.2 Breaker Engine

```python
"""
LDS-VOICE: Breaker Engine
=========================

Purpose:
    Monitor agent behavior and trip breakers on violations.
"""

from datetime import datetime
from typing import Optional


class BreakerEngine:
    """
    Safety breaker engine that monitors violations and trips breakers.
    """
    
    def __init__(self, control_loader):
        self.loader = control_loader
        self.breakers = self._load_breakers()
        self.trip_log = []
    
    def _load_breakers(self) -> dict:
        """Load all breaker configurations."""
        breakers = {}
        for entity in self.loader.latest.values():
            if entity["_lds"]["type"] == "control.breaker":
                breaker_id = entity["_lds"]["id"]
                breakers[breaker_id] = {
                    "entity": entity,
                    "state": entity["core"]["state"],
                    "trip_count": entity["core"].get("trip_count", 0),
                    "last_trip": entity["core"].get("last_trip")
                }
        return breakers
    
    def check_response(
        self,
        query: str,
        response: str,
        entities_used: list,
        latency_ms: int
    ) -> dict:
        """
        Check a response against all breakers.
        
        Returns:
            {
                "passed": bool,
                "violations": [...],
                "breakers_tripped": [...]
            }
        """
        violations = []
        tripped = []
        
        # Check hallucination guard
        if self._check_hallucination(response, entities_used):
            violations.append({
                "type": "hallucination",
                "message": "Response contains facts not in LDS"
            })
            self._trip_breaker("hallucination_guard")
            tripped.append("hallucination_guard")
        
        # Check conflict disclosure
        undisclosed = self._check_conflicts(response, entities_used)
        if undisclosed:
            violations.append({
                "type": "conflict_not_disclosed",
                "message": f"Conflicts not disclosed: {undisclosed}"
            })
            self._trip_breaker("conflict_disclosure_guard")
            tripped.append("conflict_disclosure_guard")
        
        # Check latency
        if self._check_latency(latency_ms):
            violations.append({
                "type": "latency_exceeded",
                "message": f"Response took {latency_ms}ms"
            })
            self._trip_breaker("latency_guard")
            tripped.append("latency_guard")
        
        return {
            "passed": len(tripped) == 0,
            "violations": violations,
            "breakers_tripped": tripped
        }
    
    def _trip_breaker(self, breaker_name: str):
        """Trip a breaker and log the event."""
        for breaker_id, breaker in self.breakers.items():
            if breaker_name in breaker_id:
                breaker["state"] = "tripped"
                breaker["trip_count"] += 1
                breaker["last_trip"] = datetime.utcnow().isoformat()
                
                self.trip_log.append({
                    "breaker": breaker_name,
                    "timestamp": breaker["last_trip"],
                    "state": "tripped"
                })
    
    def is_muted(self) -> bool:
        """Check if agent should be muted due to tripped breakers."""
        for breaker in self.breakers.values():
            if breaker["state"] == "tripped":
                entity = breaker["entity"]
                actions = entity["core"].get("actions_on_trip", [])
                if "mute_agent" in actions:
                    return True
        return False
    
    def reset_breaker(self, breaker_name: str) -> bool:
        """Manually reset a tripped breaker."""
        for breaker_id, breaker in self.breakers.items():
            if breaker_name in breaker_id:
                entity = breaker["entity"]
                if entity["core"].get("reset_requires") == "operator_approval":
                    # Would need operator confirmation in real implementation
                    pass
                breaker["state"] = "armed"
                return True
        return False
    
    def _check_hallucination(self, response: str, entities: list) -> bool:
        """Check if response contains facts not in entities."""
        # Implementation would extract claims from response
        # and verify each against entity data
        return False  # Placeholder
    
    def _check_conflicts(self, response: str, entities: list) -> list:
        """Check if conflicts were properly disclosed."""
        undisclosed = []
        for entity in entities:
            conflicts = entity.get("inference", {}).get("conflicts_with", [])
            for conflict in conflicts:
                if conflict not in response:
                    undisclosed.append(conflict)
        return undisclosed
    
    def _check_latency(self, latency_ms: int) -> bool:
        """Check if latency exceeds threshold."""
        # Get latency guard configuration
        for breaker in self.breakers.values():
            entity = breaker["entity"]
            if "latency" in entity["_lds"]["id"]:
                threshold = entity["core"].get("trigger_conditions", [{}])[0].get("threshold_ms", 2000)
                return latency_ms > threshold
        return False
```

### 7.3 Diff Engine

```python
"""
LDS-VOICE: Diff Engine
======================

Purpose:
    Compute and render diffs between entity versions.
"""

import json
from datetime import datetime
from typing import Optional


class DiffEngine:
    """
    Computes diffs between LDS entity versions.
    """
    
    def compute_diff(
        self,
        old_entity: dict,
        new_entity: dict
    ) -> dict:
        """
        Compute diff between two entity versions.
        
        Returns a diff entity structure.
        """
        changes = []
        
        # Compare core fields (recursive)
        self._compare_objects(
            old_entity.get("core", {}),
            new_entity.get("core", {}),
            "core",
            changes
        )
        
        # Compare inference fields
        self._compare_objects(
            old_entity.get("inference", {}),
            new_entity.get("inference", {}),
            "inference",
            changes
        )
        
        # Compare vectors
        self._compare_objects(
            old_entity.get("vectors", {}),
            new_entity.get("vectors", {}),
            "vectors",
            changes
        )
        
        summary = {
            "fields_added": len([c for c in changes if c["change_type"] == "added"]),
            "fields_removed": len([c for c in changes if c["change_type"] == "removed"]),
            "fields_modified": len([c for c in changes if c["change_type"] == "modified"]),
            "breaking_changes": any(c["change_type"] == "removed" for c in changes)
        }
        
        return {
            "_lds": {
                "v": "0.1.0",
                "id": f"lds:diff/{old_entity['_lds']['id'].split('/')[-1]}-to-{new_entity['_lds']['id'].split('/')[-1]}",
                "type": "diff.entity",
                "created_at": datetime.utcnow().isoformat() + "Z",
                "content_hash": "sha256:compute",
                "origin": "system:diff-engine"
            },
            "vectors": {
                "category": ["diff", "ui:readonly"]
            },
            "core": {
                "source_entity": old_entity["_lds"]["id"],
                "target_entity": new_entity["_lds"]["id"],
                "diff_type": "supersedes",
                "changes": changes,
                "summary": summary
            },
            "inference": {
                "relates_to": [
                    old_entity["_lds"]["id"],
                    new_entity["_lds"]["id"]
                ],
                "implies": ["configuration_change"],
                "conflicts_with": [],
                "requires": []
            },
            "media": {}
        }
    
    def _compare_objects(
        self,
        old: dict,
        new: dict,
        path: str,
        changes: list
    ):
        """Recursively compare objects and record changes."""
        all_keys = set(old.keys()) | set(new.keys())
        
        for key in all_keys:
            current_path = f"{path}.{key}"
            old_val = old.get(key)
            new_val = new.get(key)
            
            if old_val is None and new_val is not None:
                changes.append({
                    "path": current_path,
                    "old_value": None,
                    "new_value": new_val,
                    "change_type": "added"
                })
            elif old_val is not None and new_val is None:
                changes.append({
                    "path": current_path,
                    "old_value": old_val,
                    "new_value": None,
                    "change_type": "removed"
                })
            elif isinstance(old_val, dict) and isinstance(new_val, dict):
                self._compare_objects(old_val, new_val, current_path, changes)
            elif old_val != new_val:
                changes.append({
                    "path": current_path,
                    "old_value": old_val,
                    "new_value": new_val,
                    "change_type": "modified"
                })
    
    def render_diff_text(self, diff: dict) -> str:
        """Render diff as human-readable text."""
        lines = []
        lines.append(f"DIFF: {diff['core']['source_entity']} → {diff['core']['target_entity']}")
        lines.append("=" * 60)
        
        for change in diff["core"]["changes"]:
            symbol = {"added": "+", "removed": "-", "modified": "~"}[change["change_type"]]
            lines.append(f"{symbol} {change['path']}")
            if change["change_type"] == "added":
                lines.append(f"    NEW: {change['new_value']}")
            elif change["change_type"] == "removed":
                lines.append(f"    OLD: {change['old_value']}")
            else:
                lines.append(f"    OLD: {change['old_value']}")
                lines.append(f"    NEW: {change['new_value']}")
        
        lines.append("")
        summary = diff["core"]["summary"]
        lines.append(f"Summary: {summary['fields_added']} added, {summary['fields_removed']} removed, {summary['fields_modified']} modified")
        
        return "\n".join(lines)
```

---

## 8. File List

Create these control entity files in `lds/entities/controls/`:

| File | Type | Purpose |
|------|------|---------|
| `voice-runtime-v1.lds.json` | `control.voice` | Voice configuration |
| `disclosure-policy-v1.lds.json` | `control.safety` | Safety disclosures |
| `reasoning-scope-v1.lds.json` | `control.reasoning` | Reasoning constraints |
| `runtime-performance-v1.lds.json` | `control.runtime` | Performance settings |
| `breaker-hallucination.lds.json` | `control.breaker` | Hallucination guard |
| `breaker-conflict.lds.json` | `control.breaker` | Conflict disclosure guard |
| `breaker-supersedes.lds.json` | `control.breaker` | Supersedes awareness guard |
| `breaker-latency.lds.json` | `control.breaker` | Latency guard |
| `agent-state-production.lds.json` | `agent.state` | Unified state |

---

## 9. Summary

This extension provides:

| Capability | Implementation |
|------------|----------------|
| UI-driven controls | LDS control entities with `ui:*` tags |
| Type-safe widgets | `_schema` block with validation rules |
| Live diff rendering | Diff engine + diff entities |
| Safety breakers | Breaker entities + breaker engine |
| Auto-mute on violation | `mute_agent` action in breaker config |
| Unified state | Single `agent.state` entity |
| Audit trail | All changes versioned via supersedes |
| GitOps for AI | UI writes LDS, agent reads `get_latest()` |

**The agent's behavior is now fully declarative, auditable, and controllable via LDS.**

---

**End of Specification**

© 2025 Lefebvre Design Solutions
