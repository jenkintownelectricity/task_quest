# LDS Domain Schema: Assembly

**Schema ID**: `lds://schemas/construction/assembly/v1`  
**Version**: 1.0.0  
**Status**: Draft  

---

## 1. Purpose

This schema defines the structure for **assembly** entities in the construction domain. An assembly is a composite entity that combines multiple materials, components, or sub-assemblies into an installable unit.

---

## 2. Type Classification

Assemblies MUST use one of the following `type` values:

| Type | Description |
|------|-------------|
| `glazing_assembly` | Window, curtain wall, or facade glass units |
| `structural_assembly` | Beam-column connections, trusses, frames |
| `mechanical_assembly` | HVAC units, pump packages, ductwork |
| `electrical_assembly` | Panel boards, switchgear, distribution |
| `plumbing_assembly` | Fixture groups, riser assemblies |

Custom types MAY be used with the pattern: `assembly:<domain>/<subtype>`

---

## 3. Vectors Schema

### 3.1 Category Requirements

For assembly entities, `vectors.category` MUST include:

1. At least one **domain tag**: `construction:glazing`, `construction:structural`, etc.
2. At least one **assembly type tag**: `assembly:active`, `assembly:passive`, `assembly:composite`
3. At least one **material tag**: `material:steel`, `material:aluminum`, `material:glass`

Example:
```json
"category": [
  "construction:glazing",
  "assembly:active",
  "material:aluminum-thermally-broken",
  "material:electrochromic-glass"
]
```

### 3.2 Spatial Requirements

Assemblies with physical dimensions SHOULD include spatial vectors:

```json
"spatial": {
  "origin": [0, 0, 0],
  "bounds": [[x_min, y_min, z_min], [x_max, y_max, z_max]],
  "coordinate_system": "cartesian"
}
```

Units: Millimeters (mm)

### 3.3 Temporal Requirements

Assemblies SHOULD include installation phase information:

```json
"temporal": {
  "install_phase": 4,
  "sequence": 15
}
```

---

## 4. Core Schema

### 4.1 Required Fields

| Field | Type | Description |
|-------|------|-------------|
| `name` | string | Human-readable assembly name |
| `manufacturer` | string | Originating company |

### 4.2 BOM Structure (Recommended)

Assemblies SHOULD include a Bill of Materials structure:

```json
"bom_structure": [
  {
    "role": "string",           // REQUIRED: functional role
    "material_type": "string",  // REQUIRED: material classification
    "description": "string",    // OPTIONAL: human-readable
    "quantity": number,         // OPTIONAL: count or measure
    "unit": "string"            // OPTIONAL: unit of measure
  }
]
```

**Role values** (standardized):
- `active_layer` — functional/smart component
- `frame` — structural support
- `seal` — weatherproofing
- `anchor` — connection to structure
- `insulation` — thermal barrier
- `finish` — aesthetic layer

### 4.3 Prohibited in Core

Per LDS Spec §3.3.1:
- NO LDS identifiers (use `inference.relates_to` instead)
- NO probabilistic values
- NO AI-generated content

---

## 5. Inference Schema

### 5.1 Required Relationships

Assemblies MUST declare in `inference.relates_to`:
- All constituent material entities
- Compatible framing/support systems
- Required control systems (if active)

### 5.2 Required Prerequisites

Assemblies MUST declare in `inference.requires`:
- Personnel certifications
- Equipment requirements
- Permits
- Site conditions

### 5.3 Conflict Declaration

Assemblies SHOULD declare in `inference.conflicts_with`:
- Incompatible materials (galvanic, chemical)
- Structural limitations (seismic, wind)
- Environmental constraints

### 5.4 Implication Declaration

Assemblies SHOULD declare in `inference.implies`:
- Required trades
- System integrations
- Downstream requirements

---

## 6. Media Schema

Assemblies SHOULD include:

| Key | URI Scheme | Description |
|-----|------------|-------------|
| `spec_sheet` | `pdf://` | Technical specifications |
| `cad_model_2d` | `dwg://` | Elevation/section drawings |
| `cad_model_3d` | `dwg://` or `lds://` | 3D model reference |
| `bim_object` | `dwg://` | IFC or Revit family |
| `installation_manual` | `pdf://` | Install instructions |
| `installation_video` | `vid://` | Visual guide |

---

## 7. Validation Rules

A conforming assembly entity:

1. ✓ Has `type` matching assembly pattern
2. ✓ Has at least 3 category tags (domain, assembly type, material)
3. ✓ Has no LDS refs in `core`
4. ✓ Has at least 1 entry in `inference.relates_to`
5. ✓ Has at least 1 entry in `inference.requires`
6. ✓ References constituent materials via `inference.relates_to`

---

## 8. Example

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:construction/assembly/curtain-wall-unit-cw-4500",
    "type": "glazing_assembly",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "acme-glazing-corp",
    "schema": "lds://schemas/construction/assembly/v1"
  },
  "vectors": {
    "category": [
      "construction:glazing",
      "assembly:composite",
      "material:aluminum-thermally-broken",
      "material:insulated-glass"
    ],
    "spatial": {
      "origin": [0, 0, 0],
      "bounds": [[0, 0, 0], [1500, 2500, 150]]
    },
    "temporal": {
      "install_phase": 4,
      "sequence": 10
    },
    "causal": []
  },
  "core": {
    "name": "Curtain Wall Unit CW-4500",
    "manufacturer": "ACME Glazing Corp",
    "bom_structure": [
      {
        "role": "frame",
        "material_type": "aluminum_6063_t6_thermally_broken",
        "quantity": 1,
        "unit": "set"
      },
      {
        "role": "active_layer",
        "material_type": "insulated_glass_unit",
        "quantity": 1,
        "unit": "panel"
      },
      {
        "role": "seal",
        "material_type": "epdm_gasket",
        "quantity": 4,
        "unit": "linear_m"
      }
    ]
  },
  "inference": {
    "relates_to": [
      "lds:construction/material/aluminum-extrusion-6063-t6",
      "lds:construction/glazing/igu-double-low-e",
      "lds:construction/sealant/epdm-gasket-standard"
    ],
    "implies": [
      "trade:glazier",
      "trade:ironworker"
    ],
    "conflicts_with": [
      "seismic_design_category_f",
      "wind_zone_4_unprotected"
    ],
    "requires": [
      "lds:construction/personnel/certified-glazier",
      "lds:construction/equipment/boom-lift-40ft"
    ]
  },
  "media": {
    "spec_sheet": "pdf://acme/cw4500/specifications.pdf",
    "cad_model_3d": "dwg://acme/cw4500/assembly.rvt"
  }
}
```

---

**End of Schema**

© 2025 Lefebvre Design Solutions
