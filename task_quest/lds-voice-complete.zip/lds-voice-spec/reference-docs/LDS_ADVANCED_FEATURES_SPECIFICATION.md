# LDS-VOICE Advanced Features Specification

**Tier 1-2 Features: Memory, Explainability, Contextual Routing**  
**Version**: 1.0.0  
**Date**: 2025-01-07  

---

## Overview

This specification adds three features that put LDS-VOICE years ahead of typical agent frameworks:

| Feature | Tier | What It Unlocks |
|---------|------|-----------------|
| **Episodic Memory** | 1 | Continuity without "AI remembers things I didn't ask it to" |
| **Why Am I Saying This?** | 1 | Explainability that no chatbot has |
| **Contextual Voice Routing** | 2 | One agent, many personas, zero prompts |

---

## 1. Episodic Memory (LDS-Based)

### 1.1 Core Concept

Traditional AI memory is dangerous:
- It hallucinates memories
- It makes assumptions
- It can't be audited
- It can't be revoked

LDS episodic memory is:
- **Explicit** — only stores what's declared
- **Revocable** — can be deleted on demand
- **Non-assumptive** — never interprets or summarizes
- **Time-bounded** — TTL or supersedes required
- **Scoped** — session, user, or context-specific

### 1.2 Memory Entity Types

```
lds:memory/episodic           — Single memory fact
lds:memory/session            — Session-scoped collection
lds:memory/preference         — User preference (persistent)
lds:memory/context            — Conversation context
```

### 1.3 Episodic Memory Entity Structure

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:memory/episodic/session-001-fact-001",
    "type": "memory.episodic",
    "created_at": "2025-01-07T12:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:memory-engine",
    "expires_at": "2025-01-07T14:00:00Z"
  },
  "vectors": {
    "category": [
      "memory",
      "episodic",
      "session-scoped",
      "auto-expire"
    ]
  },
  "core": {
    "session_id": "session-2025-01-07T10-00-00Z",
    "memory_type": "entity_reference",
    "content": {
      "type": "last_referenced_entity",
      "entity_id": "lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2",
      "timestamp": "2025-01-07T12:00:00Z"
    },
    "source": {
      "trigger": "user_query",
      "query": "What is the R-value of the neural glass panel?"
    },
    "ttl_seconds": 7200,
    "revocable": true
  },
  "inference": {
    "relates_to": [
      "lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2"
    ],
    "implies": [
      "recent_context",
      "may_be_referenced_again"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

### 1.4 User Preference Memory

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:memory/preference/user-001-verbosity",
    "type": "memory.preference",
    "created_at": "2025-01-07T12:00:00Z",
    "content_hash": "sha256:...",
    "origin": "user:explicit-request"
  },
  "vectors": {
    "category": [
      "memory",
      "preference",
      "user-scoped",
      "persistent"
    ]
  },
  "core": {
    "user_id": "user-001",
    "preference_type": "response_style",
    "preference": {
      "key": "verbosity",
      "value": "concise",
      "user_statement": "Keep answers short"
    },
    "source": {
      "trigger": "explicit_user_request",
      "original_text": "Please keep your answers short from now on",
      "timestamp": "2025-01-07T12:00:00Z"
    },
    "scope": "persistent",
    "revocable": true,
    "revocation_phrase": "Go back to normal answers"
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "reduce_verbosity",
      "prioritize_brevity"
    ],
    "conflicts_with": [
      "preference:detailed_responses"
    ],
    "requires": []
  },
  "media": {}
}
```

### 1.5 Session Context Memory

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:memory/context/session-001",
    "type": "memory.context",
    "created_at": "2025-01-07T10:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:session-manager"
  },
  "vectors": {
    "category": [
      "memory",
      "context",
      "session"
    ]
  },
  "core": {
    "session_id": "session-2025-01-07T10-00-00Z",
    "started_at": "2025-01-07T10:00:00Z",
    "last_activity": "2025-01-07T12:30:00Z",
    
    "entities_referenced": [
      {
        "entity_id": "lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2",
        "first_referenced": "2025-01-07T10:05:00Z",
        "reference_count": 3
      }
    ],
    
    "unresolved_questions": [
      {
        "question": "What about the installation timeline?",
        "asked_at": "2025-01-07T12:30:00Z",
        "reason_unresolved": "no_matching_entity"
      }
    ],
    
    "active_preferences": [
      "lds:memory/preference/user-001-verbosity"
    ],
    
    "persona_switches": [
      {
        "from": "lds:voice/profile/technical-truth",
        "to": "lds:voice/profile/site-superintendent",
        "at": "2025-01-07T11:00:00Z"
      }
    ]
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "active_session",
      "has_context"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

### 1.6 Memory Rules (NON-NEGOTIABLE)

| Rule | Enforcement |
|------|-------------|
| No interpretation | Memory stores exact facts, never summaries |
| No inference | Memory doesn't "figure out" what user wants |
| Explicit source | Every memory must have a trigger source |
| TTL or supersedes | No eternal memories without explicit approval |
| Revocable | User can always say "forget that" |
| Auditable | Every memory action is logged |

### 1.7 Memory Control Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:control/memory-policy-v1",
    "type": "control.memory",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "control",
      "memory",
      "policy"
    ]
  },
  "core": {
    "memory_enabled": true,
    
    "allowed_memory_types": [
      "entity_reference",
      "user_preference",
      "unresolved_question",
      "persona_switch"
    ],
    
    "forbidden_memory_types": [
      "user_summary",
      "inferred_intent",
      "personality_profile",
      "behavioral_pattern"
    ],
    
    "retention": {
      "episodic_ttl_seconds": 7200,
      "preference_ttl_seconds": null,
      "context_ttl_seconds": 86400,
      "max_memories_per_session": 100
    },
    
    "user_controls": {
      "can_view_memories": true,
      "can_delete_memories": true,
      "can_disable_memory": true,
      "forget_phrase": "forget that",
      "clear_phrase": "clear all memory"
    }
  },
  "_schema": {
    "memory_enabled": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Memory Enabled",
      "description": "Allow agent to remember context"
    },
    "retention.episodic_ttl_seconds": {
      "type": "integer",
      "ui": "slider",
      "min": 300,
      "max": 86400,
      "default": 7200,
      "unit": "s",
      "label": "Episodic Memory TTL"
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "memory_bounded",
      "user_controlled"
    ],
    "conflicts_with": [
      "unbounded_memory",
      "hidden_memory"
    ],
    "requires": []
  },
  "media": {}
}
```

---

## 2. "Why Am I Saying This?" Mode

### 2.1 Core Concept

Most AI systems are black boxes. When asked "why did you say that?", they either:
- Make up a reason (hallucination)
- Refuse to explain
- Give vague non-answers

LDS-VOICE can answer this question **precisely** because:
- Every fact comes from an LDS entity
- Every policy decision is in a profile
- Every version change is in a supersedes chain
- Every inference rule is explicit

### 2.2 Explainability Modes

| Mode | Trigger | Output |
|------|---------|--------|
| **Inline** | Automatic | Citations in response |
| **On-Demand** | "Why did you say that?" | Full trace |
| **Verbose** | /explain mode | Every fact traced |
| **Audit** | System log | Complete provenance |

### 2.3 Trace Entity Structure

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:trace/response/2025-01-07T12-00-00Z-001",
    "type": "trace.response",
    "created_at": "2025-01-07T12:00:01Z",
    "content_hash": "sha256:...",
    "origin": "system:trace-engine"
  },
  "vectors": {
    "category": [
      "trace",
      "response",
      "audit"
    ]
  },
  "core": {
    "session_id": "session-2025-01-07T10-00-00Z",
    "query_id": "query-2025-01-07T12-00-00Z",
    
    "user_query": "What is the R-value of the neural glass panel?",
    "response_text": "The Neural-Glass Panel has an R-value of 8.1...",
    
    "entities_used": [
      {
        "entity_id": "lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2",
        "entity_type": "material.photonic.glass",
        "sections_accessed": ["core.thermal_performance", "inference.conflicts_with"],
        "is_latest": true,
        "supersedes": "lds:lefebvre/material/neural-glass-panel-lng-p-2025"
      }
    ],
    
    "facts_extracted": [
      {
        "fact": "R-value is 8.1",
        "source": "core.thermal_performance.r_value",
        "entity_id": "lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2",
        "verbatim": false
      },
      {
        "fact": "Conflicts with acetoxy cure silicone",
        "source": "inference.conflicts_with[0]",
        "entity_id": "lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2",
        "verbatim": true
      }
    ],
    
    "policy_applied": {
      "voice_profile_id": "lds:voice/profile/technical-truth",
      "profile_implications": [
        "no_marketing_language",
        "include_conflicts_when_present",
        "cite_source_entity"
      ],
      "facts_included": ["thermal_performance", "conflicts_with"],
      "facts_excluded": ["unit_cost", "roi"]
    },
    
    "inference_chain": [
      {
        "step": 1,
        "rule": "always_include thermal_performance",
        "result": "included r_value: 8.1"
      },
      {
        "step": 2,
        "rule": "include_when_relevant conflicts_with",
        "result": "included 3 conflicts"
      },
      {
        "step": 3,
        "rule": "no_marketing_language",
        "result": "filtered superlatives"
      }
    ],
    
    "version_context": {
      "is_superseded": false,
      "supersedes_chain": [
        "lds:lefebvre/material/neural-glass-panel-lng-p-2025",
        "lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2"
      ],
      "version_disclosed": true
    },
    
    "confidence": {
      "score": 0.95,
      "factors": {
        "entity_coverage": 1.0,
        "inference_certainty": 0.9,
        "no_conflicts": true
      }
    }
  },
  "inference": {
    "relates_to": [
      "lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2",
      "lds:voice/profile/technical-truth"
    ],
    "implies": [
      "fully_traceable",
      "audit_ready"
    ],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

### 2.4 "Why?" Response Format

When user asks "Why did you say that?":

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  WHY I SAID THAT                                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  YOUR QUESTION:                                                             │
│  "What is the R-value of the neural glass panel?"                          │
│                                                                             │
│  SOURCES USED:                                                              │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                                                             │
│  📄 Entity: lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2         │
│     Type: material.photonic.glass                                           │
│     Version: v2 (supersedes v1)                                             │
│                                                                             │
│  FACTS EXTRACTED:                                                           │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                                                             │
│  ✓ "R-value is 8.1"                                                        │
│    ← core.thermal_performance.r_value                                       │
│                                                                             │
│  ✓ "Conflicts with acetoxy cure silicone"                                  │
│    ← inference.conflicts_with[0]                                            │
│                                                                             │
│  POLICY APPLIED:                                                            │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                                                             │
│  📋 Voice Profile: lds:voice/profile/technical-truth                        │
│                                                                             │
│  Rules Applied:                                                             │
│  • always_include: thermal_performance ✓                                    │
│  • include_when_relevant: conflicts_with ✓                                  │
│  • never_include: unit_cost, roi (filtered out)                            │
│  • no_marketing_language (filtered superlatives)                           │
│                                                                             │
│  VERSION INFO:                                                              │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ │
│                                                                             │
│  v1 (2025-01-07) ──superseded by──► v2 (2025-03-15) ← USED                 │
│                                                                             │
│  Changes in v2:                                                             │
│  • R-value: 7.2 → 8.1 (+12.5%)                                             │
│  • Added PHIUS certification                                                │
│                                                                             │
│  CONFIDENCE: 95%                                                            │
│  • Entity coverage: 100%                                                    │
│  • Inference certainty: 90%                                                 │
│  • No unresolved conflicts                                                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.5 Explainability Control Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:control/explainability-v1",
    "type": "control.explainability",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "control",
      "explainability",
      "audit"
    ]
  },
  "core": {
    "trace_enabled": true,
    "trace_retention_hours": 168,
    
    "inline_citations": {
      "enabled": true,
      "format": "entity_id",
      "verbosity": "minimal"
    },
    
    "on_demand_explain": {
      "enabled": true,
      "trigger_phrases": [
        "why did you say that",
        "explain that",
        "where did that come from",
        "cite your sources"
      ],
      "include_supersedes_chain": true,
      "include_policy_rules": true,
      "include_confidence": true
    },
    
    "verbose_mode": {
      "enabled": true,
      "command": "/explain",
      "shows_all_facts": true,
      "shows_filtered_facts": true
    },
    
    "audit_log": {
      "enabled": true,
      "log_all_traces": true,
      "retention_days": 90
    }
  },
  "_schema": {
    "trace_enabled": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Response Tracing",
      "description": "Track sources for all responses"
    },
    "inline_citations.enabled": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Inline Citations",
      "description": "Include source references in responses"
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "full_traceability",
      "audit_ready",
      "user_trust"
    ],
    "conflicts_with": [
      "black_box_mode"
    ],
    "requires": []
  },
  "media": {}
}
```

---

## 3. Contextual Voice Routing

### 3.1 Core Concept

Instead of manual persona switching:

```
USER: "What about installation?"
AGENT: [automatically switches to superintendent voice]
```

The routing is based on:
- Entity category vectors
- Query intent
- Context signals
- Explicit rules (not ML inference)

### 3.2 Routing Strategy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    CONTEXTUAL VOICE ROUTING                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Query: "How do I install this?"                                            │
│         │                                                                   │
│         ▼                                                                   │
│  ┌─────────────────┐                                                        │
│  │ Intent Parser   │                                                        │
│  │ → installation  │                                                        │
│  └────────┬────────┘                                                        │
│           │                                                                 │
│           ▼                                                                 │
│  ┌─────────────────┐                                                        │
│  │ Entity Matcher  │                                                        │
│  │ → glazing_assembly │                                                     │
│  │ → category: installation, field │                                        │
│  └────────┬────────┘                                                        │
│           │                                                                 │
│           ▼                                                                 │
│  ┌─────────────────┐     ┌─────────────────────────────────────────────┐   │
│  │ Route Resolver  │ ──► │ ROUTING RULES                               │   │
│  └────────┬────────┘     │                                             │   │
│           │              │ IF category contains "installation"        │   │
│           │              │    OR intent is "how_to_install"           │   │
│           │              │    OR context is "field"                    │   │
│           │              │ THEN use voice:site-superintendent          │   │
│           │              │                                             │   │
│           │              │ IF category contains "marketing"            │   │
│           │              │    OR category contains "sales"             │   │
│           │              │ THEN use voice:BLOCKED (safety)             │   │
│           │              │                                             │   │
│           │              │ DEFAULT: voice:technical-truth              │   │
│           │              └─────────────────────────────────────────────┘   │
│           │                                                                 │
│           ▼                                                                 │
│  ┌─────────────────┐                                                        │
│  │ Selected Voice  │                                                        │
│  │ → site-superintendent │                                                  │
│  └─────────────────┘                                                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.3 Voice Route Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:control/voice-routing-v1",
    "type": "control.voice_routing",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "control",
      "voice",
      "routing",
      "automatic"
    ]
  },
  "core": {
    "routing_enabled": true,
    "default_voice": "lds:voice/profile/technical-truth",
    
    "routes": [
      {
        "id": "route-installation",
        "name": "Installation Context",
        "priority": 10,
        "conditions": {
          "any": [
            {"category_contains": "installation"},
            {"category_contains": "field"},
            {"category_contains": "construction-site"},
            {"intent_matches": "how_to_install"},
            {"intent_matches": "installation_requirements"},
            {"query_contains": ["install", "installing", "installation"]}
          ]
        },
        "voice_id": "lds:voice/profile/site-superintendent",
        "announce_switch": false
      },
      {
        "id": "route-specifications",
        "name": "Technical Specifications",
        "priority": 20,
        "conditions": {
          "any": [
            {"category_contains": "specifications"},
            {"category_contains": "engineering"},
            {"category_contains": "physics"},
            {"intent_matches": "get_specifications"},
            {"query_contains": ["r-value", "u-value", "efficiency", "thermal"]}
          ]
        },
        "voice_id": "lds:voice/profile/technical-truth",
        "announce_switch": false
      },
      {
        "id": "route-marketing-block",
        "name": "Marketing Block",
        "priority": 1,
        "conditions": {
          "any": [
            {"category_contains": "marketing"},
            {"category_contains": "sales"},
            {"intent_matches": "get_price"},
            {"intent_matches": "roi_projection"}
          ]
        },
        "voice_id": null,
        "action": "block",
        "block_message": "I can provide technical specifications but not marketing or pricing information."
      },
      {
        "id": "route-safety-critical",
        "name": "Safety Critical",
        "priority": 5,
        "conditions": {
          "any": [
            {"has_conflicts": true},
            {"category_contains": "safety"},
            {"category_contains": "warning"}
          ]
        },
        "voice_id": "lds:voice/profile/site-superintendent",
        "voice_override": {
          "emphasis_mode": "warnings_first",
          "verbosity": "detailed_on_conflicts"
        },
        "announce_switch": true,
        "announcement": "Switching to safety-focused mode."
      }
    ],
    
    "intent_keywords": {
      "how_to_install": ["install", "installing", "installation", "set up", "mount", "attach"],
      "get_specifications": ["spec", "specs", "specifications", "what is", "tell me about", "r-value", "u-value"],
      "installation_requirements": ["need", "require", "requirements", "prerequisites", "before installing"],
      "get_price": ["price", "cost", "how much", "pricing", "quote"],
      "roi_projection": ["roi", "return", "payback", "investment"]
    },
    
    "fallback_behavior": {
      "on_no_match": "use_default",
      "on_conflict": "use_highest_priority",
      "on_blocked": "explain_and_offer_alternative"
    }
  },
  "_schema": {
    "routing_enabled": {
      "type": "boolean",
      "ui": "toggle",
      "label": "Automatic Voice Routing",
      "description": "Automatically select voice based on context"
    }
  },
  "inference": {
    "relates_to": [
      "lds:voice/profile/technical-truth",
      "lds:voice/profile/site-superintendent"
    ],
    "implies": [
      "automatic_persona_selection",
      "context_aware",
      "zero_prompt_switching"
    ],
    "conflicts_with": [
      "manual_only_switching"
    ],
    "requires": []
  },
  "media": {}
}
```

### 3.4 Route Resolution Algorithm

```python
def resolve_voice_route(
    query: str,
    entity: dict,
    context: dict,
    routing_config: dict
) -> tuple[str, dict]:
    """
    Resolve which voice to use based on context.
    
    Returns:
        (voice_id, route_info)
    """
    routes = routing_config["core"]["routes"]
    intent_keywords = routing_config["core"]["intent_keywords"]
    
    # Sort by priority (lower = higher priority)
    sorted_routes = sorted(routes, key=lambda r: r["priority"])
    
    entity_categories = entity.get("vectors", {}).get("category", [])
    has_conflicts = bool(entity.get("inference", {}).get("conflicts_with"))
    
    for route in sorted_routes:
        conditions = route["conditions"]
        matched = False
        
        # Check "any" conditions
        for condition in conditions.get("any", []):
            if "category_contains" in condition:
                if condition["category_contains"] in entity_categories:
                    matched = True
                    break
            
            elif "intent_matches" in condition:
                intent = condition["intent_matches"]
                keywords = intent_keywords.get(intent, [])
                if any(kw in query.lower() for kw in keywords):
                    matched = True
                    break
            
            elif "query_contains" in condition:
                if any(term in query.lower() for term in condition["query_contains"]):
                    matched = True
                    break
            
            elif "has_conflicts" in condition:
                if has_conflicts == condition["has_conflicts"]:
                    matched = True
                    break
        
        if matched:
            return route.get("voice_id"), route
    
    # No match - use default
    return routing_config["core"]["default_voice"], None
```

### 3.5 Route Switch Event

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:event/voice-route/2025-01-07T12-00-00Z",
    "type": "event.voice_route",
    "created_at": "2025-01-07T12:00:00Z",
    "content_hash": "sha256:...",
    "origin": "system:route-resolver"
  },
  "vectors": {
    "category": ["event", "voice", "routing"]
  },
  "core": {
    "session_id": "session-2025-01-07T10-00-00Z",
    "query": "How do I install the neural glass panel?",
    
    "route_matched": {
      "route_id": "route-installation",
      "route_name": "Installation Context",
      "condition_matched": "query_contains: install"
    },
    
    "voice_selected": "lds:voice/profile/site-superintendent",
    "previous_voice": "lds:voice/profile/technical-truth",
    
    "entity_context": {
      "entity_id": "lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2",
      "categories": ["smart-glass", "bipv", "gen-2-cigs"]
    },
    
    "announced": false
  },
  "inference": {
    "relates_to": [],
    "implies": ["automatic_switch", "context_based"],
    "conflicts_with": [],
    "requires": []
  },
  "media": {}
}
```

---

## 4. Confidence & Uncertainty Meter

### 4.1 Core Concept

The agent should know — and disclose — how certain it is. Confidence is computed from:

| Factor | Weight | Source |
|--------|--------|--------|
| Entity coverage | 40% | Did we find matching entities? |
| Fact completeness | 25% | Are all requested facts present? |
| Inference certainty | 20% | Are there conflicting implications? |
| Version freshness | 15% | Is this the latest version? |

### 4.2 Confidence Entity

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:control/confidence-threshold-v1",
    "type": "control.confidence",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "control",
      "confidence",
      "quality"
    ]
  },
  "core": {
    "thresholds": {
      "high": 0.85,
      "medium": 0.60,
      "low": 0.40
    },
    
    "disclosure_rules": {
      "below_high": {
        "disclose": true,
        "message_template": "Based on available data (confidence: {score}%)..."
      },
      "below_medium": {
        "disclose": true,
        "message_template": "I have limited information on this (confidence: {score}%). {gaps}"
      },
      "below_low": {
        "disclose": true,
        "suggest_alternative": true,
        "message_template": "I don't have sufficient data to answer confidently. {suggestion}"
      }
    },
    
    "computation": {
      "entity_coverage_weight": 0.40,
      "fact_completeness_weight": 0.25,
      "inference_certainty_weight": 0.20,
      "version_freshness_weight": 0.15
    },
    
    "gap_detection": {
      "enabled": true,
      "report_missing_fields": true,
      "report_unresolved_references": true,
      "report_superseded_without_update": true
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "honest_uncertainty",
      "quality_aware"
    ],
    "conflicts_with": [
      "overconfident_mode"
    ],
    "requires": []
  },
  "media": {}
}
```

---

## 5. Implementation Summary

### 5.1 New Entity Types

| Type | Purpose |
|------|---------|
| `memory.episodic` | Single memory fact |
| `memory.preference` | User preference |
| `memory.context` | Session context |
| `trace.response` | Response provenance |
| `event.voice_route` | Route switch event |
| `control.memory` | Memory policy |
| `control.explainability` | Trace settings |
| `control.voice_routing` | Route rules |
| `control.confidence` | Certainty thresholds |

### 5.2 New Commands

| Command | Function |
|---------|----------|
| `/why` | Explain last response |
| `/memory` | View current memories |
| `/forget` | Clear specific memory |
| `/clear` | Clear all session memory |
| `/route` | Show current voice route |
| `/confidence` | Show confidence breakdown |

### 5.3 Automatic Behaviors

| Trigger | Behavior |
|---------|----------|
| Entity with `installation` category | Route to superintendent voice |
| Response below 60% confidence | Disclose uncertainty |
| User says "why did you say that" | Show full trace |
| Session idle > TTL | Clear episodic memory |
| Entity has conflicts | Always disclose |

---

## 6. What This Unlocks

| Feature | Capability | Competitors Have This? |
|---------|------------|------------------------|
| **Episodic Memory** | Continuity without hallucination | ❌ |
| **Why Mode** | Full explainability | ❌ |
| **Contextual Routing** | Zero-prompt persona switching | ❌ |
| **Confidence Meter** | Honest uncertainty | ❌ |
| **Memory Revocation** | User control over AI memory | ❌ |
| **Audit Trail** | Complete provenance | ❌ |

**You're now years ahead of most agent frameworks.**

---

**End of Specification**
