# LDS-VOICE Build Package

**Version**: 1.0.0  
**Date**: 2025-01-07  
**Author**: Lefebvre Design Solutions  

---

## Package Contents

### Build Specifications

| File | Description |
|------|-------------|
| `LDS_VOICE_BUILD_SPECIFICATION.md` | Complete enterprise build specification |
| `CLAUDE_CODE_QUICK_START.md` | Condensed prompt for immediate action |

### Seed Data: Materials

| File | Entity ID | Version |
|------|-----------|---------|
| `seed-data/materials/neural-glass-v1.lds.json` | `lds:lefebvre/material/neural-glass-panel-lng-p-2025` | v1 (superseded) |
| `seed-data/materials/neural-glass-v2.lds.json` | `lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2` | v2 (current) |

### Seed Data: Assemblies

| File | Entity ID | Version |
|------|-----------|---------|
| `seed-data/assemblies/glazing-assembly-v1.lds.json` | `lds:construction/glazing/lefebvre-neural-glass-panel-lng-p-2025` | v1 (superseded) |
| `seed-data/assemblies/glazing-assembly-v2.lds.json` | `lds:construction/glazing/lng-p-2025-v2` | v2 (current) |

### Seed Data: Marketing

| File | Entity ID | Version |
|------|-----------|---------|
| `seed-data/marketing/marketing-profile-v1.lds.json` | `lds:lefebvre/product/lng-p-2025-marketing` | v1 (superseded) |
| `seed-data/marketing/marketing-profile-v2.lds.json` | `lds:lefebvre/product/lng-p-2025-marketing-v2` | v2 (current) |

### Seed Data: Voice Profiles

| File | Entity ID | Purpose |
|------|-----------|---------|
| `seed-data/profiles/voice-technical-truth.lds.json` | `lds:voice/profile/technical-truth` | Engineering voice, no marketing |
| `seed-data/profiles/voice-superintendent.lds.json` | `lds:voice/profile/site-superintendent` | Field voice, action-oriented |

### Seed Data: Revision Sets

| File | Entity ID | Entities Covered |
|------|-----------|------------------|
| `seed-data/revision-sets/lng-p-2025-gen2-release.lds.json` | `lds:lefebvre/revision-set/lng-p-2025-gen2-release` | Material v2, Marketing v2, Assembly v2 |

### Seed Data: Control Entities

| File | Entity ID | Type | Purpose |
|------|-----------|------|---------|
| `seed-data/controls/voice-runtime-v1.lds.json` | `lds:control/voice-runtime-v1` | `control.voice` | Voice & expression settings |
| `seed-data/controls/disclosure-policy-v1.lds.json` | `lds:control/disclosure-policy-v1` | `control.safety` | Safety & disclosure rules |
| `seed-data/controls/reasoning-scope-v1.lds.json` | `lds:control/reasoning-scope-v1` | `control.reasoning` | Reasoning boundaries |
| `seed-data/controls/runtime-performance-v1.lds.json` | `lds:control/runtime-performance-v1` | `control.runtime` | Performance settings |
| `seed-data/controls/breaker-hallucination.lds.json` | `lds:control/breaker/hallucination-guard` | `control.breaker` | Zero-tolerance hallucination guard |
| `seed-data/controls/breaker-conflict.lds.json` | `lds:control/breaker/conflict-disclosure-guard` | `control.breaker` | Conflict disclosure guard |
| `seed-data/controls/breaker-supersedes.lds.json` | `lds:control/breaker/supersedes-awareness-guard` | `control.breaker` | Version awareness guard |
| `seed-data/controls/breaker-latency.lds.json` | `lds:control/breaker/latency-guard` | `control.breaker` | Performance guard |
| `seed-data/controls/agent-state-production.lds.json` | `lds:agent/state/production-v1` | `agent.state` | Unified agent state |

### Reference Documentation

| File | Description |
|------|-------------|
| `reference-docs/LDS_SPECIFICATION_v0.1.0.md` | Complete LDS format specification |
| `reference-docs/LOGIC_KERNEL_ARCHITECTURE_v0.1.0.md` | Kernel architecture specification |
| `reference-docs/WHY_LDS_EXISTS.md` | Technical position paper |
| `reference-docs/ASSEMBLY_SCHEMA_v1.md` | Domain schema for assemblies |
| `reference-docs/SUPERSEDES_CHAIN_STRATEGY.md` | Version management strategy |
| `reference-docs/LDS_CONTROL_ENTITIES_SPECIFICATION.md` | UI schema, breakers, agent state |

---

## How to Use This Package

### Option 1: Claude Code (Recommended)

1. Open Claude Code
2. Create a new project
3. Copy the contents of `CLAUDE_CODE_QUICK_START.md` as your first prompt
4. Claude Code will build the complete system
5. Copy all files from `seed-data/` to the generated `lds/entities/` directory

### Option 2: Manual Build

1. Read `LDS_VOICE_BUILD_SPECIFICATION.md` completely
2. Follow the build phases in order
3. Use `reference-docs/` for LDS format details
4. Use `seed-data/` as your initial entity corpus

---

## Verification

After building, verify with these checks:

```bash
# Run tests
pytest tests/ -v

# Validate all entities
python scripts/validate_corpus.py

# Start in terminal mode
python main.py --mode terminal --profile technical-truth

# Test query
> What is the R-value of the neural glass panel?
# Should respond with: 8.1 (from v2 entity)
```

---

## Entity Graph

```
┌─────────────────────────────────────────────────────────────────────┐
│                    LNG-P-2025 ENTITY GRAPH                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  v1 Layer (Superseded)          v2 Layer (Current)                 │
│  ════════════════════          ═══════════════════                 │
│                                                                     │
│  material-v1 ─────────────────► material-v2                        │
│       │                              │                              │
│       │ relates_to                   │ relates_to                   │
│       ▼                              ▼                              │
│  marketing-v1 ────────────────► marketing-v2                       │
│       │                              │                              │
│       │ relates_to                   │ relates_to                   │
│       ▼                              ▼                              │
│  assembly-v1 ─────────────────► assembly-v2                        │
│                                      │                              │
│                                      │ member_of                    │
│                                      ▼                              │
│                               revision-set                          │
│                          (lng-p-2025-gen2-release)                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Voice Profile Comparison

| Attribute | Technical Truth | Superintendent |
|-----------|-----------------|----------------|
| Tone | Professional | Direct |
| Verbosity | Detailed | Concise |
| R-value | ✅ Always | ⚠️ When asked |
| Conflicts | ✅ When relevant | ✅ Always |
| Requirements | ✅ When relevant | ✅ Always |
| Pricing | ❌ Never | ❌ Never |
| Physics details | ✅ Always | ❌ Never |
| Units | Imperial + Metric | Imperial only |

---

## Entity Count

| Category | Count |
|----------|-------|
| Materials | 2 (v1 + v2) |
| Assemblies | 2 (v1 + v2) |
| Marketing | 2 (v1 + v2) |
| Voice Profiles | 2 |
| Revision Sets | 1 |
| Control Entities | 4 |
| Safety Breakers | 4 |
| Agent State | 1 |
| **Total** | **18** |

---

## Control System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    CONTROL ARCHITECTURE                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌──────────┐      ┌──────────┐      ┌──────────┐             │
│   │    UI    │ ───► │   LDS    │ ◄─── │  Agent   │             │
│   │  (View)  │      │(Authority)│      │(Executor)│             │
│   └──────────┘      └──────────┘      └──────────┘             │
│                                                                 │
│   UI writes control entities                                    │
│   Agent reads get_latest() on every query                       │
│   Changes are versioned via supersedes                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Safety Breakers

| Breaker | Severity | Auto-Reset | Action |
|---------|----------|------------|--------|
| Hallucination Guard | Critical | No | Mute agent |
| Conflict Disclosure | High | 60s | Mute agent |
| Supersedes Awareness | Medium | 30s | Warn user |
| Latency Guard | Warning | 10s | Switch model |

### UI Widget Types

| Tag | Widget | Usage |
|-----|--------|-------|
| `ui:slider` | Range slider | Numeric values |
| `ui:toggle` | Boolean switch | On/off |
| `ui:dropdown` | Single select | Options |
| `ui:checklist` | Multi-checkbox | Lists |
| `ui:multiselect` | Multi-dropdown | Arrays |
| `ui:breaker` | Circuit breaker | Safety |
| `ui:alert` | Warning badge | Status |

---

## Support

For questions about LDS-VOICE:
- Review the build specification
- Check reference documentation
- Verify entity hashes match

**Lefebvre Design Solutions**  
*Building the future of construction intelligence.*
