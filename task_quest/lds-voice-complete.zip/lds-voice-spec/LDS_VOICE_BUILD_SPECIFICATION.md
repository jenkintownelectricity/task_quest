# LDS-VOICE: Claude Code Build Specification

**Project**: LDS-VOICE (Logic Data System Voice Agent)  
**Version**: 1.0.0  
**Classification**: Internal / Engineering  
**Author**: Lefebvre Design Solutions  
**Date**: 2025-01-07  

---

## EXECUTIVE SUMMARY

You are building **LDS-VOICE**, a voice-enabled AI agent that speaks only from pre-computed truth stored in LDS (Logic Data System) files. 

**The core principle is non-negotiable:**
> The LLM never decides what is true. It only renders what LDS already knows.

This is not a chatbot. This is a **truth-rendering agent**.

---

## TABLE OF CONTENTS

1. [Project Overview](#1-project-overview)
2. [Architecture](#2-architecture)
3. [Directory Structure](#3-directory-structure)
4. [LDS Specification](#4-lds-specification)
5. [Build Instructions](#5-build-instructions)
6. [Documentation Requirements](#6-documentation-requirements)
7. [Testing Requirements](#7-testing-requirements)
8. [Seed Data](#8-seed-data)

---

## 1. PROJECT OVERVIEW

### 1.1 What LDS-VOICE Does

```
User speaks → Microphone
Speech → Text (Whisper)
Text → LDS Logic Kernel (truth lookup)
LDS → Structured facts + deltas
Facts → Voice Policy (filtering)
Policy → Groq LLM (render only, no invention)
Text → Speech (TTS)
Agent speaks back WITHOUT hallucinating
```

### 1.2 Why This Matters

Traditional voice agents hallucinate because:
- The LLM decides what is true
- No ground truth source
- No audit trail
- No version control

LDS-VOICE solves this by:
- Pre-computing all truth in LDS files
- LLM only renders, never invents
- Complete audit trail via content hashes
- Version control via supersedes chains

### 1.3 Target Use Cases

- Construction site voice assistant
- Technical specification lookup
- Material compatibility queries
- Safety requirement verification
- Change order impact analysis

---

## 2. ARCHITECTURE

### 2.1 System Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           LDS-VOICE SYSTEM                              │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌──────────────┐      ┌──────────────┐      ┌──────────────┐          │
│  │   AUDIO IN   │      │   AUDIO OUT  │      │   TERMINAL   │          │
│  │  (Whisper)   │      │    (TTS)     │      │   (Fallback) │          │
│  └──────┬───────┘      └──────▲───────┘      └──────▲───────┘          │
│         │                     │                     │                   │
│         ▼                     │                     │                   │
│  ┌──────────────────────────────────────────────────────────┐          │
│  │                      AGENT LOOP                          │          │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐         │          │
│  │  │   Parse    │→ │   Query    │→ │   Render   │         │          │
│  │  │   Intent   │  │   Kernel   │  │   Response │         │          │
│  │  └────────────┘  └─────┬──────┘  └─────▲──────┘         │          │
│  └────────────────────────┼───────────────┼─────────────────┘          │
│                           │               │                             │
│                           ▼               │                             │
│  ┌──────────────────────────────────────────────────────────┐          │
│  │                    LOGIC KERNEL                          │          │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐         │          │
│  │  │   Loader   │→ │ Supersedes │→ │  Inference │         │          │
│  │  │            │  │  Resolver  │  │  Extractor │         │          │
│  │  └─────┬──────┘  └────────────┘  └─────┬──────┘         │          │
│  │        │                               │                 │          │
│  │        ▼                               ▼                 │          │
│  │  ┌────────────┐                 ┌────────────┐          │          │
│  │  │   Entity   │                 │   Voice    │          │          │
│  │  │   Store    │                 │   Policy   │──────────┼──────────┤
│  │  └────────────┘                 └────────────┘          │          │
│  └──────────────────────────────────────────────────────────┘          │
│                                                                         │
│  ┌──────────────────────────────────────────────────────────┐          │
│  │                    LDS FILE STORAGE                      │          │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐     │          │
│  │  │ Entity  │  │ Entity  │  │ Voice   │  │ Schema  │     │          │
│  │  │   v1    │  │   v2    │  │ Profile │  │  Defs   │     │          │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────┘     │          │
│  └──────────────────────────────────────────────────────────┘          │
│                                                                         │
│  ┌──────────────────────────────────────────────────────────┐          │
│  │                    GROQ LLM (RENDERER)                   │          │
│  │                                                          │          │
│  │  Input: Structured facts from Voice Policy               │          │
│  │  Output: Natural language (no new facts added)           │          │
│  │  Model: llama3-70b-8192                                  │          │
│  │                                                          │          │
│  └──────────────────────────────────────────────────────────┘          │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Data Flow

```
1. USER INPUT
   "What's the R-value of the neural glass panel?"
   
2. INTENT PARSING
   { entity: "neural-glass", attribute: "r_value" }
   
3. KERNEL QUERY
   kernel.get_latest("lds:construction/glazing/lng-p-2025")
   → Returns v2 entity with R-value: 8.1
   
4. INFERENCE EXTRACTION
   { r_value: 8.1, implies: [...], conflicts: [...] }
   
5. VOICE POLICY
   Filter based on voice-technical-truth profile
   { r_value: 8.1, include_conflicts: true }
   
6. LLM RENDERING
   "The Neural-Glass Panel has an R-value of 8.1..."
   
7. TTS OUTPUT
   Agent speaks the response
```

### 2.3 Key Constraints

| Constraint | Enforcement |
|------------|-------------|
| LLM cannot invent facts | System prompt + structured input only |
| All truth from LDS | No external data sources |
| Version awareness | Supersedes chain resolution |
| Audit trail | Content hashes on all entities |
| Voice profile control | Policy filters what can be spoken |

---

## 3. DIRECTORY STRUCTURE

Create exactly this structure:

```
lds-voice/
├── README.md                          # Project documentation
├── CHANGELOG.md                       # Version history
├── requirements.txt                   # Python dependencies
├── .env.example                       # Environment template
├── .gitignore                         # Git ignore rules
│
├── docs/                              # Documentation
│   ├── ARCHITECTURE.md                # System architecture
│   ├── LDS_SPECIFICATION.md           # LDS format spec
│   ├── API_REFERENCE.md               # Internal API docs
│   ├── VOICE_POLICY_GUIDE.md          # Voice profile guide
│   └── DEPLOYMENT.md                  # Deployment guide
│
├── lds/                               # LDS Data Layer
│   ├── entities/                      # LDS entity files
│   │   ├── materials/                 # Material entities
│   │   ├── assemblies/                # Assembly entities
│   │   ├── marketing/                 # Marketing entities
│   │   ├── profiles/                  # Voice profiles
│   │   └── revision-sets/             # Revision sets
│   ├── schemas/                       # Domain schemas
│   └── index.json                     # Entity index (auto-generated)
│
├── kernel/                            # Logic Kernel
│   ├── __init__.py
│   ├── loader.py                      # LDS file loader
│   ├── validator.py                   # LDS validation
│   ├── hasher.py                      # Content hash computation
│   ├── supersedes.py                  # Version resolution
│   ├── inference.py                   # Inference extraction
│   ├── indexer.py                     # Category indexing
│   ├── query.py                       # Query engine
│   └── diff.py                        # Version diff
│
├── voice/                             # Voice Layer
│   ├── __init__.py
│   ├── policy.py                      # Voice policy engine
│   ├── intent.py                      # Intent parsing
│   └── composer.py                    # Response composition
│
├── audio/                             # Audio Layer
│   ├── __init__.py
│   ├── stt.py                         # Speech-to-text
│   └── tts.py                         # Text-to-speech
│
├── llm/                               # LLM Layer
│   ├── __init__.py
│   ├── groq_client.py                 # Groq API client
│   └── prompts.py                     # System prompts
│
├── api/                               # API Layer (optional)
│   ├── __init__.py
│   ├── routes.py                      # HTTP endpoints
│   └── websocket.py                   # Real-time audio
│
├── tests/                             # Test Suite
│   ├── __init__.py
│   ├── test_loader.py
│   ├── test_validator.py
│   ├── test_supersedes.py
│   ├── test_inference.py
│   ├── test_policy.py
│   └── fixtures/                      # Test data
│
├── scripts/                           # Utility Scripts
│   ├── hash_entity.py                 # Compute content hash
│   ├── validate_corpus.py             # Validate all entities
│   ├── build_index.py                 # Build entity index
│   └── export_graph.py                # Export knowledge graph
│
├── agent.py                           # Main agent orchestrator
├── main.py                            # Entry point
└── config.py                          # Configuration
```

---

## 4. LDS SPECIFICATION

### 4.1 Core Principles

The LDS (Logic Data System) format is the foundation of LDS-VOICE. Every piece of truth the agent can speak comes from an LDS file.

**Key Rules:**
1. Every LDS file has exactly 5 sections: `_lds`, `vectors`, `core`, `inference`, `media`
2. `content_hash` = `sha256(canonical_json(vectors + core + inference + media))`
3. Entities are immutable (append-only via supersedes)
4. Hard references (`relates_to`, `requires`) must resolve
5. Soft references (`implies`, `conflicts_with`) are semantic tags

### 4.2 Entity Structure

```json
{
  "_lds": {
    "v": "0.1.0",                    // REQUIRED: Spec version
    "id": "lds:namespace/type/name", // REQUIRED: Unique identifier
    "type": "entity_type",           // REQUIRED: Classification
    "created_at": "ISO8601",         // REQUIRED: Creation timestamp
    "content_hash": "sha256:...",    // REQUIRED: Integrity hash
    "origin": "authority-id",        // REQUIRED: Issuing authority
    "supersedes": "lds:...",         // OPTIONAL: Previous version
    "schema": "lds://schemas/..."    // OPTIONAL: Schema reference
  },
  
  "vectors": {
    "category": ["tag1", "tag2"],    // REQUIRED: At least one
    "spatial": null,                 // OPTIONAL: 3D coordinates
    "temporal": null,                // OPTIONAL: Phase/sequence
    "causal": []                     // OPTIONAL: Dependencies
  },
  
  "core": {
    // Domain-specific truth data
    // NO LDS references allowed
    // NO probabilistic values
  },
  
  "inference": {
    "relates_to": [],                // REQUIRED: Connected entities
    "implies": [],                   // REQUIRED: Logical consequences
    "conflicts_with": [],            // REQUIRED: Incompatibilities
    "requires": []                   // REQUIRED: Prerequisites
  },
  
  "media": {
    // URI references to associated resources
    // Format: "scheme://path"
  }
}
```

### 4.3 Voice Profile Entity

Voice profiles are special LDS entities that control what the agent can say:

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:voice/profile/technical-truth",
    "type": "voice_profile",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:...",
    "origin": "lefebvre-design-solutions"
  },
  
  "vectors": {
    "category": ["voice-profile", "technical", "construction"]
  },
  
  "core": {
    "name": "Technical Truth Profile",
    "description": "Speaks technical specifications without marketing",
    "persona": "construction_expert",
    "tone": "professional",
    "verbosity": "detailed",
    "allowed_domains": [
      "construction",
      "materials",
      "specifications"
    ],
    "blocked_domains": [
      "marketing",
      "pricing",
      "sales"
    ],
    "fact_categories": {
      "always_include": [
        "dimensions",
        "ratings",
        "certifications"
      ],
      "include_when_asked": [
        "conflicts",
        "requirements",
        "implications"
      ],
      "never_include": [
        "unit_cost",
        "roi",
        "market_segment"
      ]
    }
  },
  
  "inference": {
    "relates_to": [],
    "implies": [
      "no_marketing_language",
      "no_superlatives",
      "include_conflicts_when_present",
      "include_requirements_when_present",
      "cite_source_entity"
    ],
    "conflicts_with": [
      "sales_profile",
      "marketing_profile"
    ],
    "requires": []
  },
  
  "media": {}
}
```

---

## 5. BUILD INSTRUCTIONS

### 5.1 Phase 1: Project Setup

**Instruction to Claude Code:**

```
Create the LDS-VOICE project with the following:

1. Initialize the directory structure exactly as specified in Section 3
2. Create requirements.txt with these dependencies:
   - groq>=0.4.0
   - faster-whisper>=0.10.0
   - pyttsx3>=2.90
   - python-dotenv>=1.0.0
   - pydantic>=2.0.0
   - pytest>=7.0.0

3. Create .env.example with:
   GROQ_API_KEY=your_api_key_here
   WHISPER_MODEL=base
   TTS_ENGINE=pyttsx3
   LOG_LEVEL=INFO

4. Create .gitignore excluding:
   - .env
   - __pycache__
   - *.pyc
   - .pytest_cache
   - lds/index.json

5. Create README.md with project overview, setup instructions, and usage examples

Document every file created with a header comment explaining its purpose.
```

### 5.2 Phase 2: Logic Kernel

**Instruction to Claude Code:**

```
Build the Logic Kernel with complete documentation:

FILE: kernel/loader.py
PURPOSE: Load and validate LDS entity files from disk
REQUIREMENTS:
- Load all .json files from lds/entities/ (recursive)
- Validate 5 required sections exist
- Build in-memory entity store
- Return dict mapping id → entity
DOCUMENT: Every function with docstrings, type hints, and example usage

FILE: kernel/validator.py
PURPOSE: Validate LDS entities against specification
REQUIREMENTS:
- Check all required _lds fields present
- Validate content_hash matches computed hash
- Check no extra top-level keys
- Validate inference arrays exist
- Check no LDS refs in core
DOCUMENT: Validation errors with specific failure reasons

FILE: kernel/hasher.py
PURPOSE: Compute LDS content hashes per specification
REQUIREMENTS:
- Implement canonical JSON stringify (sorted keys, recursive)
- Compute SHA-256 of vectors+core+inference+media
- Format as "sha256:<64-hex-chars>"
DOCUMENT: Hash algorithm with examples

FILE: kernel/supersedes.py
PURPOSE: Resolve version chains to find latest entities
REQUIREMENTS:
- Build supersedes graph from all entities
- Identify superseded entities
- Return only current (non-superseded) entities
- Support get_latest(base_id) function
- Support list_versions(base_id) function
DOCUMENT: Version resolution strategy

FILE: kernel/inference.py
PURPOSE: Extract inference-safe facts for rendering
REQUIREMENTS:
- Extract id, type, origin
- Extract core data
- Extract inference hooks
- Filter based on voice policy
DOCUMENT: What data is safe to render

FILE: kernel/indexer.py
PURPOSE: Build searchable indexes
REQUIREMENTS:
- Category index (tag → entity ids)
- Type index (type → entity ids)
- Full-text search on core fields
DOCUMENT: Index structures and query patterns

FILE: kernel/query.py
PURPOSE: Query engine for natural language questions
REQUIREMENTS:
- Parse query intent
- Match to entity categories
- Resolve to specific entities
- Return structured results
DOCUMENT: Query patterns with examples

FILE: kernel/diff.py
PURPOSE: Compute differences between entity versions
REQUIREMENTS:
- Compare two entities
- Identify changed fields
- Format human-readable diff
DOCUMENT: Diff algorithm and output format

Each file MUST include:
- Module docstring with purpose and usage
- Class/function docstrings
- Type hints on all functions
- Example usage in docstring
- Unit test file in tests/
```

### 5.3 Phase 3: Voice Layer

**Instruction to Claude Code:**

```
Build the Voice Layer with complete documentation:

FILE: voice/policy.py
PURPOSE: Apply voice profile rules to filter facts
REQUIREMENTS:
- Load voice profile entity
- Filter core data based on allowed_domains
- Filter core data based on fact_categories
- Apply inference implications (no_marketing_language, etc.)
- Return structured output safe for LLM rendering
DOCUMENT: Policy application rules with examples

FILE: voice/intent.py
PURPOSE: Parse user speech into structured intent
REQUIREMENTS:
- Extract entity references
- Extract attribute queries
- Extract comparison requests
- Extract version queries ("what changed?")
DOCUMENT: Intent patterns with examples

FILE: voice/composer.py
PURPOSE: Compose structured facts into render-ready format
REQUIREMENTS:
- Order facts by relevance
- Include source citations
- Format for LLM prompt
- Include voice profile constraints in prompt
DOCUMENT: Composition rules and output format

Each file MUST include:
- Module docstring with purpose and usage
- Class/function docstrings
- Type hints on all functions
- Example usage in docstring
- Unit test file in tests/
```

### 5.4 Phase 4: Audio Layer

**Instruction to Claude Code:**

```
Build the Audio Layer with complete documentation:

FILE: audio/stt.py
PURPOSE: Convert speech to text
REQUIREMENTS:
- Support faster-whisper for transcription
- Support microphone input
- Support file input for testing
- Return transcribed text with confidence
DOCUMENT: Audio formats supported, model options

FILE: audio/tts.py
PURPOSE: Convert text to speech
REQUIREMENTS:
- Support pyttsx3 for local TTS
- Support ElevenLabs API (optional)
- Support Coqui TTS (optional)
- Queue and play audio
DOCUMENT: TTS engine options and configuration

Each file MUST include:
- Module docstring with purpose and usage
- Class/function docstrings
- Type hints on all functions
- Example usage in docstring
- Fallback to terminal I/O for testing
```

### 5.5 Phase 5: LLM Layer

**Instruction to Claude Code:**

```
Build the LLM Layer with complete documentation:

FILE: llm/prompts.py
PURPOSE: System prompts that constrain LLM behavior
REQUIREMENTS:
- RENDERER_PROMPT: Only speak provided facts, no invention
- CLARIFIER_PROMPT: Ask clarifying questions only
- ERROR_PROMPT: Explain what's not available
DOCUMENT: Each prompt with rationale

FILE: llm/groq_client.py
PURPOSE: Groq API client for LLM rendering
REQUIREMENTS:
- Initialize with API key from env
- render_response(structured_facts, voice_profile) → text
- Handle rate limits
- Handle API errors gracefully
DOCUMENT: API usage, rate limits, error handling

The render_response function MUST:
1. Build system prompt from RENDERER_PROMPT
2. Include voice profile constraints
3. Format structured facts as user message
4. Call Groq API with llama3-70b-8192
5. Return only the rendered text
6. NEVER allow the LLM to add facts not in input

Each file MUST include:
- Module docstring with purpose and usage
- Class/function docstrings
- Type hints on all functions
- Example usage in docstring
```

### 5.6 Phase 6: Agent Orchestrator

**Instruction to Claude Code:**

```
Build the Agent Orchestrator:

FILE: agent.py
PURPOSE: Main agent loop connecting all components
REQUIREMENTS:
- Initialize kernel on startup
- Load voice profile
- Main loop: listen → query → render → speak
- Handle errors gracefully
- Log all queries and responses
DOCUMENT: Agent lifecycle, error handling

FILE: main.py
PURPOSE: Entry point with CLI options
REQUIREMENTS:
- --profile: Voice profile to use
- --mode: "voice" | "terminal" | "api"
- --log-level: DEBUG | INFO | WARN | ERROR
- Load config from .env
- Initialize and run agent
DOCUMENT: CLI usage, configuration options

FILE: config.py
PURPOSE: Configuration management
REQUIREMENTS:
- Load from .env
- Validate required settings
- Provide defaults
DOCUMENT: All configuration options

Each file MUST include:
- Module docstring with purpose and usage
- Class/function docstrings
- Type hints on all functions
- Example usage in docstring
```

### 5.7 Phase 7: Documentation

**Instruction to Claude Code:**

```
Create comprehensive documentation:

FILE: docs/ARCHITECTURE.md
- System overview diagram
- Component descriptions
- Data flow explanation
- Design decisions and rationale

FILE: docs/LDS_SPECIFICATION.md
- Complete LDS format specification
- All field definitions
- Validation rules
- Examples

FILE: docs/API_REFERENCE.md
- All public functions
- Parameters and return types
- Example calls
- Error codes

FILE: docs/VOICE_POLICY_GUIDE.md
- How to create voice profiles
- Available policy options
- Examples for different use cases

FILE: docs/DEPLOYMENT.md
- Production setup
- Environment configuration
- Performance tuning
- Monitoring

FILE: CHANGELOG.md
- Version history
- Breaking changes
- Migration guides
```

---

## 6. DOCUMENTATION REQUIREMENTS

Every file MUST follow these documentation standards:

### 6.1 File Headers

```python
"""
LDS-VOICE: [Module Name]
========================

Purpose:
    [One sentence description]

Description:
    [Detailed explanation of what this module does]

Dependencies:
    - [List of dependencies]

Example:
    >>> from kernel.loader import load_lds_entities
    >>> entities = load_lds_entities("lds/entities")
    >>> print(len(entities))
    42

Author: Lefebvre Design Solutions
Created: 2025-01-07
Version: 1.0.0
"""
```

### 6.2 Function Documentation

```python
def load_lds_entities(
    path: str = "lds/entities",
    validate: bool = True
) -> dict[str, dict]:
    """
    Load all LDS entity files from the specified directory.

    This function recursively scans the directory for .json files,
    parses each one, validates the LDS structure, and returns a
    dictionary mapping entity IDs to their full content.

    Args:
        path: Directory path containing LDS entity files.
              Defaults to "lds/entities".
        validate: Whether to validate each entity against the
                  LDS specification. Defaults to True.

    Returns:
        Dictionary mapping entity ID strings to entity dictionaries.
        Example: {"lds:construction/glazing/panel-v1": {...}}

    Raises:
        FileNotFoundError: If the path does not exist.
        LDSValidationError: If validate=True and an entity is invalid.
        json.JSONDecodeError: If a file contains invalid JSON.

    Example:
        >>> entities = load_lds_entities()
        >>> for id, entity in entities.items():
        ...     print(f"{id}: {entity['_lds']['type']}")
        lds:construction/glazing/panel-v1: glazing_assembly
        lds:construction/glazing/panel-v2: glazing_assembly

    Note:
        Entities are not automatically resolved for supersedes chains.
        Use kernel.supersedes.resolve_latest() for current versions.
    """
```

### 6.3 Class Documentation

```python
class LogicKernel:
    """
    The Logic Kernel is the core engine for LDS-VOICE.

    It manages entity storage, indexing, version resolution, and
    query execution. The kernel ensures that only validated,
    hash-verified entities are used for truth rendering.

    Attributes:
        entities (dict): Mapping of entity IDs to entity data.
        index (CategoryIndex): Searchable category index.
        latest (dict): Mapping of base IDs to current entities.

    Example:
        >>> kernel = LogicKernel("lds/entities")
        >>> kernel.load()
        >>> entity = kernel.get("lds:construction/glazing/panel-v2")
        >>> latest = kernel.get_latest("lds:construction/glazing/panel")

    Design Decisions:
        - Entities are loaded into memory for fast access
        - Supersedes chains are resolved on load
        - Indexes are built incrementally

    Thread Safety:
        The kernel is NOT thread-safe. For concurrent access,
        use separate kernel instances or external synchronization.
    """
```

### 6.4 Changelog Entry Format

```markdown
## [1.0.0] - 2025-01-07

### Added
- Initial Logic Kernel implementation
- Voice policy engine
- Groq LLM adapter

### Changed
- N/A (initial release)

### Fixed
- N/A (initial release)

### Security
- Content hash verification on all entities
```

---

## 7. TESTING REQUIREMENTS

### 7.1 Test File Structure

Every kernel module needs a corresponding test file:

```
tests/
├── test_loader.py
├── test_validator.py
├── test_hasher.py
├── test_supersedes.py
├── test_inference.py
├── test_indexer.py
├── test_query.py
├── test_diff.py
├── test_policy.py
├── test_intent.py
├── test_composer.py
├── test_groq_client.py
└── fixtures/
    ├── valid_entity.json
    ├── invalid_entity_missing_lds.json
    ├── invalid_entity_bad_hash.json
    ├── supersedes_chain/
    │   ├── entity-v1.json
    │   ├── entity-v2.json
    │   └── entity-v3.json
    └── voice_profiles/
        ├── technical-truth.json
        └── sales-profile.json
```

### 7.2 Test Categories

```python
# test_loader.py

class TestLoader:
    """Test suite for kernel/loader.py"""

    def test_load_valid_entity(self):
        """Should successfully load a valid LDS entity."""
        pass

    def test_load_directory_recursive(self):
        """Should load entities from nested directories."""
        pass

    def test_reject_invalid_json(self):
        """Should raise JSONDecodeError for malformed files."""
        pass

    def test_reject_missing_sections(self):
        """Should raise LDSValidationError for incomplete entities."""
        pass

    def test_entity_id_uniqueness(self):
        """Should detect duplicate entity IDs."""
        pass
```

### 7.3 Test Coverage Requirements

- Minimum 80% code coverage
- 100% coverage on validation logic
- 100% coverage on hash computation
- Edge cases documented in tests

---

## 8. SEED DATA

Include these LDS files in the project. They are the foundation for testing and demonstration.

### 8.1 Material Entity (v1)

**File: lds/entities/materials/neural-glass-v1.lds.json**

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:lefebvre/material/neural-glass-panel-lng-p-2025",
    "type": "material.photonic.glass",
    "created_at": "2025-01-07T02:00:00Z",
    "content_hash": "sha256:ecebd573fd70cc79c02af0801c21001b2f1d9dfa17974e2546e887079d83254c",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "smart-glass",
      "photonic-material",
      "electrochromic",
      "building-envelope",
      "energy-efficiency",
      "daylighting-control"
    ],
    "spatial": null,
    "temporal": null,
    "causal": []
  },
  "core": {
    "product_name": "Lefebvre Neural-Glass Panel",
    "model": "LNG-P-2025",
    "photon_to_electron_conversion_efficiency": 0.42,
    "thermal_conductivity_w_mk": {
      "opaque_state": 0.85,
      "transparent_state": 1.1
    },
    "opacity_switching_speed_ms": {
      "clear_to_opaque": 180,
      "opaque_to_clear": 220
    },
    "degradation_half_life_years": 32
  },
  "inference": {
    "relates_to": [
      "lds:lefebvre/product/lng-p-2025-marketing",
      "lds:construction/glazing/lefebvre-neural-glass-panel-lng-p-2025"
    ],
    "implies": [
      "reduced-hvac-load",
      "dynamic-glare-reduction",
      "improved-daylighting-control",
      "lower-peak-cooling-demand"
    ],
    "conflicts_with": [
      "sustained-temperature-above-80c",
      "uv-wavelength-below-280nm"
    ],
    "requires": [
      "electrochromic-control-voltage-24v-dc"
    ]
  },
  "media": {
    "spec_sheet": "pdf://lefebvre/neural-glass/LNG-P-2025-spec.pdf",
    "cad_model": "dwg://lefebvre/neural-glass/LNG-P-2025.dwg",
    "datasheet_image": "img://lefebvre/neural-glass/LNG-P-2025-render.png"
  }
}
```

### 8.2 Material Entity (v2)

**File: lds/entities/materials/neural-glass-v2.lds.json**

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2",
    "type": "material.photonic.glass",
    "created_at": "2025-03-15T02:00:00Z",
    "content_hash": "sha256:616b389af7260d9cfd1c56e06a622cbc1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d",
    "origin": "lefebvre-design-solutions",
    "supersedes": "lds:lefebvre/material/neural-glass-panel-lng-p-2025"
  },
  "vectors": {
    "category": [
      "smart-glass",
      "photonic-material",
      "electrochromic",
      "building-envelope",
      "energy-efficiency",
      "daylighting-control",
      "gen-2-cigs"
    ],
    "spatial": null,
    "temporal": null,
    "causal": []
  },
  "core": {
    "product_name": "Lefebvre Neural-Glass Panel",
    "model": "LNG-P-2025",
    "generation": "Gen 2",
    "bipv_cell_type": "CIGS Gen 2",
    "photon_to_electron_conversion_efficiency": 0.48,
    "thermal_conductivity_w_mk": {
      "opaque_state": 0.78,
      "transparent_state": 1.02
    },
    "opacity_switching_speed_ms": {
      "clear_to_opaque": 165,
      "opaque_to_clear": 195
    },
    "degradation_half_life_years": 38,
    "revision_notes": {
      "summary": "Gen 2 CIGS cell technology with improved efficiency and longevity",
      "changes": [
        "Photon conversion efficiency: 0.42 → 0.48 (+14.3%)",
        "Thermal conductivity (opaque): 0.85 → 0.78 W/mK (-8.2%)",
        "Switching speed (clear→opaque): 180ms → 165ms (-8.3%)",
        "Degradation half-life: 32 → 38 years (+18.8%)"
      ]
    }
  },
  "inference": {
    "relates_to": [
      "lds:lefebvre/product/lng-p-2025-marketing-v2",
      "lds:construction/glazing/lng-p-2025-v2"
    ],
    "implies": [
      "reduced-hvac-load",
      "dynamic-glare-reduction",
      "improved-daylighting-control",
      "lower-peak-cooling-demand",
      "gen-2-performance-tier"
    ],
    "conflicts_with": [
      "sustained-temperature-above-80c",
      "uv-wavelength-below-280nm"
    ],
    "requires": [
      "electrochromic-control-voltage-24v-dc"
    ]
  },
  "media": {
    "spec_sheet": "pdf://lefebvre/neural-glass/LNG-P-2025-v2-spec.pdf",
    "cad_model": "dwg://lefebvre/neural-glass/LNG-P-2025-v2.dwg",
    "datasheet_image": "img://lefebvre/neural-glass/LNG-P-2025-v2-render.png",
    "gen2_whitepaper": "pdf://lefebvre/research/gen2-cigs-technology.pdf"
  }
}
```

### 8.3 Construction Assembly (v2)

**File: lds/entities/assemblies/glazing-assembly-v2.lds.json**

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:construction/glazing/lng-p-2025-v2",
    "type": "glazing_assembly",
    "created_at": "2025-03-15T14:30:00Z",
    "content_hash": "sha256:c8474aed13cecb82c55529726ffd325d36765bb2fcf57fe795f7aa4a3d6c44f5",
    "origin": "lefebvre-design-solutions",
    "supersedes": "lds:construction/glazing/lefebvre-neural-glass-panel-lng-p-2025"
  },
  "vectors": {
    "category": [
      "glazing",
      "curtain-wall",
      "smart-glass",
      "electrochromic",
      "facade",
      "exterior-envelope",
      "energy-generating",
      "bipv",
      "high-performance",
      "commercial",
      "structural-glass"
    ],
    "spatial": {
      "origin": [0, 0, 0],
      "bounds": [[0, 0, 0], [1500, 3000, 52]],
      "coordinate_system": "cartesian"
    },
    "temporal": {
      "install_phase": 4,
      "sequence": 15
    },
    "causal": [
      "lds:construction/framing/curtain-wall-mullion-system",
      "lds:construction/electrical/facade-junction-box-480v"
    ]
  },
  "core": {
    "name": "Lefebvre Neural-Glass Panel",
    "model": "LNG-P-2025",
    "manufacturer": "Lefebvre Design Solutions",
    "category": "Electrochromic BIPV Insulated Glass Unit",
    "dimensions": {
      "width_mm": 1500,
      "height_mm": 3000,
      "thickness_mm": 52,
      "weight_kg": 147,
      "weight_psf": 10.1
    },
    "thermal_performance": {
      "r_value_imperial": 8.1,
      "u_value_imperial": 0.123,
      "u_value_metric": 0.70,
      "shgc_clear_state": 0.32,
      "shgc_tinted_state": 0.08,
      "visible_transmittance_clear": 0.65,
      "visible_transmittance_tinted": 0.02,
      "condensation_resistance": 78
    },
    "electrical_output": {
      "bipv_technology": "thin_film_cigs_gen2",
      "peak_power_wp": 210,
      "voltage_mpp_v": 39.5,
      "current_mpp_a": 5.32,
      "efficiency_percent": 14.0,
      "output_connector": "mc4_compatible"
    },
    "certifications": [
      "ASTM_E2190",
      "NFRC_certified",
      "UL_61730",
      "PHIUS_certified"
    ],
    "warranty_years": 30
  },
  "inference": {
    "relates_to": [
      "lds:lefebvre/material/neural-glass-panel-lng-p-2025-v2",
      "lds:lefebvre/product/lng-p-2025-marketing-v2",
      "lds:construction/framing/aluminum-curtain-wall-system-4500"
    ],
    "implies": [
      "dedicated_electrical_conduit_required",
      "thermal_break_mandatory",
      "bas_integration_point",
      "commissioning_protocol_required",
      "rapid_shutdown_compliance_nec_690.12"
    ],
    "conflicts_with": [
      "acetoxy_cure_silicone_sealant",
      "non_thermally_broken_aluminum_frame",
      "seismic_design_category_f_without_isolation",
      "voltage_system_120v_only"
    ],
    "requires": [
      "lds:construction/personnel/certified-glazier-agmt-level-3",
      "lds:construction/equipment/crane-capacity-15-ton-min",
      "lds:construction/permit/electrical-permit-bipv"
    ]
  },
  "media": {
    "spec_sheet": "pdf://lefebvre/glazing/LNG-P-2025-v2_specification.pdf",
    "cad_model_3d": "dwg://lefebvre/glazing/LNG-P-2025-v2_assembly.rvt",
    "installation_manual": "pdf://lefebvre/glazing/LNG-P-2025_install_guide.pdf"
  }
}
```

### 8.4 Voice Profile: Technical Truth

**File: lds/entities/profiles/voice-technical-truth.lds.json**

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:voice/profile/technical-truth",
    "type": "voice_profile",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:compute_on_creation",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "voice-profile",
      "technical",
      "construction",
      "engineering"
    ]
  },
  "core": {
    "name": "Technical Truth Profile",
    "description": "Professional engineering voice that speaks only verified specifications without marketing language",
    "persona": {
      "role": "senior_construction_engineer",
      "tone": "professional",
      "formality": "high",
      "verbosity": "detailed"
    },
    "language_rules": {
      "allowed": [
        "technical_specifications",
        "measurements_with_units",
        "certification_references",
        "safety_requirements",
        "compatibility_warnings",
        "installation_prerequisites"
      ],
      "forbidden": [
        "marketing_superlatives",
        "price_information",
        "sales_language",
        "unverified_claims",
        "comparative_marketing",
        "roi_projections"
      ],
      "required_disclaimers": [
        "cite_source_entity",
        "note_supersedes_if_applicable"
      ]
    },
    "fact_categories": {
      "always_include": [
        "dimensions",
        "weight",
        "thermal_performance",
        "electrical_specifications",
        "certifications",
        "warranty_years"
      ],
      "include_when_relevant": [
        "conflicts_with",
        "requires",
        "implies",
        "installation_phase"
      ],
      "include_when_asked": [
        "manufacturer",
        "model",
        "media_references"
      ],
      "never_include": [
        "unit_cost_usd",
        "roi_break_even_years",
        "market_segment",
        "target_asset_class",
        "rent_premium_uplift",
        "marketing_differentiation"
      ]
    },
    "response_format": {
      "structure": "fact_then_context",
      "citation_style": "inline_entity_id",
      "unit_preference": "both_imperial_and_metric"
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "no_marketing_language",
      "no_superlatives",
      "include_conflicts_when_present",
      "include_requirements_when_present",
      "cite_source_entity",
      "professional_tone"
    ],
    "conflicts_with": [
      "voice_profile_sales",
      "voice_profile_marketing",
      "voice_profile_casual"
    ],
    "requires": []
  },
  "media": {}
}
```

### 8.5 Voice Profile: Site Superintendent

**File: lds/entities/profiles/voice-superintendent.lds.json**

```json
{
  "_lds": {
    "v": "0.1.0",
    "id": "lds:voice/profile/site-superintendent",
    "type": "voice_profile",
    "created_at": "2025-01-07T00:00:00Z",
    "content_hash": "sha256:compute_on_creation",
    "origin": "lefebvre-design-solutions"
  },
  "vectors": {
    "category": [
      "voice-profile",
      "construction",
      "field",
      "safety"
    ]
  },
  "core": {
    "name": "Site Superintendent Profile",
    "description": "Practical field voice focused on installation requirements, safety, and coordination",
    "persona": {
      "role": "site_superintendent",
      "tone": "direct",
      "formality": "medium",
      "verbosity": "concise"
    },
    "language_rules": {
      "allowed": [
        "installation_requirements",
        "safety_conflicts",
        "equipment_needs",
        "personnel_requirements",
        "phase_sequence",
        "coordination_points"
      ],
      "forbidden": [
        "detailed_physics",
        "marketing_language",
        "financial_information",
        "research_data"
      ],
      "required_disclaimers": []
    },
    "fact_categories": {
      "always_include": [
        "requires",
        "conflicts_with",
        "install_phase",
        "weight",
        "dimensions"
      ],
      "include_when_relevant": [
        "certifications",
        "safety_ratings"
      ],
      "include_when_asked": [
        "thermal_performance",
        "electrical_specifications"
      ],
      "never_include": [
        "photon_conversion_efficiency",
        "degradation_half_life",
        "unit_cost_usd",
        "roi_projections"
      ]
    },
    "response_format": {
      "structure": "action_items_first",
      "citation_style": "none",
      "unit_preference": "imperial_only"
    }
  },
  "inference": {
    "relates_to": [],
    "implies": [
      "focus_on_requirements",
      "focus_on_conflicts",
      "focus_on_safety",
      "concise_responses",
      "action_oriented"
    ],
    "conflicts_with": [
      "voice_profile_sales",
      "voice_profile_research"
    ],
    "requires": []
  },
  "media": {}
}
```

---

## FINAL CHECKLIST

Before considering the build complete, verify:

### Code Quality
- [ ] All files have module docstrings
- [ ] All functions have docstrings with Args, Returns, Raises
- [ ] All functions have type hints
- [ ] No hardcoded paths or credentials
- [ ] Error handling on all external calls

### Documentation
- [ ] README.md complete with setup and usage
- [ ] CHANGELOG.md initialized
- [ ] Architecture diagram in docs/
- [ ] API reference complete
- [ ] Voice policy guide complete

### Testing
- [ ] Test file for every module
- [ ] Fixtures for valid/invalid entities
- [ ] Test for supersedes chain resolution
- [ ] Test for hash validation
- [ ] Test for voice policy filtering

### LDS Data
- [ ] All seed entities have valid hashes
- [ ] Supersedes chains are consistent
- [ ] Voice profiles are complete
- [ ] Index can be generated

### Integration
- [ ] Agent loop works end-to-end
- [ ] Terminal mode functional
- [ ] Error messages are helpful
- [ ] Logging is comprehensive

---

**END OF SPECIFICATION**

This document is the complete instruction set for building LDS-VOICE.
Execute each phase in order.
Document everything.
Test everything.

The result will be a voice agent that speaks only truth.

---

**Lefebvre Design Solutions**  
*Building the future of construction intelligence.*
